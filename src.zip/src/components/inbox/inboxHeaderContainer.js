import React, {Component} from 'react';
import {View, Text, TouchableOpacity, Platform, StatusBar} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import ArrowBackWhiteSVG from '../../icons/arrowBackWhiteSVG';
import FeatherSendWhiteSVG from '../../icons/featherSendWhiteSVG';
class InboxHeaderContainer extends Component {
  state = {};

  render() {
    const isIOS = Platform.OS === 'ios';
    return (
      <View style={{width: '100%', backgroundColor: SECONDRY_BLACK}}>
        {isIOS ? <View style={{height: 35}} /> : false}
        <View
          style={{
            width: '100%',
            height: 50,
            backgroundColor: SECONDRY_BLACK,
            flexDirection: 'row',
          }}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => this.props.navigation.goBack()}
            style={{
              width: 50,
              height: '100%',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <ArrowBackWhiteSVG size={16} />
          </TouchableOpacity>
          <View style={{flex: 1}}>{this.props.children}</View>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => this.props.navigation.push('NewMessageScreen')}
            style={{
              width: 50,
              height: '100%',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            {this.props.noRightIcon ? false : <FeatherSendWhiteSVG size={16} />}
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

export default InboxHeaderContainer;
