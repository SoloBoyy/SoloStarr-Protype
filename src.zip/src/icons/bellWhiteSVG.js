import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const BellWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="24.872" height="27.409" viewBox="0 0 24.872 27.409">
  <g id="Icon_feather-bell" data-name="Icon feather-bell" transform="translate(-3.5 -2)">
    <path id="Path_3748" data-name="Path 3748" d="M23.56,10.624a7.624,7.624,0,1,0-15.248,0C8.312,19.519,4.5,22.06,4.5,22.06H27.372S23.56,19.519,23.56,10.624" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_3749" data-name="Path 3749" d="M19.8,31.5a2.541,2.541,0,0,1-4.4,0" transform="translate(-1.667 -4.357)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default BellWhiteSVG;
