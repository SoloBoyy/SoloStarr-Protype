import React, {Component, useEffect} from 'react';
import {View, Text} from 'react-native';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import ForYouTabPage from '../components/foryouFollowing/forYouTabPage';
import MyTabBar from '../components/profile/myTabBar';
import FollowingTabPage from '../components/foryouFollowing/followingTabPage';
import ForYouFollwingTabBar from '../components/foryouFollowing/foryouFollowingTabBar';
import HitBox from '../components/foryouFollowing/hitBox';
import MyProfileScreenNew from './myProfileScreenNew';
import MyForYouController from '../controllers/forYouController';
const Tab = createMaterialTopTabNavigator();

const TabBar = ({state}) => {
  useEffect(() => {
    // console.log(`TAB INDEX ${state?.index}`);
    if (state.index === 1) {
      MyForYouController.setVideoPlayable(false);
    } else {
      MyForYouController.setVideoPlayable(true);
    }
  }, [state.index]);
  return <View />;
};

class FollowingAndForYouScreen extends Component {
  constructor() {
    super();
    this.unsubNavEvent = null;
  }
  componentDidMount() {
    // console.log('TEST 00- Adding Listner');
    this.unsubNavEvent = this.props.navigation.addListener('focus', () => {
      MyForYouController.setVideoPlayable(true);
    });
  }
  state = {};

  render() {
    return (
      <View style={{flex: 1}}>
        <Tab.Navigator tabBar={(props) => <TabBar {...props} />}>
          <Tab.Screen name="foryou" component={ForYouTabPage} />
          <Tab.Screen name="followng" component={MyProfileScreenNew} />
        </Tab.Navigator>
        <HitBox />
      </View>
    );
  }
}

export default FollowingAndForYouScreen;
