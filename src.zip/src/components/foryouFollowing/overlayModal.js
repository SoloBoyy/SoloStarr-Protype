import React, {PureComponent} from 'react';
import {View, Text, Modal, TouchableOpacity} from 'react-native';

class OverlayModal extends PureComponent {
  state = {};
  render() {
    const visible = this.props.visible ? true : false;
    return (
      <Modal
        key={25}
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={() => {
          if (this.props.setVisible) {
            this.props.setVisible(false);
          }
        }}>
        <View style={{flex: 1}}>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => {
              if (this.props.setVisible) {
                this.props.setVisible(false);
              }
            }}
            key={26}
            style={{
              flex: 1,
            }}></TouchableOpacity>
          {this.props.children}
        </View>
      </Modal>
    );
  }
}

export default OverlayModal;
