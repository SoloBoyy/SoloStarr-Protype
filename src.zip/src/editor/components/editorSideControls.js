import React from 'react';
import {View, Text} from 'react-native';
import MyTextIconButton from './myTextIconButton';
import FilterSVG from '../icons/filterSVG';
import NotesSVG from '../icons/notesSVG';
import LayerSVG from '../icons/layersSVG';
import ToolsSVG from '../icons/toolsSVG';
import SoundSVG from '../icons/soundSVG';
import SpeedSVG from '../icons/speedSVG';
import TextSVG from '../icons/textSVG';
import UploadsSVG from '../icons/uploadsSVG';
import MyLayoutManager from '../Controllers/layoutManager';
import {useSelector} from 'react-redux';
import MyRecordingController from '../Controllers/recordingConroller';

const EditorSideControls = (props) => {
  const buttonSize = 30;
  const topMargin = 5;
  const timerTimeoutValue = useSelector(
    (store) => store.EditorReducer.timerTimeout,
  );
  const recordingSpeed = useSelector(
    (store) => store.EditorReducer.recordingSpeed,
  );

  return (
    <View>
      {/* <MyTextIconButton topMargin={topMargin} size={buttonSize} title="Notes">
        <NotesSVG />
      </MyTextIconButton>

      <MyTextIconButton topMargin={topMargin} size={buttonSize} title="Layer">
        <LayerSVG />
      </MyTextIconButton> */}

      <MyTextIconButton
        onPress={() => MyLayoutManager.navigateTo('UploadScreen')}
        topMargin={topMargin}
        size={buttonSize}
        title="Upload">
        <UploadsSVG />
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => MyLayoutManager.navigateTo('SoundScreen')}
        topMargin={topMargin}
        size={buttonSize}
        title="Sound">
        <SoundSVG />
      </MyTextIconButton>

      <MyTextIconButton topMargin={topMargin} size={buttonSize} title="Filters">
        <FilterSVG />
      </MyTextIconButton>

      {/* CURRENT SPEED */}
      <MyTextIconButton
        onPress={() => false}
        topMargin={topMargin}
        size={buttonSize}
        title="Speed">
        {props.playingSpeed === 1 ? (
          <SpeedSVG />
        ) : (
          <Text
            style={{
              color: 'white',
              fontSize: 12,
            }}>{`${props.playingSpeed}x`}</Text>
        )}
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => false}
        topMargin={topMargin}
        size={buttonSize}
        title="Text">
        <Text style={{color: 'white', fontSize: 20, fontWeight: 'bold'}}>
          T
        </Text>
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => false}
        topMargin={topMargin}
        size={buttonSize}
        title="Tools">
        <ToolsSVG />
      </MyTextIconButton>
    </View>
  );
};

export default EditorSideControls;
