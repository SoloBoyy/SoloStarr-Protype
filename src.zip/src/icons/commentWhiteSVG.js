import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CommentWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="28" height="14" viewBox="0 0 28 14">
  <defs>
    <clipPath id="clip-path">
      <rect width="18" height="4" fill="none"/>
    </clipPath>
  </defs>
  <g id="Group_626" data-name="Group 626" transform="translate(-239 -141)">
    <rect id="Rectangle_627" data-name="Rectangle 627" width="28" height="14" rx="7" transform="translate(239 141)" fill="#fff"/>
    <g id="Repeat_Grid_5" data-name="Repeat Grid 5" transform="translate(244 146)" clip-path="url(#clip-path)">
      <g transform="translate(-245 -16)">
        <circle fill="#111111" id="Ellipse_80" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)"/>
      </g>
      <g transform="translate(-238 -16)">
        <circle fill="#111111" id="Ellipse_80-2" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)"/>
      </g>
      <g transform="translate(-231 -16)">
        <circle fill="#111111" id="Ellipse_80-3" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)"/>
      </g>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default CommentWhiteSVG;
