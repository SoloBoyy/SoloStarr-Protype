import React, {useEffect, useState, useRef} from 'react';
import {View, Text, FlatList, Animated} from 'react-native';
import MyProfileAnimController from '../../screens/profileAnimController';
import ProfileSnapLiked from './profileSnapLiked';
import ProfileSnapSeries from './profileSnapSeries';
import SingleSnap from './singleSnap';
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const LikedTabContent = (props) => {
  const yAnim = new Animated.Value(0);
  const listRef = useRef();
  const [posts, setPosts] = useState([{_id: 1}, {_id: 2}, {_id: 3}, {_id: 4}]);
  // ({nativeEvent}) => console.log(nativeEvent.contentOffset.y);
  // Animated.event(
  //   {nativeEvent: {contentOffset: {y: props.y}}},
  //   {useNativeDriver: true},
  // );
  const scrollToStart = () => {
    listRef.current.scrollToOffset({animated: true, offset: 0});
  };
  MyProfileAnimController.setTopScrollHandler('liked', scrollToStart);
  useEffect(() => {
    // console.log('On change tab');
    // console.log(props.currentTab);
    if (props.currentTab !== 'Liked') {
      scrollToStart();
    }
  }, [props.currentTab]);
  return (
    <AnimatedFlatList
      onScroll={Animated.event(
        [
          {
            nativeEvent: {
              contentOffset: {
                y: props.title === props.currentTab ? props.y : yAnim,
              },
            },
          },
        ],
        {useNativeDriver: true}, //83tert <-- Add this
      )}
      ref={listRef}
      numColumns={1}
      data={posts}
      renderItem={({item, index}) => (
        <ProfileSnapLiked
          key={`${Math.round(Math.random() * 10000)}-${index}`}
          {...{title: `10/13/2020`}}
        />
      )}
      keyExtractor={(item) =>
        `${Math.round(Math.random() * 10000)}-${item._id}`
      }
    />
  );
};
export default LikedTabContent;
