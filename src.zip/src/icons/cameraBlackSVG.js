import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CameraBlackSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="27" height="20.25" viewBox="0 0 27 20.25">
  <g id="Icon_ionic-ios-camera" data-name="Icon ionic-ios-camera" transform="translate(-4.5 -7.875)">
    <path fill="#111111" id="Path_2200" data-name="Path 2200" d="M22.043,19.336A4.043,4.043,0,1,1,18,15.293,4.043,4.043,0,0,1,22.043,19.336Z"/>
    <path fill="#111111" id="Path_2201" data-name="Path 2201" d="M29.355,11.25H25.523a1.141,1.141,0,0,1-.844-.38c-2-2.236-2.749-3-3.565-3H15.1c-.823,0-1.631.759-3.635,3a1.119,1.119,0,0,1-.837.373h-.288v-.562a.564.564,0,0,0-.563-.562H7.952a.564.564,0,0,0-.562.563v.563H6.862A2.28,2.28,0,0,0,4.5,13.409V25.784a2.434,2.434,0,0,0,2.355,2.341h22.5A2.254,2.254,0,0,0,31.5,25.784V13.409A2.1,2.1,0,0,0,29.355,11.25ZM18.281,25.341A6.011,6.011,0,1,1,24,19.617,6.017,6.017,0,0,1,18.281,25.341ZM24.75,15.328a.914.914,0,1,1,.914-.914A.912.912,0,0,1,24.75,15.328Z"/>
  </g>
</svg>
`}
    />
  );
};
export default CameraBlackSVG;
