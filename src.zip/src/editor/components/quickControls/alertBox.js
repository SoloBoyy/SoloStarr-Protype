import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import MyAlertBoxController from '../../Controllers/myAlertBoxController';
const AlertBoxButton = (props) => {
  const value = props.value ? props.value : {_id: 1, title: 'Yes'};
  return (
    <TouchableOpacity
      onPress={props.onPress ? () => props.onPress(value.title) : () => false}
      style={{
        height: '80%',
        borderRadius: props.radious,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
      }}>
      <Text style={{paddingLeft: 10, paddingRight: 10}}>{value.title}</Text>
    </TouchableOpacity>
  );
};

const AlertBox = (props) => {
  const radious = 10;
  //   const actions = [
  //     {_id: 1, title: 'Yes'},
  //     {_id: 2, title: 'Discard'},
  //   ];

  return (
    <View style={Styles.container}>
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          padding: 10,
        }}>
        <Text style={{color: 'black', fontSize: 15}}>
          {props.alertBox.message}{' '}
        </Text>
      </View>
      <View
        style={{
          height: 40,
          width: '100%',
          backgroundColor: 'white',
          borderBottomRightRadius: radious,
          borderBottomLeftRadius: radious,
          justifyContent: 'space-around',
          alignItems: 'center',
          flexDirection: 'row',
        }}>
        {props.alertBox.actions.map((a) => (
          <AlertBoxButton
            onPress={(result) => {
              MyAlertBoxController.onAlertResult(result);
            }}
            key={a._id}
            value={a}
            radious={radious}
          />
        ))}
      </View>
    </View>
  );
};
const mapStateToProps = (state) => ({
  alertBox: state.EditorReducer.alertBox,
});
export default connect(mapStateToProps, null)(AlertBox);

const Styles = StyleSheet.create({
  container: {
    width: '80%',
    minHeight: 100,
    borderRadius: 10,
    backgroundColor: 'white',
    alignSelf: 'center',
    elevation: 3,
  },
});
