import produce from 'immer';
import React, {Component} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {WHITE_COLOR} from '../../themes/colors';

const CircleButton = (props) => {
  const invert = props.invert ? true : false;
  const size = props.size ? props.size : 30;
  return (
    <TouchableOpacity
      onPress={props.onPress ? props.onPress : () => false}
      key={30}
      style={{
        width: size,
        height: size,
        borderRadius: 50,
        marginBottom: 5,
        backgroundColor: invert ? 'black' : WHITE_COLOR,
        justifyContent: 'center',
        alignItems: 'center',
        ...props.style,
      }}>
      {props.Icon ? props.Icon(props) : false}
    </TouchableOpacity>
  );
};

export default CircleButton;
