import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const ToolsSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="261.787" height="254.821" viewBox="0 0 261.787 254.821">
  <path id="Icon_metro-tools" data-name="Icon metro-tools" d="M247.489,43.843a61.5,61.5,0,0,1-87.165,77.145l-17.011,18.578,12.137,12.185L162.7,144.5a9.479,9.479,0,0,1,13.423,0l58.819,59.418a9.479,9.479,0,0,1,0,13.423L208.1,244.187a9.479,9.479,0,0,1-13.423,0l-58.819-59.418a9.479,9.479,0,0,1,0-13.423l6.625-6.625-11.566-11.6L49.573,241.992a18.976,18.976,0,0,1-26.847,0l-6.712-6.712a18.976,18.976,0,0,1,0-26.847l92.667-77.61L47.136,69.113,27.7,69.1,5.2,32.934,23.307,14.8,60.3,37.441l.242,19.032,62.261,62.5,18.114-15.164a61.558,61.558,0,0,1,72.929-93.46L173.961,49.684l33.568,33.568,39.96-39.409Z" transform="translate(3.039 0.766)" fill="none" stroke="#fff" stroke-width="13"/>
</svg>
`}
    />
  );
};
export default ToolsSVG;
