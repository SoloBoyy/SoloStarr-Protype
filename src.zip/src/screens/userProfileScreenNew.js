import React, {Component, useRef} from 'react';
import {
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  Modal,
  Dimensions,
  FlatList,
  Image,
  Platform,
} from 'react-native';
import ProfileHeader from '../components/profile/V2/profileHeader';
import UserProfileDetailHeader from '../components/profile/V2/userProfileDetailHeader';
import PostTabContent from '../components/profile/V2/userPostsTabContent';
import {SECONDRY_BLACK} from '../themes/colors';
import ArrowBackWhiteSVG from '../icons/arrowBackWhiteSVG';
import {goBack} from '../navigator';

const {width, height} = Dimensions.get('window');

class UserProfileScreenNew extends Component {
  constructor() {
    super();
    this.state = {};
    this.HEADER_HEIGHT = Platform.OS === 'ios' ? 110 : 100; /// TODIOS 100-> 110
  }

  render() {
    return (
      <View style={{flex: 1, backgroundColor: 'black'}}>
        <StatusBar
          hidden={false}
          backgroundColor={SECONDRY_BLACK}
          barStyle="light-content"
        />
        <View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            zIndex: 999,
          }}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => goBack()}
            style={{
              marginTop: 30,
              width: 40,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <ArrowBackWhiteSVG size={16} />
          </TouchableOpacity>
        </View>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          <View
            style={{
              width,
              height: height + this.HEADER_HEIGHT - StatusBar.currentHeight,
              borderBottomLeftRadius: 50,
              borderBottomRightRadius: 50,
              backgroundColor: SECONDRY_BLACK,
              justifyContent: 'space-between', /// TODOIOS
            }}>
            <UserProfileDetailHeader />
            <ProfileHeader />
          </View>
          <View style={{height: height - this.HEADER_HEIGHT}}>
            <PostTabContent />
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default UserProfileScreenNew;
