import React, {useState} from 'react';
import {View, StyleSheet, PermissionsAndroid, Platform} from 'react-native';
import MyButton from './myButton';
import {connect} from 'react-redux';
import MyRecordingController from '../Controllers/recordingConroller';
import CaptureButton from './captureButton';
import MyLayoutManager from '../Controllers/layoutManager';
import MyEditingController from '../Controllers/editingController';
import MyAlertBoxController from '../Controllers/myAlertBoxController';
import VideoClipsTimeline from './clipsTimeline/videoClipsTimeline';

const FooterOverlay = (props) => {
  const [enabled, setEnabled] = useState(true);
  const _handleCaptureButtonPress = () => {
    setEnabled(false);
    // console.log('STARTING...');
    setTimeout(() => setEnabled(true), 50);

    checkCameraPermission()
      .then((granted) => {
        MyRecordingController.checkMemory()
          .then((res) => {
            MyRecordingController.toggleCam();
          })
          .catch((err) => {
            console.log(err);
          });
      })
      .catch((err) => {
        console.log('CAMERA PERMSSION NOT GRANTED');
      });
  };

  const checkAudioPermission = () => {
    return new Promise((resolve, reject) => {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO)
        .then((granted) => {
          if (!granted) {
            PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
            )
              .then((granted) => {
                console.log('Permission Granted By User');
                resolve(true);
              })
              .catch((err) => {
                console.log('PERMISSION NOT GRANGED');
                console.log(err);
                reject(false);
              });
          } else {
            console.log('PERMISSION ALREADY GRANTED');
            resolve(true);
          }
        })
        .catch((err) => {
          console.log('Error in Checking PERMISSION');
          reject(false);
        });
    });
  };

  const checkCameraPermission = () => {
    return new Promise((resolve, reject) => {
      if (Platform.OS === 'android') {
        PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA)
          .then((granted) => {
            if (!granted) {
              PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA)
                .then((granted) => {
                  console.log('Permission Granted By User');
                  checkAudioPermission()
                    .then((granted) => {
                      resolve(true);
                    })
                    .catch((err) => {
                      reject(false);
                    });
                })
                .catch((err) => {
                  console.log('PERMISSION NOT GRANGED');
                  console.log(err);
                  reject(false);
                });
            } else {
              console.log('PERMISSION ALREADY GRANTED');
              resolve(true);
            }
          })
          .catch((err) => {
            console.log('Error in Checking PERMISSION');
            reject(false);
          });
      } else {
        resolve(true);
      }
    });
  };

  const checkPermission = () => {
    return new Promise((resolve, reject) => {
      PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      )
        .then((granted) => {
          if (!granted) {
            PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            )
              .then((granted) => {
                console.log('Permission Granted By User');
                resolve(true);
              })
              .catch((err) => {
                console.log('PERMISSION NOT GRANGED');
                console.log(err);
                reject(false);
              });
          } else {
            console.log('PERMISSION ALREADY GRANTED');
            resolve(true);
          }
        })
        .catch((err) => {
          console.log('Error in Checking PERMISSION');
          reject(false);
        });
    });
  };

  return (
    <View
      style={{
        width: '100%',
        height: '70%',
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View style={{flex: 1}}>
        {props.editorLayoutMode.F_L_UNDO ? (
          <MyButton
            onPress={() => {
              MyAlertBoxController.show(
                MyAlertBoxController.ACTIONS_NO_DISCARD,
                'The Clip will be discarded permanently',
                (result) => {
                  if (result === MyAlertBoxController.RESULTS.DISCARD) {
                    MyRecordingController.removeLastRecordedClip();
                  }
                },
              );
            }}
            name="redo"
          />
        ) : (
          false
        )}
      </View>
      <View style={{flex: 2, alignItems: 'center'}}>
        {props.editorLayoutMode.F_C_CAPTURE_INITIAL ? (
          <CaptureButton
            onPress={() => {
              if (enabled) {
                _handleCaptureButtonPress();
              }
            }}
          />
        ) : (
          false
        )}
      </View>
      <View style={{flex: 1, alignItems: 'flex-end'}}>
        {props.editorLayoutMode.F_R_NEXT_ARROW ? (
          <MyButton
            onPress={() => {
              checkPermission()
                .then((granted) => {
                  MyRecordingController.checkMemory()
                    .then((memRes) => {
                      // MyLayoutManager.setLoaderVisible(
                      //   true,
                      //   'Processing...',
                      // ).then((res) => {});
                      setTimeout(() => {
                        // MyEditingController.processVideo()
                        //   .then((res) => {
                        // MyLayoutManager.setEditorLayoutMode(
                        //   MyLayoutManager.LAYOUT_MODE
                        //     .ZERO_EDITOR_VIDEO_PREVIEW,
                        // );
                        MyEditingController.setPlayingMode('full');
                        MyLayoutManager.navigateTo('VideoEditingScreen');
                        // console.log('PROCESSED......');
                        // })
                        // .catch((err) => {
                        //   // console.log('PROCESSING CATCH ERROR');
                        //   MyAlertBoxController.show(
                        //     MyAlertBoxController.ACTIONS_OKAY,
                        //     err,
                        //     (result) => false,
                        //   );
                        //   console.log(err);
                        // });
                      }, 10);
                    })
                    .catch((err) => {
                      MyAlertBoxController.show(
                        MyAlertBoxController.ACTIONS_OKAY,
                        err,
                        (res) => false,
                      );
                    });
                })
                .catch((err) => console.log('NO STORAGE ACCESS PERMISSON'));
            }}
            name="arrow-right"
          />
        ) : (
          false
        )}

        {props.editorLayoutMode.F_VIDEO_CLIPS_TIMELINE ? (
          <VideoClipsTimeline />
        ) : (
          false
        )}
      </View>
    </View>
  );
};
const Styles = StyleSheet.create({});
const mapStateToProps = (state) => ({
  editorLayoutMode: state.EditorReducer.editorLayoutMode,
});
export default connect(mapStateToProps, null)(FooterOverlay);
