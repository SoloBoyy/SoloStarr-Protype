import React, {Component} from 'react';
import {View, TouchableOpacity, StatusBar, Modal} from 'react-native';
import GestureList from '../components/gestureList/listGesture';
class FiltersScreen extends Component {
  state = {};
  render() {
    return (
      <Modal
        visible={this.props.visible ? true : false}
        animationType="fade"
        transparent={true}
        onRequestClose={() => {
          if (this.props.onClose) {
            this.props.onClose();
          }
        }}>
        <View style={{flex: 1, backgroundColor: 'rgba(0,0,0,0.6)'}}>
          <TouchableOpacity
            onPress={() => this.props.onClose()}
            style={{
              width: 100,
              height: 100,

              position: 'absolute',
              zIndex: 999,
            }}></TouchableOpacity>
          <GestureList />
          <View style={{height: 0, width: '100%'}} />
        </View>
      </Modal>
    );
  }
}

export default FiltersScreen;
