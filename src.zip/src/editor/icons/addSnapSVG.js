import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const AddSnapSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg id="add" xmlns="http://www.w3.org/2000/svg" width="30.893" height="30.893" viewBox="0 0 30.893 30.893">
  <g id="Group_67" data-name="Group 67">
    <g id="Group_66" data-name="Group 66">
      <path id="Path_58" data-name="Path 58" d="M28,27.031H25.1V28a2.9,2.9,0,0,1-2.9,2.9H2.9A2.9,2.9,0,0,1,0,28V8.689a2.9,2.9,0,0,1,2.9-2.9h.965V2.9A2.9,2.9,0,0,1,6.758,0H28a2.9,2.9,0,0,1,2.9,2.9V24.135A2.9,2.9,0,0,1,28,27.031Zm-24.135-2.9V7.723H2.9a.965.965,0,0,0-.965.965V28a.965.965,0,0,0,.965.965H22.2A.965.965,0,0,0,23.17,28v-.965H6.758A2.9,2.9,0,0,1,3.862,24.135ZM28.962,2.9A.965.965,0,0,0,28,1.931H6.758a.965.965,0,0,0-.965.965V24.135a.965.965,0,0,0,.965.965H28a.965.965,0,0,0,.965-.965Z" fill="#fff"/>
      <path id="Path_59" data-name="Path 59" d="M183.723,189.516h-1.931v-5.792H176v-1.931h5.792V176h1.931v5.792h5.792v1.931h-5.792Z" transform="translate(-165.381 -169.242)" fill="#fff"/>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default AddSnapSVG;
