import React, {Component} from 'react';
import {View, Text, TextInput, Animated} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {WHITE_COLOR} from '../../themes/colors';
const ProfileSearchBox = (props) => {
  return (
    <Animated.View
      style={{
        width: '100%',
        height: 35,
        backgroundColor: 'black',
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 50,
        paddingLeft: 5,
        paddingRight: 5,
        ...props.style,
      }}>
      <Icon
        style={{color: WHITE_COLOR, width: 20, paddingLeft: 5}}
        name="search"
      />
      <TextInput style={{flex: 1, color: 'white', marginBottom: -3}} />
    </Animated.View>
  );
};
export default ProfileSearchBox;
