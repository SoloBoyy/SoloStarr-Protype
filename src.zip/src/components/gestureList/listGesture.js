import React, {useRef, useState} from 'react';
import {
  View,
  TouchableOpacity,
  Dimensions,
  FlatList,
  Animated,
} from 'react-native';
import Card, {CARD_HEIGHT, CARD_WIDTH} from './card';
import Icon from 'react-native-vector-icons/FontAwesome';
const AnimatedFlatlist = Animated.createAnimatedComponent(FlatList);

const ListGesture = (props) => {
  const [cards, setCards] = useState([
    {_id: 1, title: 'F1', isTransparent: true},
    {_id: 2, title: 'F2', isTransparent: true},
    {_id: 3, title: 'F1', isTransparent: false},
    {_id: 4, title: 'F2', isTransparent: false},
    {_id: 5, title: 'F3', isTransparent: false},
    {_id: 6, title: 'F4', isTransparent: false},
    {_id: 7, title: 'F5', isTransparent: false},
    {_id: 8, title: 'F6', isTransparent: false},
    {_id: 9, title: 'F7', isTransparent: false},
    {_id: 13, title: 'F8', isTransparent: false},
    {_id: 14, title: 'F9', isTransparent: false},
    {_id: 15, title: 'F10', isTransparent: false},
    {_id: 16, title: 'F11', isTransparent: false},
    {_id: 10, title: 'F12', isTransparent: false},
    {_id: 11, title: 'F11', isTransparent: true},
    {_id: 12, title: 'F12', isTransparent: true},
  ]);
  const [isEye, setIsEye] = useState(false);
  const {width, height} = Dimensions.get('window');
  const x = new Animated.Value(0);
  const onScroll = Animated.event([{nativeEvent: {contentOffset: {x}}}], {
    useNativeDriver: true,
  });

  const listRef = useRef();
  const scrollToIndex = (index) => {
    let offset = CARD_WIDTH * index - CARD_WIDTH * 2.1;
    listRef.current.scrollToOffset({animated: true, offset: offset});
  };
  return (
    <View
      style={{
        width,
        height: height,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <TouchableOpacity
        // onPress={() => setIsEye(!isEye)}
        style={{
          width: 50,
          height: 50,
          position: 'absolute',
          bottom: CARD_HEIGHT + 120,
          justifyContent: 'flex-end',
          alignItems: 'center',
          zIndex: 999,
        }}>
        <Icon name={isEye ? 'eye' : 'eye-slash'} color="white" size={20} />
      </TouchableOpacity>
      <AnimatedFlatlist
        showsHorizontalScrollIndicator={false}
        ref={listRef}
        scrollEventThrottle={16}
        horizontal
        {...{onScroll}}
        contentContainerStyle={{alignItems: 'flex-end'}}
        style={{width: width, height}}
        data={cards}
        renderItem={({item, index}) => (
          <Card
            {...{
              index,
              x,
              title: item.title,
              isTransparent: item.isTransparent,
              onPress: () => scrollToIndex(index),
            }}
          />
        )}
        keyExtractor={(item) => `${item._id}`}
      />
    </View>
  );
};
// export default ListGesture;

// import React, {Component} from 'react';
// import {View, Text} from 'react-native';
// const GestureList = (props) => {
//   return <View />;
// };

export default ListGesture;
