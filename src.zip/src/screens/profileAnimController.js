class ProfileAnimController {
  constructor() {
    this.CURRENT_TAB = 'series';
    this._postTopScrollHandler = null;
    this._seriesTopScrollHandler = null;
    this._likedTopScrollHandler = null;

    this.setCurrentTab = (tab) => {
      this.CURRENT_TAB = tab.toLowerCase();
    };

    this.setTopScrollHandler = (tab, _handler) => {
      switch (tab) {
        case 'series':
          this._seriesTopScrollHandler = _handler;
          break;
        case 'posts':
          this._postTopScrollHandler = _handler;
          break;
        case 'liked':
          this._likedTopScrollHandler = _handler;
          break;
      }
    };

    this.scrollToTop = () => {
      //   console.log(`Scrolling top: ${this.CURRENT_TAB}`);
      switch (this.CURRENT_TAB) {
        case 'series':
          if (this._seriesTopScrollHandler) this._seriesTopScrollHandler();
          break;
        case 'posts':
          if (this._postTopScrollHandler) this._postTopScrollHandler();
          break;
        case 'liked':
          if (this._likedTopScrollHandler) this._likedTopScrollHandler();
          break;
      }
    };
  }
}

const MyProfileAnimController = new ProfileAnimController();
export default MyProfileAnimController;
