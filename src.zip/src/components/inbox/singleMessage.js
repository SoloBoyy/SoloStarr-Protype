import React, {Component} from 'react';
import {View, Text, Animated, StyleSheet} from 'react-native';
import {WHITE_COLOR} from '../../themes/colors';
import {PanGestureHandler, State} from 'react-native-gesture-handler';

const SingleMessage = (props) => {
  const message = props.message
    ? props.message
    : {_id: 0, isSender: false, text: 'hey'};
  const isSender = message.isSender;
  const _translateX = new Animated.Value(0);
  const translationX = _translateX.interpolate({
    inputRange: [-200, 0],
    outputRange: [-140, 0],
    extrapolate: 'clamp',
  });

  const opacity = _translateX.interpolate({
    inputRange: [-200, 0],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  const _onGestureStateChange = (state) => {
    switch (state.nativeEvent.state) {
      case State.END:
        Animated.timing(_translateX, {
          toValue: 0,
          duration: 500,
          useNativeDriver: true,
        }).start();
        break;
    }
  };
  const _onGestureEvent = Animated.event(
    [
      {
        nativeEvent: {
          translationX: _translateX,
        },
      },
    ],
    {useNativeDriver: true},
  );
  return (
    <View style={{width: '100%'}}>
      {isSender ? (
        <Animated.View
          style={{
            ...StyleSheet.absoluteFill,
            justifyContent: 'center',
            alignItems: 'flex-end',
            opacity: opacity,
          }}>
          <Text style={{color: 'white'}}>
            {new Date().toLocaleDateString()}
          </Text>
        </Animated.View>
      ) : (
        false
      )}
      <PanGestureHandler
        onHandlerStateChange={_onGestureStateChange}
        onGestureEvent={_onGestureEvent}>
        <Animated.View
          style={{
            transform: [{translateX: isSender ? translationX : 0}],
            minHeight: 40,
            maxWidth: '70%',
            backgroundColor: isSender ? '#555555' : '#333333',
            borderRadius: 50,
            justifyContent: 'center',
            paddingLeft: 20,
            paddingRight: 20,
            paddingTop: 10,
            paddingBottom: 10,
            marginBottom: 5,
            alignSelf: isSender ? 'flex-end' : 'flex-start',
          }}>
          <Text style={{color: WHITE_COLOR}}>{message.text}</Text>
        </Animated.View>
      </PanGestureHandler>
    </View>
  );
};

export default SingleMessage;
