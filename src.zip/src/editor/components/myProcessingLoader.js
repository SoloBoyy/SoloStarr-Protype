import React, {Component} from 'react';
import {View, Text, Dimensions, ActivityIndicator} from 'react-native';

const MyProcessingLoader = (props) => {
  const {width, height} = Dimensions.get('window');
  const message = props.message ? props.message : 'Processing...';
  const visible = props.visible ? true : false;

  // if (visible) {
  return (
    <View
      style={{
        width: 100,
        height: 75,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(1, 1, 1, 0.7)',
        borderRadius: 10,
        zIndex: 999,
      }}>
      <ActivityIndicator color="white" size={40} />
      <Text style={{color: 'white', fontStyle: 'italic'}}>{message}</Text>
    </View>
  );
  // } else {
  //   return false;
  // }
};
export default MyProcessingLoader;
