import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const SeasorWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="29.121" height="30" viewBox="0 0 29.121 30">
  <g id="Icon_feather-scissors" data-name="Icon feather-scissors" transform="translate(-3 -3)">
    <path id="Path_53" data-name="Path 53" d="M13.5,9A4.5,4.5,0,1,1,9,4.5,4.5,4.5,0,0,1,13.5,9Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
    <path id="Path_54" data-name="Path 54" d="M13.5,27A4.5,4.5,0,1,1,9,22.5,4.5,4.5,0,0,1,13.5,27Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
    <path id="Path_55" data-name="Path 55" d="M30,6,12.18,23.82" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
    <path id="Path_56" data-name="Path 56" d="M21.7,21.72,30,30" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
    <path id="Path_57" data-name="Path 57" d="M12.18,12.18,18,18" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
  </g>
</svg>
`}
    />
  );
};
export default SeasorWhiteSVG;
