import React, {useState, useRef} from 'react';
import {View, Text, ScrollView, Dimensions} from 'react-native';
import {DARK_GRAY, LIGHT_GRAY} from '../../../themes/colors';
import {connect} from 'react-redux';
import TrashSVG from '../../icons/trashSVG';
import AddSnapSVG from '../../icons/addSnapSVG';
import SeasorWhiteSVG from '../../icons/seasorWhiteSVG';
import MyTextIconButton from '../myTextIconButton';
import SingleClip, {
  CLIP_NORMAL_SIZE,
  CLIP_TRANSITOR_SIZE,
  CLIP_SELECTED_SIZE,
} from './singleClip';
import MyRecordingController from '../../Controllers/recordingConroller';
import MyAlertBoxController from '../../Controllers/myAlertBoxController';
import MyEditingController from '../../Controllers/editingController';
import Icon from 'react-native-vector-icons/FontAwesome5';
const VideoClipsTimeline = (props) => {
  const [dragging, setDragging] = useState(false);
  const [containerHeight, setContainerHeight] = useState(0);
  const {width} = Dimensions.get('window');
  const [clips, setClips] = useState([
    {_id: 1, selected: false},
    {_id: 2, selected: false},
    {_id: 3, selected: false},
    {_id: 4, selected: false},
    {_id: 5, selected: false},
    {_id: 6, selected: false},
    {_id: 7, selected: false},
    {_id: 8, selected: false},
    {_id: 9, selected: false},
    {_id: 10, selected: false},
  ]);

  const timeLineScrollViewRef = useRef();
  const scrollToIndex = (index) => {
    let clipIndex = index;

    // if (clipIndex >= 0) {
    let offset =
      clipIndex * (CLIP_NORMAL_SIZE.width + CLIP_TRANSITOR_SIZE.width);
    offset -=
      (width - (CLIP_SELECTED_SIZE.width + CLIP_TRANSITOR_SIZE.width)) / 2 -
      CLIP_TRANSITOR_SIZE.width;
    setTimeout(
      () => timeLineScrollViewRef.current.scrollTo({x: offset, animated: true}),
      100,
    );
    // }
  };

  const handleDeleteSelectedClip = () => {
    const selectedClipIndex = props.recorder.recordings.findIndex(
      (r) => r.selected === true,
    );

    if (selectedClipIndex >= 0) {
      MyAlertBoxController.show(
        MyAlertBoxController.ACTIONS_NO_DISCARD,
        'Clip will be discarded permanently',
        (result) => {
          if (result === MyAlertBoxController.RESULTS.DISCARD) {
            let clip = props.recorder.recordings[selectedClipIndex];

            MyRecordingController.removeRecordedClipById(clip._id);
          }
        },
      );
    }
  };

  return (
    <View style={{padding: 10, width}}>
      <View
        style={{
          justifyContent: 'center',
          marginBottom: 4,
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <MyTextIconButton
            onPress={() => handleDeleteSelectedClip()}
            size={dragging ? 50 : 35}>
            {/* <RedoSVG size={30} /> */}
            <TrashSVG />
          </MyTextIconButton>
          <MyTextIconButton onPress={() => false}>
            <Icon
              name="redo"
              size={16}
              style={{transform: [{rotateZ: '-70deg'}]}}
              color="white"
            />
          </MyTextIconButton>
          <View style={{width: 30}} />
          <MyTextIconButton style={{alignSelf: 'center'}} onPress={() => false}>
            <SeasorWhiteSVG />
          </MyTextIconButton>
          <MyTextIconButton style={{alignSelf: 'center'}} onPress={() => false}>
            <AddSnapSVG />
          </MyTextIconButton>
        </View>
      </View>
      <View
        onLayout={({nativeEvent}) => {
          setContainerHeight(nativeEvent.layout.height);
        }}
        style={{
          backgroundColor: DARK_GRAY,
          padding: 10,
          borderRadius: 10,
          justifyContent: 'space-between',
        }}>
        <View>
          <ScrollView
            ref={timeLineScrollViewRef}
            scrollEnabled={true}
            horizontal
            showsHorizontalScrollIndicator={false}>
            {props.recorder.recordings.map((clip, index) => (
              <SingleClip
                key={`${index}${clip._id}`}
                {...{
                  clip,
                  index,
                  timelineSize: props.recorder.recordings.length,
                  containerHeight: containerHeight,
                  onPress: (clip) => {
                    MyRecordingController.toggleVideoClipSelected(clip._id);
                    scrollToIndex(index);
                    if (clip.selected) {
                      MyEditingController.setPlayingMode('full');
                    } else {
                      MyEditingController.setPlayingMode('clip');
                    }
                  },
                  onDragging: (value) => setDragging(value),
                }}
              />
            ))}
          </ScrollView>
        </View>
        <View style={{justifyContent: 'center', alignItems: 'center'}}>
          <View
            style={{
              height: 10,
              marginTop: 7,
              width: '100%',
              borderRadius: 10,
              backgroundColor: LIGHT_GRAY,
            }}
          />
        </View>
      </View>
    </View>
  );
};
const mapStateToProps = (state) => ({
  recorder: state.EditorReducer.recorder,
});
export default connect(mapStateToProps, null)(VideoClipsTimeline);
