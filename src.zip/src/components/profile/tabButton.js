import React, {Component} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';

const TabButton = ({title, selected, width, onPress, onLongPress}) => {
  const isSelected = selected;

  return (
    <TouchableOpacity
      onPress={onPress ? onPress : () => false}
      onLongPress={onLongPress ? onLongPress : () => false}
      style={{
        paddingLeft: 10,
        paddingRight: 10,
        height: 25,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 50,
        backgroundColor: isSelected ? WHITE_COLOR : SECONDRY_BLACK,
      }}>
      <Text
        style={{
          color: isSelected ? SECONDRY_BLACK : WHITE_COLOR,
          fontWeight: 'bold',
        }}>
        {title}
      </Text>
    </TouchableOpacity>
  );
};
export default TabButton;
