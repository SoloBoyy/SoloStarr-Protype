import React, {Component} from 'react';
import {StyleSheet, View, ScrollView, TouchableOpacity} from 'react-native';
import MoodSVG from './Images/moodImage';
import {SECONDRY_BLACK} from '../../themes/colors';

export default class SoundMoodComponent extends Component {
  render() {
    return (
      <View style={styles.container}>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          <View style={styles.viewStyle}>
            <MoodSVG />
          </View>
          <View style={styles.viewStyle}>
            <MoodSVG />
          </View>
          <View style={styles.viewStyle}>
            <MoodSVG />
          </View>
          <View style={styles.viewStyle}>
            <MoodSVG />
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    height: 100,
    width: '85%',
    alignSelf: 'center',
    backgroundColor: SECONDRY_BLACK,
    flexDirection: 'row',
  },
  viewStyle: {
    height: 100,
    width: 100,
    justifyContent: 'center',
    marginRight: 10,
  },
});
