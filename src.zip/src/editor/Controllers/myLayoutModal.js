class MyLayoutModal {
  static SIDE_BAR_CONTROLS = 'SIDE_BAR_CONTROLS';
  static H_C_TABS = 'H_C_TABS';
  static H_L_CROSS = 'H_L_CROSS';
  static H_L_ARROW_LEFT = 'H_L_ARROW_LEFT';
  static H_R_CHECK = 'H_R_CHECK';
  static H_RECORDING_BAR = 'H_RECORDING_BAR';
  static F_L_UNDO = 'F_L_UNDO';
  static F_C_CAPTURE_INITIAL = 'F_C_CAPTURE_INITIAL';
  static F_R_NEXT_ARROW = 'F_R_NEXT_ARROW';
  static CAM_ZOOM_SCROLL_BAR = 'CAM_ZOOM_SCROLL_BAR';
  static F_VIDEO_CLIPS_TIMELINE = 'F_VIDEO_CLIPS_TIMELINE';
  constructor() {
    this.SIDE_BAR_CONTROLS = false;
    this.H_C_TABS = false;
    this.H_L_CROSS = false;
    this.H_R_CHECK = false;
    this.H_RECORDING_BAR = false;
    this.CAM_ZOOM_SCROLL_BAR = false;
    this.H_L_ARROW_LEFT = false;
    this.F_L_UNDO = false;
    this.F_C_CAPTURE_INITIAL = false;
    this.F_R_NEXT_ARROW = false;
    this.F_VIDEO_CLIPS_TIMELINE = false;

    this.enableAll = () => {
      this.SIDE_BAR_CONTROLS = true;
      this.H_C_TABS = true;
      this.H_L_CROSS = true;
      this.H_R_CHECK = true;
      this.H_RECORDING_BAR = true;
      this.CAM_ZOOM_SCROLL_BAR = true;
      this.F_L_UNDO = true;
      this.F_C_CAPTURE_INITIAL = true;
      this.F_R_NEXT_ARROW = true;
      this.H_L_ARROW_LEFT = true;
      this.F_VIDEO_CLIPS_TIMELINE = true;

      return this;
    };

    this.setEnabled = (key) => {
      this[key] = true;
      return this;
    };
    this.setDisabled = (key) => {
      this[key] = false;
      return this;
    };
  }
}
export default MyLayoutModal;
