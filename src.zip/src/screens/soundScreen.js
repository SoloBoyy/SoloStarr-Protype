import React, {Component} from 'react';
import {View, Text, StatusBar} from 'react-native';
import PopularTabPage from '../components/sounds/popularTabPage';
import BrowseTabPage from '../components/sounds/browseTabPage';
import SavedTabPage from '../components/sounds/savedTabPage';
import SearchTabPage from '../components/sounds/searchTabPage';
import SoundHeaderContainer from '../components/sounds/soundsHeaderContainer';
import {SECONDRY_BLACK} from '../themes/colors';
import SearchSoundBox from '../components/sounds/searchSoundBox';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import MyTabBar from '../components/profile/myTabBar';
import ImagePicker from 'react-native-image-crop-picker';
const Tab = createMaterialTopTabNavigator();

class SoundScreen extends Component {
  state = {
    isSearchEnabled: false,
  };
  _handlePickVideo = () => {
    ImagePicker.openPicker({
      mediaType: 'video',
    })
      .then((video) => {
        console.log(video);
      })
      .catch((Err) => console.log('Error in picking '));
  };
  render() {
    return (
      <View style={{flex: 1}}>
        <StatusBar hidden={false} backgroundColor={SECONDRY_BLACK} />
        <SoundHeaderContainer onPressRight={this._handlePickVideo}>
          <SearchSoundBox
            isSearchMode={this.state.isSearchEnabled}
            onChangeMode={(value) => this.setState({isSearchEnabled: value})}
          />
        </SoundHeaderContainer>

        <Tab.Navigator
          gestureHandlerProps={{enabled: false}}
          sceneContainerStyle={{backgroundColor: SECONDRY_BLACK}}
          style={{backgroundColor: SECONDRY_BLACK}}
          tabBar={(props) => (
            <MyTabBar
              {...props}
              onChange={(value) => {
                console.log(value);
              }}
            />
          )}>
          <Tab.Screen
            name="Browse"
            children={() => (
              <BrowseTabPage isSearchEnabled={this.state.isSearchEnabled} />
            )}
          />
          <Tab.Screen
            initialParams
            name="Popular"
            children={() => (
              <PopularTabPage isSearchEnabled={this.state.isSearchEnabled} />
            )}
          />
          <Tab.Screen
            name="Saved"
            children={() => (
              <SavedTabPage isSearchEnabled={this.state.isSearchEnabled} />
            )}
          />
        </Tab.Navigator>

        {/* <PopularTabPage isSearchEnabled={true} /> */}
        {/* <BrowseTabPage isSearchEnabled={false} /> */}
        {/* <SavedTabPage isSearchEnabled={false} /> */}
        {/* <SavedTabPage isSearchEnabled={false} /> */}
      </View>
    );
  }
}

export default SoundScreen;
