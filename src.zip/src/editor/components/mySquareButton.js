import React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';
import {PRIMARY_RED} from '../../themes/colors';
const MySquareButton = (props) => {
  const title = props.title ? props.title : 'btn title';

  return (
    <TouchableOpacity
      activeOpacity={1}
      style={Styles.container}
      onPress={props.onPress ? () => props.onPress() : () => false}>
      <Text style={{color: 'white'}}>{title}</Text>
    </TouchableOpacity>
  );
};
export default MySquareButton;

const Styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 45,
    backgroundColor: PRIMARY_RED,
    borderRadius: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
