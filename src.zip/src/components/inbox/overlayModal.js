import React, {PureComponent} from 'react';
import {View, Text, Modal} from 'react-native';

class OverlayModal extends PureComponent {
  state = {};
  render() {
    const visible = this.props.visible ? true : false;
    return (
      <Modal
        key={25}
        animationType="none"
        transparent={true}
        visible={visible}
        onRequestClose={() => {
          if (this.props.setVisible) {
            this.props.setVisible(false);
          }
        }}>
        <View key={26} style={{flex: 1, backgroundColor: 'rgba(0,0,0, 0.3)'}}>
          {this.props.children}
        </View>
      </Modal>
    );
  }
}

export default OverlayModal;
