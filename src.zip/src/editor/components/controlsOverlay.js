import React, {Component, useState, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import SideControls from './sideControls';
import Popover, {PopoverPlacement} from 'react-native-popover-view';

import MyTextIconButton from './myTextIconButton';
import HeaderOverlay from './headerOverlay';
import FooterOverlay from './overlayFooter';
import VerticalScrollOverlay from './verticalScrollOverlay';
import {connect} from 'react-redux';
import MyLayoutManager from '../Controllers/layoutManager';
import CountDown from './countDown';
import MyRecordingController from '../Controllers/recordingConroller';
import MyLayoutModal from '../Controllers/myLayoutModal';
import BarSelect from './quickControls/barSelect';
import MyButton from './myButton';
import {goBack} from '../../navigator';
import OverlayModal from './overlayModal';
// import {stat} from 'react-native-fs';

const MyHorizonButton = (props) => {
  const [btnsVisible, setBtnsVisible] = useState(false);
  const [closeBtnCords, setCloseBtnCods] = useState({
    top: 0,
    left: 0,
  });
  const closeBtnRef = useRef();
  return (
    <>
      <TouchableOpacity
        onPress={() => {
          setBtnsVisible(!btnsVisible);
        }}
        ref={closeBtnRef}
        onLayout={(e) => {
          closeBtnRef.current.measure((x, y, width, height, pageX, pageY) => {
            //   console.log(
            //     `\n>X: ${x}, Y: ${y} \n>WIDTH: ${width}, HEIGHT: ${height} \n>PAGE-X: ${pageX}, PAGE-Y: ${pageY}`,
            //   );
            setCloseBtnCods({top: pageY, left: pageX});
          });
        }}>
        <MyButton
          onPress={() => {
            setBtnsVisible(!btnsVisible);
          }}
          name="times"
        />
      </TouchableOpacity>
      <Popover
        backgroundStyle={{backgroundColor: 'transparent'}}
        popoverStyle={{height: 100, width: 100, backgroundColor: 'transparent'}}
        placement={PopoverPlacement.BOTTOM}
        from={closeBtnRef}
        key={25}
        isVisible={btnsVisible}
        onRequestClose={() => {
          setBtnsVisible(false);
        }}>
        <View>
          <View style={{height: 20}} />
          <TouchableOpacity
            onPress={() => {
              setBtnsVisible(false);
              goBack();
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton onPress={() => goBack()} name="times" color="red" />
            <Text style={{color: 'white'}}>{`  Delete`}</Text>
          </TouchableOpacity>
          <View style={{height: 15}} />
          <TouchableOpacity
            onPress={() => {
              setBtnsVisible(!btnsVisible);
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton name="redo" />
            <Text style={{color: 'white'}}>{`  Start Over`}</Text>
          </TouchableOpacity>
        </View>
      </Popover>
      {false ? (
        <View>
          <View style={{height: 10}} />
          <TouchableOpacity
            onPress={() => {
              goBack();
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton onPress={() => goBack()} name="times" color="red" />
            <Text style={{color: 'white'}}>{`  Delete`}</Text>
          </TouchableOpacity>
          <View style={{height: 15}} />
          <TouchableOpacity
            onPress={() => {
              setBtnsVisible(!btnsVisible);
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton name="redo" />
            <Text style={{color: 'white'}}>{`  Start Over`}</Text>
          </TouchableOpacity>
        </View>
      ) : (
        false
      )}
    </>
  );
};

class ControlsOverlay extends Component {
  state = {
    timeoutValue: 0,
  };
  componentDidMount() {
    MyRecordingController.onAddTimeOutValueListner((value) => {
      this.setState({timeoutValue: value});
    });
  }
  render() {
    const {width, height} = Dimensions.get('window');
    const {editorLayoutMode} = this.props;
    return (
      <View style={[Styles.container, {width, height}]}>
        <View style={Styles.headerContainer}>
          <HeaderOverlay />
        </View>
        {editorLayoutMode.H_L_CROSS ? (
          <View style={{position: 'absolute', top: 20, left: 20}}>
            <MyHorizonButton />
          </View>
        ) : (
          false
        )}
        <View style={Styles.centerContainer}>
          <View style={Styles.rightControlsBar}>
            {editorLayoutMode.SIDE_BAR_CONTROLS ? <SideControls /> : false}

            {editorLayoutMode.CAM_ZOOM_SCROLL_BAR ? (
              <VerticalScrollOverlay />
            ) : (
              false
            )}
          </View>
          <View style={Styles.playerOverlayContainer}>
            {!this.props.timerVisible ? (
              false
            ) : (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <CountDown value={this.state.timeoutValue} />
              </View>
            )}

            {this.props.recordingSpeedVisible ? (
              <View
                style={{
                  flex: 1,
                  alignItems: 'flex-end',
                  justifyContent: 'center',
                  alignSelf: 'center',
                  flexDirection: 'row',
                }}>
                <View style={{width: 48}} />
                <BarSelect
                  selectedValue={this.props.recordingSpeed}
                  onSelect={(opt) =>
                    MyLayoutManager.setRecordingSpeedValue(opt.value)
                  }
                  options={[
                    {_id: 1, value: 0.5, title: '0.5x', selected: false},
                    {_id: 2, value: 1, title: '1x', selected: false},
                    {_id: 3, value: 2, title: '2x', selected: false},
                    {_id: 4, value: 3, title: '3x', selected: false},
                  ]}
                />
              </View>
            ) : (
              false
            )}
          </View>
        </View>
        <View style={Styles.footerContainer}>
          <FooterOverlay />
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  editorLayoutMode: state.EditorReducer.editorLayoutMode,
  timerVisible: state.EditorReducer.timerVisible,
  recordingSpeedVisible: state.EditorReducer.recordingSpeedVisible,
  recordingSpeed: state.EditorReducer.recordingSpeed,
});
export default connect(mapStateToProps, null)(ControlsOverlay);

const Styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 999,
  },
  centerContainer: {
    flex: 1,
    flexDirection: 'row-reverse',
  },
  headerContainer: {
    width: '100%',
    height: 65,
    backgroundColor: 'transparent',
    paddingLeft: 18,
    paddingRight: 18,
  },
  playerOverlayContainer: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  rightControlsBar: {
    backgroundColor: 'transparent',
    width: 48,
    height: '100%',
    alignSelf: 'flex-end',
    flexDirection: 'column',
  },
  footerContainer: {
    width: '100%',
    height: 100,
    backgroundColor: 'transparent',
    paddingLeft: 48,
    paddingRight: 48,
  },
});
