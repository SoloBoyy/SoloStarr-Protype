import {
  SET_EDITOR_MODE,
  ON_ADD_TIMER_RECORDER,
  ADD_STEP_RECORDING,
  SET_EDITOR_LAYOUT_MODE,
  SET_MODE,
  REMOVE_LAST_RECORDED_CLIP,
  REMOVE_RECORDED_CLIP,
  SET_RECORDING_BTN_ENABLED,
  SET_BOTTOM_MENU_MODE,
  SET_KEY_VALUE,
  SET_EDITOR_KEY_VALUE,
  SET_LOADER_KEY_VALUE,
  UPDATE_RECOORDED_CLIP,
  TOGGLE_RECORDING_SELECTED,
  UPDATE_RECOORDED_CLIP_VALUE,
  SET_VIDEO_PLAYING_MODE,
  HANDLE_PLAY_NEXT_CLIP,
  SET_RECORDER_KEY_VALUE,
} from '../../editor/actionTypes';
import produce from 'immer';
import MyLayoutModal from '../../editor/Controllers/myLayoutModal';

const state = {
  mode: '', /// VIDEO OR EDITOR
  editorMode: '', /// MULTIPLE SPECIFIC TO VIDEO OR EDITR
  recordingBtnEnabled: false,
  bottomOptionMenuEnable: false,
  timerTimeout: {_id: 1, title: '0s', value: 0},
  timerVisible: false,
  recordingSpeed: {_id: 2, value: 1, title: '1x'},
  timerDefaultValue: 0,
  recordingSpeedVisible: false,
  flashMode: 0,
  alertBox: {
    message: '',
    actions: [],
  },
  alerBoxVisible: false,
  editorLayoutMode: new MyLayoutModal(), /// RELATED TO RENDERING COMPONENTS
  recorder: {
    durationPeak: 60,
    durationRemaining: 60,
    durationSeek: 0,
    recordings: [],
    camZoom: 0,
  },
  editor: {
    initialVideoSource: null,
    playingSource: null,
    playingMode: 'clip', /// clip, full
    playingSpeed: 1,
    videoRepeate: false,
  },
  isChangeSaved: false,
  loader: {
    visible: false,
    message: '',
  },
};
const EditorReducer = (mState = {...state}, action) => {
  switch (action.type) {
    case SET_RECORDER_KEY_VALUE:
      return produce(mState, (draftState) => {
        draftState.recorder[action.payload.key] = action.payload.value;
      });

    case SET_VIDEO_PLAYING_MODE:
      return produce(mState, (draftState) => {
        draftState.editor.playingMode = action.payload;
        for (
          let index = 0;
          index < draftState.recorder.recordings.length;
          index++
        ) {
          draftState.recorder.recordings[index].playing = false;
        }

        if (action.payload === 'full') {
          if (draftState.recorder.recordings.length > 0) {
            draftState.editor.playingSource =
              draftState.recorder.recordings[0].source;
            draftState.editor.playingSpeed =
              draftState.recorder.recordings[0].recordingSpeed;

            draftState.recorder.recordings[0].playing = true;
          } else {
            draftState.editor.playingSource = null;
            draftState.editor.playingSpeed = 1;
          }
          if (draftState.recorder.recordings.length === 1) {
            console.log(`MODE: ${action.payload} TRUE`);
            draftState.editor.videoRepeate = true;
          } else {
            draftState.editor.videoRepeate = false;
            console.log(`MODE: ${action.payload} FALSE`);
          }
        } else {
          draftState.editor.videoRepeate = true;
          console.log(`MODE: ${action.payload} TRUE`);
        }
      });
    case HANDLE_PLAY_NEXT_CLIP:
      return produce(mState, (draftState) => {
        for (
          let index = 0;
          index < draftState.recorder.recordings.length;
          index++
        ) {
          const rec = draftState.recorder.recordings[index];
          if (rec.playing) {
            draftState.recorder.recordings[index].playing = false;
            if (index === draftState.recorder.recordings.length - 1) {
              draftState.editor.playingSource =
                draftState.recorder.recordings[0].source;

              draftState.editor.playingSpeed =
                draftState.recorder.recordings[0].recordingSpeed;

              draftState.recorder.recordings[0].playing = true;
            } else {
              draftState.editor.playingSource =
                draftState.recorder.recordings[index + 1].source;

              draftState.editor.playingSpeed =
                draftState.recorder.recordings[index + 1].recordingSpeed;

              draftState.recorder.recordings[index + 1].playing = true;
            }
            break;
          }
        }
      });

    case SET_MODE:
      return produce(mState, (draftState) => {
        draftState.mode = action.payload;
      });

    case SET_EDITOR_MODE:
      return produce(mState, (draftState) => {
        draftState.editorMode = action.payload;
      });

    case SET_EDITOR_LAYOUT_MODE:
      return produce(mState, (draftState) => {
        draftState.editorLayoutMode = action.payload;
      });
    case ON_ADD_TIMER_RECORDER:
      return produce(mState, (draftState) => {
        draftState.recorder.durationSeek += action.payload;
      });
    case ADD_STEP_RECORDING:
      return produce(mState, (draftState) => {
        console.log('ADD_STEP_RECORDING');
        console.log(action.payload);
        draftState.recorder.recordings.push(action.payload);
        let spentTime = 0;
        for (
          let index = 0;
          index < draftState.recorder.recordings.length;
          index++
        ) {
          const recOrd = draftState.recorder.recordings[index];
          draftState.recorder.recordings[index].selected = false;
          spentTime += recOrd.duration;
        }

        draftState.recorder.durationSeek = spentTime;
        draftState.recorder.durationRemaining =
          draftState.recorder.durationPeak - spentTime;
      });

    case REMOVE_LAST_RECORDED_CLIP:
      return produce(mState, (draftState) => {
        if (draftState.recorder.recordings.length > 0) {
          let lastRecording =
            draftState.recorder.recordings[
              draftState.recorder.recordings.length - 1
            ];
          draftState.recorder.durationSeek -= lastRecording.duration;
          draftState.recorder.durationRemaining += lastRecording.duration;
          draftState.recorder.recordings.pop();
        }
      });
    case REMOVE_RECORDED_CLIP:
      return produce(mState, (draftState) => {
        if (draftState.recorder.recordings.length > 0) {
          let _id = action.payload;
          let recordingRMIndex = draftState.recorder.recordings.findIndex(
            (r) => r._id === _id,
          );
          if (recordingRMIndex >= 0) {
            let recordingRM = draftState.recorder.recordings[recordingRMIndex];
            draftState.recorder.durationSeek -= recordingRM.duration;
            draftState.recorder.durationRemaining += recordingRM.duration;
            draftState.recorder.recordings = draftState.recorder.recordings.filter(
              (r) => r._id !== _id,
            );
            // if (draftState.recorder.recordings.length > 0) {
            //   draftState.editor.playingMode = 'full';
            //   draftState.editor.playingSource =
            //     draftState.recorder.recordings[0].source;
            //   draftState.recorder.recordings[0].playing = true;
            // }
          }
        }
      });

    case TOGGLE_RECORDING_SELECTED:
      return produce(mState, (draftState) => {
        if (draftState.recorder.recordings.length > 0) {
          let _id = action.payload;
          for (
            let index = 0;
            index < draftState.recorder.recordings.length;
            index++
          ) {
            const clip001 = draftState.recorder.recordings[index];
            if (clip001._id === _id) {
              draftState.recorder.recordings[index].selected = !draftState
                .recorder.recordings[index].selected;
              //// TODO: change recording[index].source  => recording[index].processedSource after comming processing video
              draftState.editor.playingSource =
                draftState.recorder.recordings[index].source;
              draftState.editor.playingSpeed =
                draftState.recorder.recordings[index].recordingSpeed;
            } else {
              draftState.recorder.recordings[index].selected = false;
            }
          }
          let isAnySelectedClip0Index = draftState.recorder.recordings.findIndex(
            (r) => r.selected === true,
          );
          if (isAnySelectedClip0Index < 0) {
            // draftState.editor.playingSource =
            //   draftState.editor.initialVideoSource;

            draftState.editor.playingMode = 'full';
            draftState.editor.playingSource =
              draftState.recorder.recordings[0].source;
            draftState.editor.playingSpeed =
              draftState.recorder.recordings[0].recordingSpeed;
            draftState.recorder.recordings[0].playing = true;
          } else {
            draftState.editor.playingMode = 'clip';
          }
        }
      });

    case UPDATE_RECOORDED_CLIP:
      return produce(mState, (draftState) => {
        let {clipId, processedSource} = action.payload;
        console.log(
          `Updating Clip ${clipId} with source uri ${processedSource.uri}`,
        );
        let pusIndex = draftState.recorder.recordings.findIndex(
          (r) => r._id === clipId,
        );
        if (pusIndex >= 0) {
          draftState.recorder.recordings[
            pusIndex
          ].processedSource = processedSource;
          draftState.recorder.recordings[pusIndex].isProcessed = true;
        } else {
          console.log(`Clip With Id ${clipId} not found`);
        }
      });
    case UPDATE_RECOORDED_CLIP_VALUE:
      return produce(mState, (draftState) => {
        const recordedClip001 = action.payload;
        let recordedClipIndex001 = draftState.recorder.recordings.findIndex(
          (r) => r._id === recordedClip001._id,
        );
        if (recordedClipIndex001 >= 0) {
          draftState.recorder.recordings[
            recordedClipIndex001
          ] = recordedClip001;
        } else {
          console.log('No Clip found to update');
          console.log(recordedClipIndex001);
        }
      });

    case SET_RECORDING_BTN_ENABLED:
      return produce(mState, (draftState) => {
        draftState.recordingBtnEnabled = action.payload;
      });

    case SET_BOTTOM_MENU_MODE:
      return produce(mState, (draftState) => {
        draftState.bottomOptionMenuEnable = action.payload;
      });

    case SET_KEY_VALUE:
      return produce(mState, (draftState) => {
        console.log(
          `Key, ${action.payload.key}, value: ${action.payload.value}`,
        );
        draftState[action.payload.key] = action.payload.value;
      });

    case SET_EDITOR_KEY_VALUE:
      return produce(mState, (draftState) => {
        draftState.editor[action.payload.key] = action.payload.value;
      });

    case SET_LOADER_KEY_VALUE:
      return produce(mState, (draftState) => {
        draftState.loader[action.payload.key] = action.payload.value;
      });

    default:
      // console.log(mState);
      return {...mState};
  }
};
export default EditorReducer;
const clone = (obj) => {
  let newObj = {};
  for (let key in obj) {
    if (typeof obj[key] === 'object') {
      newObj = {...newObj, ...clone(obj[key])};
    } else {
      newObj = {...newObj, ...obj[key]};
    }
  }

  return newObj;
};
