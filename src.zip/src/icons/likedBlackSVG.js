import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const LikedBlackSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="16.286" height="14.25" viewBox="0 0 16.286 14.25">
  <path fill="#111111" id="Icon_awesome-heart" data-name="Icon awesome-heart" d="M14.7,3.222a4.35,4.35,0,0,0-5.935.433L8.142,4.3l-.627-.646A4.35,4.35,0,0,0,1.58,3.222a4.567,4.567,0,0,0-.315,6.613L7.42,16.19a1,1,0,0,0,1.441,0l6.155-6.355A4.565,4.565,0,0,0,14.7,3.222Z" transform="translate(0.001 -2.248)"/>
</svg>
`}
    />
  );
};
export default LikedBlackSVG;
