import React, {useState} from 'react';
import {View, Text} from 'react-native';
import MyTextIconButton from './myTextIconButton';
import FilterSVG from '../icons/filterSVG';
import NotesSVG from '../icons/notesSVG';
import LayerSVG from '../icons/layersSVG';
import FlashSVG from '../icons/flashSVG';
import SoundSVG from '../icons/soundSVG';
import SpeedSVG from '../icons/speedSVG';
import TimerSVG from '../icons/timerSVG';
import UploadsSVG from '../icons/uploadsSVG';
import MyLayoutManager from '../Controllers/layoutManager';
import {useSelector} from 'react-redux';
import MyRecordingController from '../Controllers/recordingConroller';
import FiltersScreen from '../../screens/filtersScreen';

const SideControls = (props) => {
  const buttonSize = 30;
  const topMargin = 5;
  const [filtersVisible, setFilterVisible] = useState(false);
  const timerTimeoutValue = useSelector(
    (store) => store.EditorReducer.timerTimeout,
  );
  const recordingSpeed = useSelector(
    (store) => store.EditorReducer.recordingSpeed,
  );

  return (
    <View>
      {/* <MyTextIconButton topMargin={topMargin} size={buttonSize} title="Notes">
        <NotesSVG />
      </MyTextIconButton>

      <MyTextIconButton topMargin={topMargin} size={buttonSize} title="Layer">
        <LayerSVG />
      </MyTextIconButton> */}

      <MyTextIconButton
        onPress={() => MyLayoutManager.navigateTo('UploadScreen')}
        topMargin={topMargin}
        size={buttonSize}
        title="Upload">
        <UploadsSVG />
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => MyLayoutManager.navigateTo('SoundScreen')}
        topMargin={topMargin}
        size={buttonSize}
        title="Sound">
        <SoundSVG />
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => setFilterVisible(!filtersVisible)}
        topMargin={topMargin}
        size={buttonSize}
        title="Filters">
        <FilterSVG />
      </MyTextIconButton>

      <FiltersScreen
        onClose={() => setFilterVisible(false)}
        visible={filtersVisible}
      />

      <MyTextIconButton
        onPress={() => {
          MyRecordingController.shiftRecordingSpeedValue(recordingSpeed);
        }}
        topMargin={topMargin}
        size={buttonSize}
        title="Speed">
        {recordingSpeed?.value === 1 ? (
          <SpeedSVG />
        ) : (
          <Text
            style={{
              color: 'white',
              fontSize: 12,
            }}>{`${recordingSpeed?.value}x`}</Text>
        )}
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => {
          MyRecordingController.shiftTimerTimeoutValue(timerTimeoutValue);
        }}
        topMargin={topMargin}
        size={buttonSize}
        title="Timer">
        {timerTimeoutValue?.value === 0 ? (
          <TimerSVG />
        ) : (
          <Text
            style={{
              color: 'white',
              fontSize: 12,
            }}>{`-${timerTimeoutValue?.value}s`}</Text>
        )}
      </MyTextIconButton>

      <MyTextIconButton
        onPress={() => MyLayoutManager.toggleFlashMode()}
        topMargin={topMargin}
        size={buttonSize}
        title="Flash">
        <FlashSVG />
      </MyTextIconButton>
    </View>
  );
};

export default SideControls;
