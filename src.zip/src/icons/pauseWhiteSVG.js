import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const PauseWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="18" height="22.5" viewBox="0 0 18 22.5">
  <g id="Icon_ionic-ios-pause" data-name="Icon ionic-ios-pause" transform="translate(-9 -6.75)">
    <path id="Path_1" data-name="Path 1" d="M14.055,29.25H9.57A.566.566,0,0,1,9,28.688V7.313a.566.566,0,0,1,.57-.562h4.486a.566.566,0,0,1,.57.563V28.688A.566.566,0,0,1,14.055,29.25Z" fill="#fff"/>
    <path id="Path_2" data-name="Path 2" d="M26.43,29.25H21.945a.566.566,0,0,1-.57-.562V7.313a.566.566,0,0,1,.57-.562H26.43a.566.566,0,0,1,.57.563V28.688A.566.566,0,0,1,26.43,29.25Z" fill="#fff"/>
  </g>
</svg>
`}
    />
  );
};
export default PauseWhiteSVG;
