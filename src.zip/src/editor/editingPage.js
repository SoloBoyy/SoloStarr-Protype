import React, {Component} from 'react';
import {View, Text} from 'react-native';
class EditingPage extends Component {
  state = {};
  render() {
    return (
      <View>
        <Text>Editing Page</Text>
      </View>
    );
  }
}

export default EditingPage;
