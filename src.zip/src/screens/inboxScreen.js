import React, {Component} from 'react';
import {View, Text, StatusBar} from 'react-native';
import ActivityTabPage from '../components/inbox/activityTabPage';
import InboxHeader from '../components/inbox/inboxHeader';
import InboxHeaderContainer from '../components/inbox/inboxHeaderContainer';
import MessagesTabPage from '../components/inbox/messagesTabPage';
import {SECONDRY_BLACK} from '../themes/colors';

class InboxScreen extends Component {
  state = {
    selectedTab: 'activity',
  };
  render() {
    const {selectedTab} = this.state;
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar
          hidden={false}
          barStyle="light-content"
          backgroundColor={SECONDRY_BLACK}
        />

        <InboxHeaderContainer {...{navigation: this.props.navigation}}>
          <InboxHeader
            {...{
              navigation: this.props.navigation,
              onSelectTab: (tab) => this.setState({selectedTab: tab}),
              selectedTab: this.state.selectedTab,
            }}
          />
        </InboxHeaderContainer>
        {selectedTab === 'messages' ? (
          <MessagesTabPage navigation={this.props.navigation} />
        ) : (
          <ActivityTabPage navigation={this.props.navigation} />
        )}
      </View>
    );
  }
}

export default InboxScreen;
