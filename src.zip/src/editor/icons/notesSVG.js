import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const NotesSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="26" height="32" viewBox="0 0 26 32">
  <g id="Icon_feather-file-text" data-name="Icon feather-file-text" transform="translate(-5 -2)">
    <path id="Path_1" data-name="Path 1" d="M21,3H9A3,3,0,0,0,6,6V30a3,3,0,0,0,3,3H27a3,3,0,0,0,3-3V12Z" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_2" data-name="Path 2" d="M21,3v9h9" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_3" data-name="Path 3" d="M24,19.5H12" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_4" data-name="Path 4" d="M24,25.5H12" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_5" data-name="Path 5" d="M15,13.5H12" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default NotesSVG;
