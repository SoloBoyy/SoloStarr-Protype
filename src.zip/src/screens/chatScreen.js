import React, {Component} from 'react';
import {View, Text, StatusBar, FlatList} from 'react-native';
import ChatInputBox from '../components/inbox/chatInputBox';
import InboxHeaderContainer from '../components/inbox/inboxHeaderContainer';
import SingleMessage from '../components/inbox/singleMessage';
import {SECONDRY_BLACK} from '../themes/colors';
import ChatHeader from '../components/inbox/chatHeader';
import {connect} from 'react-redux';
import MyInboxController from '../controllers/inboxController';

class ChatScreen extends Component {
  constructor() {
    super();
    this.flatListRef = null;
    this.state = {
      chatId: '',
      messageText: '',
    };
  }

  componentDidMount() {
    let chatId = this.props.route?.params?.chatId;
    console.log(`ChatId: ${chatId}`);
    setTimeout(() => this.flatListRef.scrollToEnd(), 500);
    if (chatId) {
      this.setState({chatId});
    }
  }
  render() {
    let myChat = MyInboxController.getDummy();
    if (this.props.chat) {
      const chatIndex = this.props.chat.findIndex(
        (c) => c._id === this.state.chatId,
      );
      if (chatIndex >= 0) {
        myChat = this.props.chat[chatIndex];
      }
    }

    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar backgroundColor={SECONDRY_BLACK} />
        <InboxHeaderContainer navigation={this.props.navigation}>
          <ChatHeader
            title={myChat.username}
            onPress={() => this.props.navigation.push('ProfileScreen')}
          />
        </InboxHeaderContainer>
        <View style={{height: 15}} />
        <View style={{flex: 1}}>
          <FlatList
            showsVerticalScrollIndicator={false}
            onLayout={() => this.flatListRef.scrollToEnd()}
            ref={(e) => (this.flatListRef = e)}
            data={myChat.messages}
            renderItem={({item, index}) => <SingleMessage message={item} />}
            keyExtractor={(item) => item._id}
          />
        </View>
        <ChatInputBox
          value={this.state.messageText}
          onSubmit={() => {
            MyInboxController.pushMessage(
              this.state.chatId,
              this.state.messageText,
            );
            this.setState({messageText: ''}, () => {
              setTimeout(() => this.flatListRef.scrollToEnd(), 300);
            });
          }}
          onChangeText={(text) => this.setState({messageText: text})}
        />
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  chat: state.InboxReducer.chat,
});

export default connect(mapStateToProps, null)(ChatScreen);
