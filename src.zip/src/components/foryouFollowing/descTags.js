import React from 'react';
import {View, Text, Dimensions} from 'react-native';
import {WHITE_COLOR} from '../../themes/colors';
const {width, height} = Dimensions.get('window');
const tags = ['#solostarapp', '#solostar'];
const DescTags = (props) => {
  return (
    <View style={[{width: width - 70, paddingLeft: 15}, {...props.style}]}>
      <Text style={{fontSize: 13, color: WHITE_COLOR}}>
        In publishing and graphic design, Lorem ipsum is a placeholder text
        commonly used to demonstrate the visual form of a document or a typeface
        without relying on meaningful content
      </Text>
      <Text>
        {tags.map((t) => (
          <Text
            key={t}
            style={{
              color: 'white',
              textDecorationStyle: 'solid',
            }}>
            {t}
          </Text>
        ))}
      </Text>
    </View>
  );
};
export default DescTags;
