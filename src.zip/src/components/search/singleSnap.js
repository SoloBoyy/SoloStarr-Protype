import React from 'react';
import {View, Image, Dimensions} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';

const SingleSnap = (props) => {
  const {width} = Dimensions.get('window');
  const snapWidth = width / 3;
  const borderRadius = 8;
  return (
    <View
      style={{width: snapWidth, height: snapWidth * 1.6, alignItems: 'center'}}>
      <Image
        style={{
          width: '98%',
          height: '98%',
          borderRadius,
          backgroundColor: '#444444',
        }}
        source={props.imageSource}
      />
    </View>
  );
};

export default SingleSnap;
