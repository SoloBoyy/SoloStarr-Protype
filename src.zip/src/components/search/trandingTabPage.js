import React, {useState, useEffect} from 'react';
import {View, Text, FlatList} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import SearchTabPage from '../sounds/searchTabPage';
import SingleSnap from './singleSnap';
const TrandingTapPage = (props) => {
  const [popularItems, setPopularItems] = useState([]);
  const isSearchEnabled = props.isSearchEnabled ? true : false;
  useEffect(() => {
    let items = [];
    for (let index = 0; index < 10; index++) {
      items.push({_id: index});
    }
    setPopularItems(items);
  }, []);

  if (isSearchEnabled) {
    return <SearchTabPage />;
  } else {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <View style={{height: 5}} />
        <FlatList
          showsVerticalScrollIndicator={false}
          data={popularItems}
          numColumns={3}
          renderItem={({item, index}) => <SingleSnap />}
          keyExtractor={(item) =>
            `${item._id}${Math.round(Math.random() * 10000)}`
          }
        />
      </View>
    );
  }
};
export default TrandingTapPage;
