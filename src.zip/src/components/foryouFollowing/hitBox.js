import React, {useState} from 'react';
import {TouchableOpacity, StyleSheet, View} from 'react-native';
import MyForYouController from '../../controllers/forYouController';
import AddWhiteSVG from '../../icons/addWhiteSVG';
import BellWhiteSVG from '../../icons/bellWhiteSVG';
import SearchWhiteSVG from '../../icons/searchWhiteSVG';
import {navigate} from '../../navigator';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
export const SIZE = 50;
const BTNS_BOTTOM_OFFSET = 35;
const FRAME_BOTTOM_OFFSET = 30;
const HitBox = (props) => {
  const [btsEnabled, setBtnsEnabled] = useState(false);

  return (
    <>
      <TouchableOpacity
        onPress={
          props.onPress
            ? () => props.onPress()
            : () => setBtnsEnabled(!btsEnabled)
        }
        style={[
          Styles.container,
          {
            position: 'absolute',
            alignSelf: 'center',
            bottom: FRAME_BOTTOM_OFFSET,
            backgroundColor: WHITE_COLOR,
          },
        ]}
      />

      {/* TOP BUTTON  */}

      {btsEnabled ? (
        <>
          <TouchableOpacity
            onPress={() => {
              MyForYouController.setVideoPlayable(false);
              navigate('EditorNavigator');
            }}
            style={[
              Styles.neighorBtn,
              {
                alignSelf: 'center',
                bottom: BTNS_BOTTOM_OFFSET * 2 + FRAME_BOTTOM_OFFSET + 10,
                backgroundColor: SECONDRY_BLACK,
              },
            ]}>
            <AddWhiteSVG size={25} />
          </TouchableOpacity>

          {/* Left Button */}
          <TouchableOpacity
            onPress={() => {
              MyForYouController.setVideoPlayable(false);

              navigate('InboxNavigator');
            }}
            style={[
              Styles.neighorBtn,
              {
                alignSelf: 'center',
                bottom: BTNS_BOTTOM_OFFSET + FRAME_BOTTOM_OFFSET,
                backgroundColor: SECONDRY_BLACK,
                transform: [{translateX: -SIZE - 10}],
              },
            ]}>
            <BellWhiteSVG size={25} />
          </TouchableOpacity>

          {/* RIGHT BUTTON */}
          <TouchableOpacity
            onPress={() => {
              MyForYouController.setVideoPlayable(false);

              navigate('SearchScreen');
            }}
            style={[
              Styles.neighorBtn,
              {
                alignSelf: 'center',
                bottom: BTNS_BOTTOM_OFFSET + FRAME_BOTTOM_OFFSET,
                backgroundColor: SECONDRY_BLACK,
                transform: [{translateX: SIZE + 10}],
              },
            ]}>
            <SearchWhiteSVG size={25} />
          </TouchableOpacity>
        </>
      ) : (
        false
      )}
    </>
  );
};
export default HitBox;

const Styles = StyleSheet.create({
  container: {
    width: SIZE,
    height: SIZE,
    borderRadius: 50,
    backgroundColor: WHITE_COLOR,
  },
  neighorBtn: {
    width: SIZE,
    height: SIZE,
    borderRadius: 50,
    backgroundColor: WHITE_COLOR,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
