import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import MyForYouController from '../../../controllers/forYouController';
import FeatherSendWhiteSVG from '../../../icons/featherSendWhiteSVG';
import {WHITE_COLOR} from '../../../themes/colors';
import CommentItem from './commentItem';

const AddCommentBox = (props) => {
  const [value, setValue] = useState('');
  const [isReplyBoxVisible, setReplyBoxVisible] = useState(false);
  const isSearchMode = props.isSearchMode ? true : false;
  const textInputRef = useRef();
  useEffect(() => {
    if (props.isReplyBoxVisible) {
      textInputRef.current.focus();
    }
  }, [props.isReplyBoxVisible]);
  return (
    <View
      style={{
        width: '100%',
      }}>
      <View
        style={{
          // flex: 1,
          minHeight: 50,
          backgroundColor: 'black',

          borderRadius: 15,
          paddingLeft: 5,
          paddingRight: 5,
          ...props.style,
        }}>
        {props.isReplyBoxVisible ? (
          <CommentItem onCloseReplyBox={props.onCloseReplyBox} isPreview />
        ) : (
          false
        )}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Icon
            style={{color: WHITE_COLOR, width: 20, paddingLeft: 5}}
            name="comment"
          />
          <TextInput
            placeholderTextColor={WHITE_COLOR}
            ref={textInputRef}
            placeholder={props.placeholder ? props.placeholder : ''}
            onChangeText={(text) => setValue(text)}
            style={{flex: 1, color: 'white', marginBottom: -3}}
          />

          {value !== '' ? (
            <TouchableOpacity
              onPress={() => {
                console.log('Pushing comment...');
                textInputRef.current.blur();
                MyForYouController.pushComment(props.storyId, value);
              }}
              style={{
                width: 40,
                height: 40,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <FeatherSendWhiteSVG />
            </TouchableOpacity>
          ) : (
            <View style={{height: 40}} />
          )}
        </View>
      </View>
    </View>
  );
};
export default AddCommentBox;
