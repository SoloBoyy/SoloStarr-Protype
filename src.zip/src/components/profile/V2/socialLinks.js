import React from 'react';

import {View, Text, TouchableOpacity, Modal} from 'react-native';
import Popover, {PopoverPlacement} from 'react-native-popover-view';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {WHITE_COLOR} from '../../../themes/colors';
const SocialLinksModal = (props) => {
  return (
    <Popover
      backgroundStyle={{backgroundColor: 'transparent'}}
      popoverStyle={{height: 150, width: 35, backgroundColor: 'transparent'}}
      placement={PopoverPlacement.TOP}
      from={props.from}
      key={25}
      isVisible={props.visible ? true : false}
      onRequestClose={() => {
        if (props.setVisible) {
          props.setVisible(false);
        }
      }}>
      <View
        key={27}
        style={{
          width: 150,
          height: 50,
          alignSelf: 'center',
        }}>
        <Text
          key={28}
          style={{
            width: '100%',
            height: '100%',
          }}
          onPress={() => {
            if (props.setVisible) {
              props.setVisible(false);
            }
          }}>{`  `}</Text>
      </View>
      <View
        key={29}
        style={{
          height: 150,
          width: 40,
          position: 'absolute',
          justifyContent: 'space-between',
        }}>
        <TouchableOpacity
          key={30}
          style={{
            width: 35,
            height: 35,
            borderRadius: 50,
            backgroundColor: 'black',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Icon
            key={31}
            style={{fontSize: 23}}
            color={WHITE_COLOR}
            name="instagram"
          />
        </TouchableOpacity>
        <TouchableOpacity
          key={32}
          style={{
            width: 35,
            height: 35,
            borderRadius: 50,
            backgroundColor: 'black',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Icon
            key={33}
            style={{fontSize: 23}}
            color={WHITE_COLOR}
            name="snapchat"
          />
        </TouchableOpacity>
        <TouchableOpacity
          key={34}
          style={{
            width: 35,
            height: 35,
            borderRadius: 50,
            backgroundColor: 'black',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Icon
            key={35}
            style={{fontSize: 23}}
            color={WHITE_COLOR}
            name="youtube"
          />
        </TouchableOpacity>
        <TouchableOpacity
          key={36}
          style={{
            width: 35,
            height: 35,
            borderRadius: 50,
            backgroundColor: 'black',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Icon
            key={37}
            style={{
              fontSize: 23,
              transform: [{rotateZ: '45deg'}, {scaleX: 0.7}],
            }}
            color={WHITE_COLOR}
            name="thumbtack"
          />
        </TouchableOpacity>
      </View>
    </Popover>
  );
};

export default SocialLinksModal;
