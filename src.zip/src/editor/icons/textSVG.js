import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const TextSVG = (props) => {
  const size = props.size ? props.size : 50;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="131" height="298" viewBox="0 0 131 298">
  <text id="T" transform="translate(0 229)" fill="#fff" font-size="240" font-family="Sniglet-Regular, Sniglet"><tspan x="0" y="0">T</tspan></text>
</svg>
`}
    />
  );
};
export default TextSVG;
