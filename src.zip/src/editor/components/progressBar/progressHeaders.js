import React, {Component} from 'react';
import {View, StyleSheet, Text} from 'react-native';
import SingleProgress from './singleProgress';
import StaticBar from './staticBar';
import {connect} from 'react-redux';
import MyRecordingController from '../../Controllers/recordingConroller';
class ProgressHeaders extends Component {
  state = {
    clockValue: 0,
  };
  componentDidMount() {
    MyRecordingController.onAddClockValueListner((clockValue) => {
      this.setState({clockValue});
    });
  }
  render() {
    const {props} = this;
    return (
      <View key={'PH0'} style={Styles.container}>
        {props.recorder.recordings.map((r) => (
          <StaticBar
            key={r._id}
            peak={props.recorder.durationPeak}
            seek={props.recorder.durationSeek}
            clipsCount={props.recorder.recordings.length}
            pIndex={r.pIndex}
            duration={r.duration}
          />
        ))}
        <View key={'PH1'} style={{flex: 1}}>
          <SingleProgress
            key={'PH0-0'}
            peak={props.recorder.durationRemaining}
            seek={this.state.clockValue}
            clipsCount={props.recorder.recordings.length}
          />
        </View>
      </View>
    );
  }
}
const Styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 10,
    flexDirection: 'row',
    borderRadius: 20,
  },
});

const mapStateToProps = (state) => ({
  recorder: state.EditorReducer.recorder,
});

export default connect(mapStateToProps, null)(ProgressHeaders);
