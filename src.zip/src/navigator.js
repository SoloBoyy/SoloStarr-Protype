import React from 'react';
import {
  createStackNavigator,
  CardStyleInterpolators,
} from '@react-navigation/stack';
import {NavigationContainer} from '@react-navigation/native';
import videoEditingScreen from './editor/screens/videoEditingScreen';
import videoMakingScreen from './editor/screens/videoMakingScreen';
import chatScreen from './screens/chatScreen';
import FollowerScreen from './screens/followersScreen';
import FollowingAndForYouScreen from './screens/followingForYouScreen';
import InboxScreen from './screens/inboxScreen';
import NewMessageScreen from './screens/newMessageScreen';
import SearchScreen from './screens/searchScreen';
import SoundScreen from './screens/soundScreen';
import BoostCoinBuyScreen from './screens/boostCoinBuyScreen';
import BoostCoinPermissionScreen from './screens/boostCoinPermissionScreen';
import UserProfileScreenNew from './screens/userProfileScreenNew';
import ImageEditingScreen from './screens/imageEditingScreen';
import ImageCropScreen from './screens/imageCropScreen.js';
import UploadScreen from './screens/uploadScreen';
import UserMessageScreen from './screens/userMessageScreen';
const StackNavigator = createStackNavigator();
export const isReadyRef = React.createRef();

export const navigationRef = React.createRef();

export function navigate(name, params) {
  if (isReadyRef.current && navigationRef.current) {
    // Perform navigation if the app has mounted
    navigationRef.current.navigate(name, params);
  } else {
    // You can decide what to do if the app hasn't mounted
    // You can ignore this, or add these actions to a queue you can call later
  }
}

export function goBack() {
  if (isReadyRef.current && navigationRef.current) {
    // Perform navigation if the app has mounted
    navigationRef.current.goBack();
  } else {
    // You can decide what to do if the app hasn't mounted
    // You can ignore this, or add these actions to a queue you can call later
  }
}

const InboxNavigator = () => {
  return (
    <StackNavigator.Navigator initialRouteName="InboxScreen" headerMode="none">
      <StackNavigator.Screen name="InboxScreen" component={InboxScreen} />
      <StackNavigator.Screen
        name="ChatScreen"
        component={chatScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: 'horizontal',
          cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
        }}
      />
      <StackNavigator.Screen
        name="NewMessageScreen"
        component={NewMessageScreen}
        options={{
          gestureEnabled: true,
          gestureDirection: 'horizontal',
          cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
        }}
      />
    </StackNavigator.Navigator>
  );
};

const EditorNavigator = () => (
  <StackNavigator.Navigator
    headerMode="none"
    initialRouteName="VideoMakingScreen">
    <StackNavigator.Screen
      name="VideoMakingScreen"
      component={videoMakingScreen}
      options={{
        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      }}
    />
    <StackNavigator.Screen
      name="VideoEditingScreen"
      component={videoEditingScreen}
      options={{
        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      }}
    />
    <StackNavigator.Screen
      name="SoundScreen"
      component={SoundScreen}
      options={{
        gestureEnabled: true,
        gestureDirection: 'horizontal',
        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      }}
    />
    <StackNavigator.Screen
      name="UploadScreen"
      component={UploadScreen}
      options={{
        gestureEnabled: true,
        gestureDirection: 'horizontal',
        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      }}
    />
  </StackNavigator.Navigator>
);

const AppNavigator = () => {
  return (
    <NavigationContainer
      ref={navigationRef}
      onReady={() => {
        isReadyRef.current = true;
      }}>
      <StackNavigator.Navigator
        headerMode="none"
        initialRouteName="FollowingAndForYouScreen">
        <StackNavigator.Screen name="FollowScreen" component={FollowerScreen} />
        <StackNavigator.Screen
          name="FollowingAndForYouScreen"
          component={FollowingAndForYouScreen}
        />
        <StackNavigator.Screen
          name="BoostCoinPermissionScreen"
          component={BoostCoinPermissionScreen}
          options={{
            gestureEnabled: true,
            gestureDirection: 'horizontal',
            cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
          }}
        />
        <StackNavigator.Screen
          name="ImageEditingScreen"
          component={ImageEditingScreen}
          options={{
            gestureEnabled: true,
            gestureDirection: 'horizontal',
            cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
          }}
        />

        <StackNavigator.Screen
          name="ImageCropingScreen"
          component={ImageCropScreen}
          options={{
            gestureEnabled: true,
            gestureDirection: 'horizontal',
            cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
          }}
        />
        <StackNavigator.Screen
          name="BoostCoinBuyScreen"
          component={BoostCoinBuyScreen}
          options={{
            gestureEnabled: true,
            gestureDirection: 'horizontal',
            cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
          }}
        />
        <StackNavigator.Screen
          name="UserMessageScreen"
          component={UserMessageScreen}
          options={{
            gestureEnabled: true,
            gestureDirection: 'horizontal',
            cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
          }}
        />
        <StackNavigator.Screen name="SearchScreen" component={SearchScreen} />
        <StackNavigator.Screen
          name="InboxNavigator"
          component={InboxNavigator}
        />
        <StackNavigator.Screen
          name="EditorNavigator"
          component={EditorNavigator}
        />
        <StackNavigator.Screen
          name="UserProfileScreen"
          component={UserProfileScreenNew}
        />
      </StackNavigator.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
