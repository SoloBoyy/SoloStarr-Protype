import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const InfoWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="19.011" height="19.011" viewBox="0 0 19.011 19.011">
  <g id="Icon_ionic-ios-information-circle-outline" data-name="Icon ionic-ios-information-circle-outline" transform="translate(-3.375 -3.375)">
    <path id="Path_2198" data-name="Path 2198" d="M16.552,11.618a.942.942,0,1,1,.937.914A.915.915,0,0,1,16.552,11.618Zm.064,1.631h1.746v6.585H16.616Z" transform="translate(-4.612 -2.567)" fill="#fff"/>
    <path id="Path_2199" data-name="Path 2199" d="M12.881,4.655A8.223,8.223,0,1,1,7.063,7.063a8.172,8.172,0,0,1,5.818-2.408m0-1.28a9.506,9.506,0,1,0,9.506,9.506,9.5,9.5,0,0,0-9.506-9.506Z" fill="#fff"/>
  </g>
</svg>
`}
    />
  );
};
export default InfoWhiteSVG;
