import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const SearchSvg = props => {
  const size = props.size ? props.size : 18;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="27.871" height="27.871" viewBox="0 0 27.871 27.871">
      <g id="Icon_feather-search" data-name="Icon feather-search" transform="translate(-3 -3)">
        <path id="Path_2208" data-name="Path 2208" d="M26.056,15.278A10.778,10.778,0,1,1,15.278,4.5,10.778,10.778,0,0,1,26.056,15.278Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
        <path id="Path_2209" data-name="Path 2209" d="M30.835,30.835l-5.86-5.86" transform="translate(-2.085 -2.085)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
      </g>
    </svg>
    
    
`}
    />
  );
};
export default SearchSvg;
