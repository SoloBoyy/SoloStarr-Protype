import store from '../store';
import {
  COMMENT_TOGGLE_LIKE,
  PUSH_NEW_COMMENT,
  SET_FORYOU_LAYOUT_KEY_VALUE,
  COMMENT_SET_VISIBLE,
  STORY_TOGGLE_LIKE,
  SET_PROFILE_KEY_VALUE_FORYOU,
} from './types';
class ForYouController {
  constructor() {
    this.setProfileKeyValue = (key, value) => {
      store.dispatch({
        type: SET_PROFILE_KEY_VALUE_FORYOU,
        payload: {key, value},
      });
    };
    this.pushComment = (storyId, commentText) => {
      const comment = {
        text: commentText,
        likes: 215,
      };
      let commentItem = {
        _id: `${Math.round(Math.random() * 10000)}`,
        user: {
          username: 'atamuhiuldin',
          avatar: '',
        },
        age: '21d',
        comment,
        replies: [comment, comment, comment],
      };
      store.dispatch({
        type: PUSH_NEW_COMMENT,
        payload: {
          storyId,
          comment: commentItem,
        },
      });
    };
    this.likeComment = (storyId, commentId, likedValue) => {
      store.dispatch({
        type: COMMENT_TOGGLE_LIKE,
        payload: {storyId, commentId, likedValue},
      });
    };
    this.likeStory = (storyId, likedValue) => {
      console.log(storyId);
      store.dispatch({
        type: STORY_TOGGLE_LIKE,
        payload: {storyId, likedValue},
      });
    };

    this.setCommentVisible = (storyId, value) => {
      store.dispatch({
        type: COMMENT_SET_VISIBLE,
        payload: {storyId, value},
      });
    };

    this.setLayoutKeyValue = (key, force = false, value = false) => {
      store.dispatch({
        type: SET_FORYOU_LAYOUT_KEY_VALUE,
        payload: {
          force,
          key,
          value,
        },
      });
    };

    this.toggleADOverlay = (value = undefined) => {
      this.setLayoutKeyValue(
        'VIEW_AD_ENABLED',
        value !== undefined ? true : false,
        value,
      );
    };

    this.setVideoPlayable = (value) => {
      this.setLayoutKeyValue('FOR_YOU_VIDEO_PLAYABLE', true, value);
    };
    this.toggleCommentOverlay = (value = undefined) => {
      this.setLayoutKeyValue(
        'COMMENTS_VISIBLE',
        value !== undefined ? true : false,
        value,
      );
    };
    this.toggleShareOverlay = (value = undefined) => {
      this.setLayoutKeyValue(
        'SHARE_ENABLED',
        value !== undefined ? true : false,
        value,
      );
    };
  }
}
const MyForYouController = new ForYouController();
export default MyForYouController;
