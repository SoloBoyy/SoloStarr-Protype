import React, {useEffect, useState, useRef} from 'react';
import {View, Text, FlatList, Animated} from 'react-native';
import MyProfileAnimController from '../../screens/profileAnimController';
import SingleSnap from './singleSnap';
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const PostTabContent = (props) => {
  const yAnim = new Animated.Value(0);
  const listRef = useRef();
  const [posts, setPosts] = useState([
    {_id: 1, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 2, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 3, imageSource: require('../../assets/dummy03.jpg')},
    {_id: 4, imageSource: require('../../assets/dummy04.jpg')},
    {_id: 5, imageSource: require('../../assets/dummy05.jpg')},
    {_id: 6, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 7, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 8, imageSource: require('../../assets/dummy03.jpg')},
    {_id: 9, imageSource: require('../../assets/dummy04.jpg')},
    {_id: 10, imageSource: require('../../assets/dummy05.jpg')},
    {_id: 11, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 12, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 13, imageSource: require('../../assets/dummy03.jpg')},
    {_id: 14, imageSource: require('../../assets/dummy04.jpg')},
    {_id: 15, imageSource: require('../../assets/dummy05.jpg')},
    {_id: 16, imageSource: require('../../assets/dummy05.jpg')},
    {_id: 17, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 18, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 19, imageSource: require('../../assets/dummy03.jpg')},
    {_id: 20, imageSource: require('../../assets/dummy04.jpg')},
    {_id: 21, imageSource: require('../../assets/dummy05.jpg')},
  ]);
  // ({nativeEvent}) => console.log(nativeEvent.contentOffset.y);
  // Animated.event(
  //   {nativeEvent: {contentOffset: {y: props.y}}},
  //   {useNativeDriver: true},
  // );
  const scrollToStart = () => {
    listRef.current.scrollToOffset({animated: true, offset: 0});
  };
  MyProfileAnimController.setTopScrollHandler('posts', scrollToStart);

  useEffect(() => {
    // console.log('On change tab');
    // console.log(props.currentTab);
    if (props.currentTab !== 'Posts') {
      scrollToStart();
    }
  }, [props.currentTab]);
  return (
    <AnimatedFlatList
      onScroll={Animated.event(
        [
          {
            nativeEvent: {
              contentOffset: {
                y: props.title === props.currentTab ? props.y : yAnim,
              },
            },
          },
        ],
        {useNativeDriver: true}, //83tert <-- Add this
      )}
      ref={listRef}
      numColumns={3}
      data={posts}
      renderItem={({item, index}) => (
        <SingleSnap
          key={`${Math.round(Math.random() * 10000)}-${index}`}
          {...{imageSource: item.imageSource}}
        />
      )}
      keyExtractor={(item) =>
        `${Math.round(Math.random() * 10000)}-${item._id}`
      }
    />
  );
};
export default PostTabContent;
