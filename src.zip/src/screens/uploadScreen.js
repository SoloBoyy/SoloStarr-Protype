import React, {Component} from 'react';
import {View, Text, StatusBar, TouchableOpacity} from 'react-native';
import ArrowBackWhiteSVG from '../icons/arrowBackWhiteSVG';
import {goBack} from '../navigator';
import {SECONDRY_BLACK} from '../themes/colors';
import ImagePicker from 'react-native-image-crop-picker';
import MyRecordingController from '../editor/Controllers/recordingConroller';

class UploadScreen extends Component {
  state = {};
  _handlePickVideo = () => {
    ImagePicker.openPicker({
      mediaType: 'video',
    })
      .then((video) => {
        //// Handle Append and calculation
        let videoDurationSec = video.duration / 1000;
        console.log(`Video With Duration: ${videoDurationSec} Seconds`);
        console.log(video);
        MyRecordingController.appendVideoClip(
          {...video, uri: video.path},
          false,
        );
        goBack();
      })
      .catch((Err) => console.log('Error in picking '));
  };
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={false} barStyle="light-content" />
        <View
          style={{
            width: '100%',
            height: 100,
            backgroundColor: SECONDRY_BLACK,
          }}>
          <TouchableOpacity
            onPress={() => goBack()}
            style={{width: 50, height: 50, marginLeft: 20, marginTop: 10}}>
            <ArrowBackWhiteSVG />
          </TouchableOpacity>
        </View>

        <View
          style={{
            flex: 1,
            backgroundColor: 'black',
          }}>
          <Text style={{color: 'white', alignSelf: 'center', marginTop: 50}}>
            Upload Video file, Audio will be extracted
          </Text>

          <View style={{height: 100}} />
          <Text
            onPress={this._handlePickVideo}
            style={{color: 'white', alignSelf: 'center', padding: 30}}>
            Tap Here
          </Text>
        </View>
      </View>
    );
  }
}

export default UploadScreen;
