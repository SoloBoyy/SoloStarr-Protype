import React, {Component} from 'react';
import {View, Text} from 'react-native';

class RecordingPage extends Component {
  state = {};
  render() {
    return (
      <View>
        <Text>Recording Page</Text>
      </View>
    );
  }
}

export default RecordingPage;
