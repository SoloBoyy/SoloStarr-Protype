import React, {useEffect, useState, useRef} from 'react';
import {View, Text, FlatList, Animated} from 'react-native';
import MyProfileAnimController from '../../screens/profileAnimController';
import ProfileSnapSeries from './profileSnapSeries';
import SingleSnap from './singleSnap';
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const SeriesTabContent = (props) => {
  const yAnim = new Animated.Value(0);
  const listRef = useRef();
  const [posts, setPosts] = useState([
    {_id: 1},
    {_id: 2},
    {_id: 3},
    {_id: 4},
    {_id: 5},
    {_id: 6},
    {_id: 7},
    {_id: 8},
    {_id: 9},
    {_id: 10},
    {_id: 11},
    {_id: 12},
    {_id: 13},
    {_id: 14},
    {_id: 15},
    {_id: 16},
    {_id: 17},
    {_id: 18},
    {_id: 19},
    {_id: 20},
    {_id: 21},
  ]);
  // ({nativeEvent}) => console.log(nativeEvent.contentOffset.y);
  // Animated.event(
  //   {nativeEvent: {contentOffset: {y: props.y}}},
  //   {useNativeDriver: true},
  // );
  const scrollToStart = () => {
    listRef.current.scrollToOffset({animated: true, offset: 0});
  };
  MyProfileAnimController.setTopScrollHandler('series', scrollToStart);

  useEffect(() => {
    // console.log('On change tab');
    // console.log(props.currentTab);
    if (props.currentTab !== 'Series') {
      scrollToStart();
    }
  }, [props.currentTab]);
  return (
    <AnimatedFlatList
      onScroll={Animated.event(
        [
          {
            nativeEvent: {
              contentOffset: {
                y: props.title === props.currentTab ? props.y : yAnim,
              },
            },
          },
        ],
        {useNativeDriver: true}, //83tert <-- Add this
      )}
      ref={listRef}
      numColumns={1}
      data={posts}
      renderItem={({item, index}) => (
        <ProfileSnapSeries
          key={`${Math.round(Math.random() * 10000)}-${index}`}
          {...{title: `Series ${index + 1}`}}
        />
      )}
      keyExtractor={(item) =>
        `${Math.round(Math.random() * 10000)}-${item._id}`
      }
    />
  );
};
export default SeriesTabContent;
