import React, {useState, useRef, useEffect} from 'react';
import {
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  ImageBackground,
  StatusBar,
  TextInput,
  KeyboardAvoidingView,
  Modal,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome5';
import CheckMarkGreenSVG from '../../../icons/checkMarkGreenSVG';
import EditPenWhiteSVG from '../../../icons/editPenWhiteSVG';
import StarWhiteSVG from '../../../icons/startWhiteSVG';
import {navigate} from '../../../navigator';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../../themes/colors';
import CircleButton from '../../inbox/circleButton';
import {useKeyboard} from '../../keybordHeight';
import ProfileImageEditOptions from './profileImageEditOptions';
const {width, height} = Dimensions.get('window');

const ProfileState = ({title, value, onPress, activeOpacity}) => {
  const size = 15;
  return (
    <TouchableOpacity
      onPress={onPress ? () => onPress() : () => false}
      activeOpacity={activeOpacity}
      style={{alignItems: 'center'}}>
      <Text style={{color: 'white', fontSize: size, fontWeight: '700'}}>
        {value}
      </Text>
      <Text style={{color: 'white', fontSize: size - 5}}>{title}</Text>
    </TouchableOpacity>
  );
};
// 63F420
const ProfileDetailHeader = (props) => {
  const [fullName, setFullName] = useState('Chris Gullette');
  const [aboutDesc, setAboutDesc] = useState(
    'In publishing and graphic design, Lorem ipsum is a',
  );
  const [webLink, setWebLink] = useState('solostar.com');
  const [editingOptionsVisible, setEditingOptionsVisible] = useState(false);
  const fullNameRef = useRef();
  const aboutDescRef = useRef();
  const webLinkRef = useRef();
  const editImageRef = useRef();
  const focus = (ref) => {
    ref.current.focus();
  };
  const [currentKeybordHeight, setKeybordHeight] = useState(0);
  const keybordHeight = useKeyboard();
  useEffect(() => {
    console.log(keybordHeight);
    // setKeybordHeight(keybordHeight[0]);
  }, keybordHeight);
  const visible = props.visible ? true : false;
  const handleGotoImageEditing = () => {
    console.log('Closing...');
    if (props.setVisible) {
      console.log('calling...');
      props.setVisible(false);
    }
    navigate('ImageEditingScreen');
  };
  const handleGotoProfileReframe = () => {
    console.log('Closing...');
    if (props.setVisible) {
      console.log('calling...');
      props.setVisible(false);
    }
    navigate('ImageCropingScreen');
  };
  return (
    <Modal
      key={25}
      animationType="none"
      transparent={true}
      visible={visible}
      onRequestClose={() => {
        console.log('Closing...');
        if (props.setVisible) {
          console.log('calling...');
          props.setVisible(false);
        }
      }}>
      <View style={{flex: 1}}>
        <ImageBackground
          resizeMode="contain"
          source={require('../../../assets/SAMPLE02.jpg')}
          style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
          {/* TODOIOS */}
          <TouchableOpacity
            ref={editImageRef}
            onPress={() => setEditingOptionsVisible(true)}
            style={{position: 'absolute', right: 20, top: 30, zIndex: 9999}}>
            <CircleButton
              onPress={() => setEditingOptionsVisible(true)}
              size={45}
              style={{backgroundColor: 'transparent'}}
              invert
              Icon={() => (
                <EditPenWhiteSVG
                  onPress={() => setEditingOptionsVisible(true)}
                  size={25}
                />
              )}
            />
          </TouchableOpacity>

          {/* {currentKeybordHeight !== 0 ? <View style={{flex: 1}}></View> : false} */}
          <LinearGradient
            locations={[0, 0.7, 1]}
            style={{flex: 1}}
            colors={['rgba(0,0,0, 0)', SECONDRY_BLACK, SECONDRY_BLACK]}>
            <View
              style={{
                flex: 1,
                justifyContent: 'flex-end',
              }}>
              <KeyboardAvoidingView
                behavior="padding"
                keyboardVerticalOffset={currentKeybordHeight}>
                <View style={{width: '90%', alignSelf: 'center'}}>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TextInput
                      ref={fullNameRef}
                      style={{fontSize: 25, color: 'white'}}
                      value={fullName}
                      onChangeText={(text) => {
                        setFullName(text);
                        setTimeout(() => props.onChangeName(text), 50);
                      }}
                    />
                    {/* <Text style={{fontSize: 25, color: 'white'}}>
                  Chris Gullette
                </Text> */}
                    <EditPenWhiteSVG
                      onPress={() => focus(fullNameRef)}
                      style={{marginTop: 3, marginLeft: 5}}
                    />
                  </View>

                  {/* <View style={{height: 10}} /> */}
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TextInput
                      ref={aboutDescRef}
                      multiline
                      style={{color: 'white', maxWidth: '60%'}}
                      value={aboutDesc}
                      onChangeText={(text) => {
                        setAboutDesc(text);
                        setTimeout(() => props.onChangeDesc(text), 50);
                      }}
                    />
                    <EditPenWhiteSVG
                      onPress={() => focus(aboutDescRef)}
                      style={{marginTop: 3, marginLeft: 5}}
                    />
                  </View>
                  {/* <Text style={{color: 'white', maxWidth: '60%'}}>
                In publishing and graphic design, Lorem ipsum is a
              </Text> */}
                  {/* <View style={{height: 10}} /> */}
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <TextInput
                      ref={webLinkRef}
                      style={{color: 'white', maxWidth: '60%'}}
                      value={webLink}
                      onChangeText={(text) => {
                        setWebLink(text);
                        setTimeout(() => props.onChangeWeb(text), 50);
                      }}
                    />
                    <EditPenWhiteSVG
                      onPress={() => focus(webLinkRef)}
                      style={{marginTop: 3, marginLeft: 5}}
                    />
                  </View>
                  {/* <Text style={{color: 'white'}}>solostar.com</Text> */}
                </View>
              </KeyboardAvoidingView>
              <View style={{height: 40}} />
              <View
                style={{
                  flexDirection: 'row',
                  width: 250,
                  alignSelf: 'center',
                  justifyContent: 'space-evenly',
                }}>
                <ProfileState
                  onPress={() => {
                    navigate('FollowScreen', {
                      target: 'Followers',
                    });
                  }}
                  key={10}
                  {...{title: 'Followers', value: '127k'}}
                />
                <ProfileState
                  onPress={() => {
                    navigate('FollowScreen', {
                      target: 'Followers',
                    });
                  }}
                  key={11}
                  {...{title: 'Followers', value: '127k'}}
                />
                <ProfileState
                  onPress={() => {
                    navigate('FollowScreen', {
                      target: 'Followers',
                    });
                  }}
                  key={12}
                  {...{title: 'Followers', value: '127k'}}
                />
                <View style={{width: 10}} />
                {/* TODOIOS */}
                <CircleButton
                  onPress={() => props.setVisible(false)}
                  size={35}
                  invert
                  Icon={() => (
                    <CheckMarkGreenSVG
                      onPress={() => props.setVisible(false)}
                    />
                  )}
                />
              </View>

              <View style={{height: 40}} />
              {/* <View style={{flexDirection: 'row', alignSelf: 'center'}}>
              <View key={21}>
                <TouchableOpacity
                  key={22}
                  onPress={() => false}
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <StarWhiteSVG />
                </TouchableOpacity>
              </View>
              <View style={{width: 10}} />
              <TouchableOpacity
                key={19}
                style={{
                  width: 200,
                  height: 35,
                  borderRadius: 50,
                  backgroundColor: 'black',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text key={20} style={{color: 'white'}}>
                  Edit Profile
                </Text>
              </TouchableOpacity>
              <View style={{width: 10}} />

              <View key={25}>
                <TouchableOpacity
                  key={90}
                  onPress={() => false}
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Icon
                    onPress={() => false}
                    key={63}
                    style={{fontSize: 23}}
                    color={'white'}
                    name={false ? 'times' : 'paperclip'}
                  />
                </TouchableOpacity>
              </View>
            </View> */}
            </View>
          </LinearGradient>
        </ImageBackground>
        <ProfileImageEditOptions
          onReframePicture={handleGotoImageEditing}
          onProfileReframe={handleGotoProfileReframe}
          setVisible={(value) => setEditingOptionsVisible(value)}
          from={editImageRef}
          visible={editingOptionsVisible}
        />
      </View>
    </Modal>
  );
};

export default ProfileDetailHeader;
