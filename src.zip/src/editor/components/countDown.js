import React, {useState, useLayoutEffect} from 'react';
import {View, Text, Dimensions} from 'react-native';

const CountDown = (props) => {
  const {width, height} = Dimensions.get('window');
  const [timerValue, setTimerValue] = useState(0);
  const boxWidth = 100;
  const boxHeight = 100;
  let clock = 0;
  const left = width / 2 - boxWidth / 2;
  const top = height / 2 - boxHeight / 2;

  return (
    <View
      style={{
        width: boxWidth,
        height: boxHeight,
        left,
        top,
        position: 'absolute',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <Text style={{color: 'white', fontSize: 50}}>
        {props.value ? props.value : 0}
      </Text>
    </View>
  );
};
export default CountDown;
