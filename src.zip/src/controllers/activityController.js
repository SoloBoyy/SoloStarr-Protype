import store from '../store';
import {SET_ACTIVITY_TYPE_FILTER} from './types';
class ActivityController {
  constructor() {
    this.setFilter = (filter) => {
      store.dispatch({
        type: SET_ACTIVITY_TYPE_FILTER,
        payload: filter,
      });
    };
  }
}
const MyActivityController = new ActivityController();
export default MyActivityController;
