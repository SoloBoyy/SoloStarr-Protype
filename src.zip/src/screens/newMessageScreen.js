import React, {Component} from 'react';
import {View, Text, StatusBar} from 'react-native';
import ChatInputBox from '../components/inbox/chatInputBox';
import InboxChatItem from '../components/inbox/inboxChatItem';
import InboxHeaderContainer from '../components/inbox/inboxHeaderContainer';
import InboxSearchBox from '../components/inbox/inboxSearchBox';
import {SECONDRY_BLACK} from '../themes/colors';

class NewMessageScreen extends Component {
  state = {};
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar backgroundColor={SECONDRY_BLACK} />
        <InboxHeaderContainer navigation={this.props.navigation} noRightIcon>
          <View
            style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{color: 'white'}}>New Message</Text>
          </View>
        </InboxHeaderContainer>
        <View style={{width: '90%', alignSelf: 'center'}}>
          <InboxSearchBox />
        </View>
        <View
          style={{
            flex: 1,
            backgroundColor: 'black',
          }}>
          <View
            style={{
              flex: 1,
              backgroundColor: 'black',
              width: '90%',
              alignSelf: 'center',
            }}>
            <InboxChatItem isSelected selectable />
            <InboxChatItem selectable />
            <InboxChatItem selectable />
            <InboxChatItem isSelected selectable />
            <InboxChatItem isSelected selectable />
          </View>
        </View>
        <ChatInputBox />
      </View>
    );
  }
}

export default NewMessageScreen;
