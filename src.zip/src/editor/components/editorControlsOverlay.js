import React, {Component} from 'react';
import {View, Text, StyleSheet, Dimensions} from 'react-native';
import EditorSideControls from './editorSideControls';
import MyTextIconButton from './myTextIconButton';
import EditorHeaderOverlay from './editorHeaderOverlay';
import FooterOverlay from './overlayFooter';
import VerticalScrollOverlay from './verticalScrollOverlay';
import {connect} from 'react-redux';
import MyLayoutManager from '../Controllers/layoutManager';
import CountDown from './countDown';
import MyRecordingController from '../Controllers/recordingConroller';
import MyLayoutModal from '../Controllers/myLayoutModal';
import VideoClipsTimeline from './clipsTimeline/videoClipsTimeline';
class EditorControlsOverlay extends Component {
  render() {
    const {width, height} = Dimensions.get('window');
    const {editorLayoutMode} = this.props;
    return (
      <View style={[Styles.container, {width, height}]}>
        <View style={Styles.headerContainer}>
          <EditorHeaderOverlay />
        </View>
        <View style={Styles.centerContainer}>
          <View style={Styles.rightControlsBar}>
            {/* {editorLayoutMode.SIDE_BAR_CONTROLS ? ( */}
            <EditorSideControls playingSpeed={this.props.playingSpeed} />
            {/* ) : ( */}
            {/* false */}
            {/* )} */}
          </View>
          <View style={Styles.playerOverlayContainer}></View>
        </View>
        <View style={Styles.footerContainer}>
          {/* <FooterOverlay /> */}
          <VideoClipsTimeline />
        </View>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  editorLayoutMode: state.EditorReducer.editorLayoutMode,
});
export default connect(mapStateToProps, null)(EditorControlsOverlay);

const Styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 0,
    top: 0,
    zIndex: 999,
  },
  centerContainer: {
    flex: 1,
    flexDirection: 'row-reverse',
  },
  headerContainer: {
    width: '100%',
    height: 65,
    backgroundColor: 'transparent',
    paddingLeft: 18,
    paddingRight: 18,
  },
  playerOverlayContainer: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  rightControlsBar: {
    backgroundColor: 'transparent',
    width: 48,
    height: '100%',
    alignSelf: 'flex-end',
    flexDirection: 'column',
  },
  footerContainer: {
    width: '100%',
    backgroundColor: 'transparent',
  },
});
