import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {connect} from 'react-redux';
import MyLayoutManager from '../Controllers/layoutManager';
const TabBarButton = (props) => {
  const selectedFont = 18;
  const normalFont = 10;
  console.log('MODE');
  console.log(props);

  return (
    <>
      <Text
        style={[
          Styles.tabText,
          {
            fontSize:
              props.mode === MyLayoutManager.VIDEO_MAKING_MODE
                ? selectedFont
                : normalFont,
            marginTop:
              props.mode === MyLayoutManager.VIDEO_MAKING_MODE ? -3 : 0,
          },
        ]}>
        Video
      </Text>
      <View style={{width: 1, height: 21, backgroundColor: 'white'}} />
      <Text
        style={[
          Styles.tabText,
          {
            fontSize:
              props.mode === MyLayoutManager.VIDEO_MAKING_MODE
                ? normalFont
                : selectedFont,
            marginTop: 0,
          },
        ]}>
        Edit
      </Text>
    </>
  );
};
// const mapStateToProps = (state) => ({
//   mode: state.EditorReducer.mode,
// });
export default TabBarButton;

const Styles = StyleSheet.create({
  tabText: {color: 'white', padding: 6, fontWeight: 'bold'},
});
