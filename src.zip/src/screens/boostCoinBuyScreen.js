import React, {Component} from 'react';
import {View, Text, StatusBar, Image} from 'react-native';
import CircleButton from '../components/inbox/circleButton';
import CrossMarkWhiteSVG from '../icons/crossMarkWhiteSVG';
import {goBack} from '../navigator';
import {SECONDRY_BLACK, WHITE_COLOR} from '../themes/colors';

const BuyCoinButton = (props) => {
  return (
    <View
      style={{
        width: 100,
        height: 100,
        borderRadius: 25,
        backgroundColor: 'black',
        justifyContent: 'space-evenly',
        alignItems: 'center',
      }}>
      <View style={{alignItems: 'center', marginTop: -5}}>
        <Text style={{color: 'white', fontSize: 23, fontWeight: 'bold'}}>
          ##
        </Text>
        <Text style={{color: 'white'}}>Boost Coins</Text>
      </View>
      <Text style={{color: 'white'}}>$#.##</Text>
    </View>
  );
};

class BoostCoinBuyScreen extends Component {
  state = {};
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={false} backgroundColor={SECONDRY_BLACK} />
        <View style={{position: 'absolute', top: 10, left: 10}}>
          <CircleButton
            onPress={() => goBack()}
            invert
            Icon={() => <CrossMarkWhiteSVG size={10} />}
          />
        </View>
        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
          <Text style={{color: WHITE_COLOR, fontSize: 25}}>
            Buy Boost Coins
          </Text>
        </View>
        <View
          style={{
            flex: 1.6,
            flexDirection: 'row',
            justifyContent: 'space-evenly',
          }}>
          <BuyCoinButton />
          <BuyCoinButton />
          <BuyCoinButton />
        </View>
      </View>
    );
  }
}

export default BoostCoinBuyScreen;
