import React, {PureComponent} from 'react';
import {View, Text, StatusBar, Dimensions, FlatList} from 'react-native';
import Animated from 'react-native-reanimated';
import ForYouFollowingTabPage from '../components/foryouFollowing/forYouFollowingTabPage';
import {SECONDRY_BLACK} from '../themes/colors';

class FollowingAndForYouScreen extends PureComponent {
  constructor() {
    super();
    this.state = {
      stories: [
        {_id: 0, title: 'abc0'},
        {_id: 1, title: 'abc1'},
        {_id: 2, title: 'abc2'},
        {_id: 3, title: 'abc3'},
      ],
      scrollEnabled: true,
    };
    this.DIMENSIONS = Dimensions.get('window');
    this.storyFlatListRef = null;
    this.CONTENT_WIDTH = 0;
    this.INITIALIZED = 0;
  }

  componentDidMount() {
    setTimeout(() => {
      this.INITIALIZED = 1;
      // this.storyFlatListRef.scrollToIndex({index: 2, animated: true});
      // this.storyFlatListRef.scrollToOffset({animated: true, offset: 1});
    }, 0);
  }

  toggleMainScrollEnabled = (value) => {
    this.setState({toggleMainScrollEnabled: value});
  };

  onNext = (index) => {
    if (index < this.state.stories.length - 1) {
      this.storyFlatListRef.scrollToIndex({index: index + 1});
    }
  };

  onPrevious = (index) => {
    if (index > 0) {
      this.storyFlatListRef.scrollToIndex({index: index - 1});
    }
  };

  _handleTransition = (nativeEvent) => {
    let offsets = nativeEvent.contentOffset.y;
    let modul = offsets % this.CONTENT_HEIGHT;
    let currentIndex = (offsets - modul) / this.CONTENT_HEIGHT;
    let scrollLeft = nativeEvent.velocity.y < 0 ? true : false;
    let velocityY =
      nativeEvent.velocity.y < 0
        ? -nativeEvent.velocity.y
        : nativeEvent.velocity.y;
    if (velocityY > 1.6) {
      if (scrollLeft) {
        // console.log('GOING NEXT: VELOCITY');
        this.onNext(currentIndex);
      } else {
        this.storyFlatListRef.scrollToIndex({index: currentIndex});
      }
    } else if (modul < 140) {
      this.storyFlatListRef.scrollToIndex({index: currentIndex});
    } else {
      // console.log('GOING NEXT: OFFSET');
      this.onNext(currentIndex);
    }
  };

  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden backgroundColor={SECONDRY_BLACK} />
        <FlatList
          showsVerticalScrollIndicator={false}
          data={this.state.stories}
          ref={(e) => (this.storyFlatListRef = e)}
          renderItem={({item, index}) => (
            <ForYouFollowingTabPage
              {...{
                card: item,
                toggleMainScrollEnabled: this.toggleMainScrollEnabled,
              }}
            />
          )}
          keyExtractor={(item) =>
            `${item._id}-${Math.round(Math.random() * 1000)}`
          }
          onLayout={({nativeEvent}) => {
            this.CONTENT_HEIGHT = nativeEvent.layout.height;
          }}
          onScroll={({nativeEvent}) => {
            if (this.INITIALIZED === 0) {
              this.INITIALIZED = 1;
              this._handleTransition({contentOffset: {x: 1}, velocity: {x: 1}});
            }
          }}
          onScrollEndDrag={({nativeEvent}) => {
            this._handleTransition(nativeEvent);
          }}
          getItemLayout={(data, index) => ({
            length: this.DIMENSIONS.height,
            offset: this.DIMENSIONS.height * index,
            index,
          })}
        />
      </View>
    );
  }
}

export default FollowingAndForYouScreen;
