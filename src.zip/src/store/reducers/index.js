import {combineReducers} from 'redux';
import EditorReducer from './editorReducer';
import InboxReducer from './inboxReducer';
import ActivityReducer from './activityReducer';
import ForYouReducer from './forYouReducer';
const RootReducer = combineReducers({
  EditorReducer,
  InboxReducer,
  ActivityReducer,
  ForYouReducer,
});
export default RootReducer;
