import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CrossMarkWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="16.716" height="16.711" viewBox="0 0 16.716 16.711">
  <path id="Icon_ionic-ios-close" data-name="Icon ionic-ios-close" d="M21.624,19.644l5.97-5.97A1.4,1.4,0,1,0,25.615,11.7l-5.97,5.97-5.97-5.97A1.4,1.4,0,1,0,11.7,13.674l5.97,5.97-5.97,5.97a1.4,1.4,0,0,0,1.978,1.978l5.97-5.97,5.97,5.97a1.4,1.4,0,0,0,1.978-1.978Z" transform="translate(-11.285 -11.289)" fill="#fff"/>
</svg>
`}
    />
  );
};
export default CrossMarkWhiteSVG;
