import React, {useState} from 'react';
import {View, Image, Text, StyleSheet, TouchableOpacity} from 'react-native';
import LikedRedSVG from '../../../icons/likedRedSVG';
import LikedWhiteSVG from '../../../icons/likedWhiteSVG';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../../themes/colors';
import MyTextIconButton from '../myTextIconButton';

export const CARD_HEIGHT = 70;
export const REPLY_HEIGHT = 60;
export const REPLY_AVATAR_SIZE = 40;
export const AVATAR_SIZE = 45;
const SingleComment = (props) => {
  const isReply = props.isReply ? true : false;
  const expanded = props.expanded ? true : false;
  const isPreview = props.isPreview ? true : false;
  const [isLiked, setIsLiked] = useState(false);
  const repliesCount = props.repliesCount ? props.repliesCount : 0;
  const commentItem = props.commentItem;
  if (isPreview) {
    return (
      <View style={[Styles.container, {...props.style}]}>
        <View style={{width: isReply ? 30 : 0}} />
        <View style={{width: 100}}>
          <View
            style={{
              height: CARD_HEIGHT,
              flexDirection: 'row',
              justifyContent: 'space-around',
              alignItems: 'center',
            }}>
            <Image
              style={{
                width: isReply ? REPLY_AVATAR_SIZE : AVATAR_SIZE,
                height: isReply ? REPLY_AVATAR_SIZE : AVATAR_SIZE,
                borderRadius: 50,
                backgroundColor: WHITE_COLOR,
              }}
            />
            <View
              style={{
                flex: 1,
                height: CARD_HEIGHT,
                justifyContent: 'space-evenly',
              }}>
              <Text
                style={{
                  fontSize: 10,
                  color: WHITE_COLOR,
                  textAlign: 'center',
                  marginBottom: -5,
                }}>
                John carter
              </Text>
              <Text
                style={{
                  color: WHITE_COLOR,
                  fontSize: 12,
                  textAlign: 'center',
                }}>
                2d
              </Text>
            </View>
          </View>
        </View>
        <View style={{flex: 5, paddingLeft: 3, paddingTop: 12}}>
          <Text style={{color: 'white', fontSize: 13, textAlign: 'left'}}>
            {commentItem.comment.text}
          </Text>
        </View>
      </View>
    );
  } else {
    return (
      <View style={[Styles.container, {...props.style}]}>
        <View style={{width: isReply ? 30 : 0}} />
        <View style={{width: 100}}>
          <View
            style={{
              height: CARD_HEIGHT,
              flexDirection: 'row',
              justifyContent: 'space-around',
              alignItems: 'center',
            }}>
            <Image
              style={{
                width: isReply ? REPLY_AVATAR_SIZE : AVATAR_SIZE,
                height: isReply ? REPLY_AVATAR_SIZE : AVATAR_SIZE,
                borderRadius: 50,
                backgroundColor: WHITE_COLOR,
              }}
            />
            <View
              style={{
                flex: 1,
                height: CARD_HEIGHT,
                justifyContent: 'space-evenly',
              }}>
              <Text
                style={{
                  fontSize: 10,
                  color: WHITE_COLOR,
                  textAlign: 'center',
                  marginBottom: -5,
                }}>
                John carter
              </Text>
              <Text
                style={{color: WHITE_COLOR, fontSize: 12, textAlign: 'center'}}>
                2d
              </Text>
            </View>
          </View>
        </View>
        <View style={{flex: 5, paddingLeft: 3, paddingTop: 12}}>
          <Text
            onPress={props.onShowReplyBox}
            style={{color: 'white', fontSize: 13, textAlign: 'left'}}>
            {commentItem.comment.text}
          </Text>
          {repliesCount ? (
            <Text
              onPress={
                props.onToggleExpand ? props.onToggleExpand : () => false
              }
              style={{
                color: 'white',
                paddingTop: 10,
                paddingBottom: 10,
                paddingRight: 10,
                fontWeight: 'bold',
              }}>
              {expanded ? 'Hide Replies' : `${repliesCount} replies`}
            </Text>
          ) : (
            false
          )}
        </View>
        <View style={{width: isReply ? 40 : 50, marginTop: 10}}>
          <MyTextIconButton
            onPress={() => setIsLiked(!isLiked)}
            size={isReply ? 35 : 45}
            title={215}>
            {isLiked ? <LikedRedSVG /> : <LikedWhiteSVG />}
          </MyTextIconButton>
        </View>
      </View>
    );
  }
};
export default SingleComment;

const Styles = StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
  },
});
