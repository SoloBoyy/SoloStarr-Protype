import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const ChevronDownWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="22.243" height="12.621" viewBox="0 0 22.243 12.621">
  <path id="Icon_feather-chevron-down" data-name="Icon feather-chevron-down" d="M9,13.5l9,9,9-9" transform="translate(-6.879 -11.379)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
</svg>
`}
    />
  );
};
export default ChevronDownWhiteSVG;
