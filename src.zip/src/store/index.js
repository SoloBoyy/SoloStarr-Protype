import {createStore, compose, applyMiddleware} from 'redux';
import RootReducer from './reducers';
import thunk from 'redux-thunk';
const initialSatate = {};
const middleWares = [thunk];

let store = null;

if (window.__REDUX_DEVTOOLS_EXTENSION__) {
  store = createStore(
    RootReducer,
    initialSatate,
    compose(
      applyMiddleware(...middleWares),
      window.__REDUX_DEVTOOLS_EXTENSION__(),
    ),
  );
} else {
  store = createStore(
    RootReducer,
    initialSatate,
    compose(applyMiddleware(...middleWares)),
  );
}

export default store;
