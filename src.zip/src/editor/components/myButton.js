import React, {Component} from 'react';
import {TouchableOpacity, Text} from 'react-native';
import IconFA5 from 'react-native-vector-icons/FontAwesome5';
const MyButton = (props) => {
  const size = 25;
  const name = props.name ? props.name : 'menu';
  const color = props.color ? props.color : 'white';
  return (
    <TouchableOpacity
      onPress={props.onPress ? () => props.onPress() : () => false}
      style={{
        width: size,
        height: size,
        elevation: 0,
        backgroundColor: '#2A2A2A',
        borderRadius: 50,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <IconFA5 name={name} color={color} size={size * 0.6} />
    </TouchableOpacity>
  );
};
export default MyButton;
