import React, {Component} from 'react';
import {View, Text, Dimensions, StatusBar} from 'react-native';
import MyProfileScreen from '../../screens/myProfileScreen';
import {SECONDRY_BLACK} from '../../themes/colors';
const {width, height} = Dimensions.get('window');
const FollowingTabPage = (props) => {
  return (
    <View style={{width, height}}>
      <StatusBar hidden={false} backgroundColor={SECONDRY_BLACK} />
      <MyProfileScreen />
    </View>
  );
};
export default FollowingTabPage;
