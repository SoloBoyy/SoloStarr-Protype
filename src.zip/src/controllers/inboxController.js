import store from '../store';
import {PUSH_NEW_MESSAGE} from './types';
class InboxController {
  constructor() {
    this.getDummy = (username) => {
      return {
        _id: `Inbox-${Math.round(Math.random() * 10000)}`,
        username,
        desc: '',
        messages: [
          {
            _id: `msg-${Math.round(Math.random() * 10000)}`,
            text: 'Hello',
            isSender: false,
          },
          {
            _id: `msg-${Math.round(Math.random() * 10000)}`,
            text: 'Hey',
            isSender: true,
          },
          {
            _id: `msg-${Math.round(Math.random() * 10000)}`,
            text: 'How are you doing today !',
            isSender: true,
          },
          {
            _id: `msg-${Math.round(Math.random() * 10000)}`,
            text: 'Am doing good',
            isSender: false,
          },
        ],
      };
    };

    this.pushMessage = (chatId, text) => {
      let message = {
        _id: `msg-${Math.round(Math.random() * 10000)}`,
        text,
        isSender: true,
      };
      store.dispatch({
        type: PUSH_NEW_MESSAGE,
        payload: {
          chatId,
          message,
        },
      });
    };
  }
}
const MyInboxController = new InboxController();
export default MyInboxController;
