import store from '../../store';
import {
  ADD_STEP_RECORDING,
  ON_ADD_TIMER_RECORDER,
  REMOVE_LAST_RECORDED_CLIP,
  SET_RECORDING_BTN_ENABLED,
  SET_KEY_VALUE,
  UPDATE_RECOORDED_CLIP,
  REMOVE_RECORDED_CLIP,
  TOGGLE_RECORDING_SELECTED,
  SET_RECORDER_KEY_VALUE,
} from '../actionTypes';
import MyEditingController from './editingController';
import MyLayoutManager from './layoutManager';
// import MyLayoutModal from './myLayoutModal';
import RNFS from 'react-native-fs';
import MyAlertBoxController from './myAlertBoxController';
import {RNCamera} from 'react-native-camera';
class RecordingController {
  constructor() {
    this.clock = 0;
    this.isRunning = false;
    this.cameraRef = null;
    this.clockTime = 0; /// clockValue: Index, And clockTime: RecordingController Are same
    this.timeoutValue = 2;
    this.TIMER_TIMEOUT_OPTIONS = [
      {_id: 1, title: '0s', value: 0},
      {_id: 2, title: '3s', value: 3},
      {_id: 3, title: '5s', value: 5},
      {_id: 4, title: '10s', value: 10},
    ];
    this.RECORDING_SPEED_OPTIONS = [
      {_id: 1, value: 0.5, title: '0.5x'},
      {_id: 2, value: 1, title: '1x'},
      {_id: 3, value: 2, title: '2x'},
      {_id: 4, value: 3, title: '3x'},
    ];

    // this.TIMEOUT_LIMIT = 2; /// TODO: REMOVE IF NOT NEEDED
    this.timeoutClock = 0;
    this.onClockValueChangeEVENT = null;
    this.onTimeOutValueChangeEVENT = null;

    this.setRecordingBtnEnabled = (value) => {
      store.dispatch({
        type: SET_RECORDING_BTN_ENABLED,
        payload: value,
      });
    };
    this.setCameraRef = (_camRef) => {
      this.cameraRef = _camRef;
    };

    //// Will start the progress bar
    this.startProgress = () => {
      let durPeak = store.getState().EditorReducer.recorder.durationPeak;
      let durSeek = store.getState().EditorReducer.recorder.durationSeek;
      let recordingSpeed = store.getState().EditorReducer.recordingSpeed.value;
      // console.log(
      //   `DUR PEAK, ${durPeak}, DUR SEEK, ${durSeek}, RecordingSpeed ${recordingSpeed}`,
      // );
      // console.log('TEST 03- Starting Progress');
      let timeIncriment = 0.25; /// seconds
      let durationPeak = durPeak;
      let durationSeek = durSeek;
      // console.log(`DURATION SEEK = ${durationSeek}`);
      if (durationSeek < durationPeak) {
        this.setRecordingBtnEnabled(true);

        this.clock = setInterval(() => {
          durationSeek += timeIncriment;
          this.clockTime += timeIncriment;
          if (durationSeek <= durationPeak) {
            if (this.onClockValueChangeEVENT) {
              this.onClockValueChangeEVENT(this.clockTime);
            }
            store.dispatch({
              type: ON_ADD_TIMER_RECORDER,
              payload: timeIncriment,
            });
          } else {
            //// ON COMPLETE
            MyLayoutManager.setEditorMode(
              MyLayoutManager.MODES.VIDEO_RECORDING_COMPLETED,
            );
            this.cameraRef.stopRecording();
            // this.setRecordingBtnEnabled(false);
          }
        }, timeIncriment * 1000 * recordingSpeed);
        // console.log('TEST 04 - Switching Cam Mode');
        MyLayoutManager.switchCamMode();
      } else {
        //// DO NOTHING///
        /// TODO: move to next
      }
    };

    this.isValidVideoLength = (duration, durationAllowed) => {
      console.log(`TEST VIDEO: Duration:  ${duration}`);
      if (duration <= durationAllowed) {
        console.log('TEST VIDEO: Valid Duration');
        return true;
      } else {
        console.log(
          `TEST VIDEO: Invalid Video Duration: ${duration} seconds Allowd Duration is ${durationAllowed} seconds`,
        );
        MyAlertBoxController.show(
          MyAlertBoxController.ACTIONS_OKAY,
          `Invalid Video Length: ${duration} seconds. Allowd Length is ${durationAllowed} seconds.`,
          (result) => false,
        );
        return false;
      }
    };

    this.appendVideoClip = (source = {uri: 'abc'}, isRecorded = true) => {
      let recorder = store.getState().EditorReducer.recorder;
      let recordingSpeed = store.getState().EditorReducer.recordingSpeed.value;

      let pIndex = recorder.recordings.length;
      let duration = 0;
      if (isRecorded) {
        // console.log('TEST VIDEO: Recorded Video');
        duration = this.clockTime;
      } else {
        // console.log('TEST VIDEO: Selected Video');
        //// Custome Duration with
        duration = source.duration / 1000;
        ///  if length invalid then return
        if (!this.isValidVideoLength(duration, recorder.durationRemaining)) {
          // console.log('TEST VIDEO: Destroying Video');
          return false;
        }
        // console.log('TEST VIDEO: Appending video');
        ///  if length valid then allow to append
      }
      if (duration > 0) {
        let _id = `${Math.random() * 1000}XYZ${Math.random() * 1000}-A`;
        // console.log('Dispatching...');
        MyEditingController.getInfo(source.uri);
        store.dispatch({
          type: ADD_STEP_RECORDING,
          payload: {
            _id,
            pIndex,
            duration,
            source: source,
            processedSource: {uri: ''},
            isProcessed: false,
            recordingSpeed,
            selected: false,
            playing: false,
            info: {
              thumbnail: null,
              duration: 0,
            },
          },
        });

        if (!isRecorded) {
          MyLayoutManager.switchCamMode(true);
        }
        MyRecordingController.setKeyValue({
          key: 'isChangeSaved',
          value: false,
        });
        if (this.onClockValueChangeEVENT) {
          this.onClockValueChangeEVENT(0);
        }
        this.clockTime = 0;
        // console.log('>>>>>>>>>NEW STORE RECORDING STATE<<<<<<<<<<');
        // console.log(store.getState().EditorReducer.recorder);
      } else {
        console.log('DURTION = 0, Cannot Append Video Clip');
      }
    };

    this.setRecorderKeyValue = (key, value) => {
      store.dispatch({
        type: SET_RECORDER_KEY_VALUE,
        payload: {
          key,
          value,
        },
      });
    };

    this.updateClipProcessedSource = (clipId, processedSource) => {
      store.dispatch({
        type: UPDATE_RECOORDED_CLIP,
        payload: {
          clipId,
          processedSource,
        },
      });
    };

    this.stopProgress = () => {
      this.isRunning = false;
      clearInterval(this.clock);
      // console.log('STOPING PROGRESSS');
      this.setRecordingBtnEnabled(false);
      /// TODO: Append Vlip will be called by RNCamera
      // this.appendVideoClip();
      MyLayoutManager.switchCamMode();
    };

    this.setKeyValue = (value) => {
      store.dispatch({
        type: SET_KEY_VALUE,
        payload: value,
      });
    };

    this.resetEditor = () => {
      this.setKeyValue({
        key: 'recorder',
        value: {
          durationPeak: 15,
          durationRemaining: 15,
          durationSeek: 0,
          recordings: [],
        },
      });
      this.setKeyValue({
        key: 'editor',
        value: {
          initialVideoSource: null,
          playingSource: null,
          playingMode: 'clip', /// clip, full
          videoRepeate: false,
        },
      });
    };

    this.checkMemory = () => {
      return new Promise((resolve, reject) => {
        console.log('Checking memory');
        RNFS.getFSInfo()
          .then((info) => {
            let availableMemory = info.freeSpace / 1024 / 1024;
            if (availableMemory > 200) {
              console.log(`Available Memory ${availableMemory}`);
              resolve(true);
            } else {
              reject(
                `Memory Warning! Free space ${Math.round(availableMemory)} MB`,
              );
            }
          })
          .catch((err) => {
            console.log('ERROR In Checking Memory Info');
            console.log(err);
            reject('NO STORAGE PERMISSONS');
          });
      });
    };

    this.toggleCam = () => {
      let durationPeak = store.getState().EditorReducer.recorder.durationPeak;
      let durationSeek = store.getState().EditorReducer.recorder.durationSeek;
      if (durationSeek < durationPeak) {
        console.log('TEST 01: PASS');
        // console.log(`IsRunning ${this.isRunning}`);
        ///allow
        // console.log('TEST 1, toggleCam');

        if (this.isRunning) {
          ///TODO: Shift this one to, Camera Call back
          /// this.stopProgress();
          this.cameraRef.stopRecording();
        } else {
          // console.log('TEST 2, Starting...');
          this.isRunning = true;
          console.log('> Starting CAM');
          this.RunTimeout().then((stoped) => {
            // console.log('TEST 02- Timer Reslved');
            this.cameraRef
              .recordAsync({
                mirrorVideo: false,
                orientation: 'portrait',
                quality: RNCamera.Constants.VideoQuality['480p'],
              })
              .then((recordedRes) => {
                this.stopProgress();
                // console.log('VIDEO RECORDING RESULT');
                // console.log(recordedRes);
                MyRecordingController.appendVideoClip(recordedRes);
                // this.setState({
                //   recordedSource: [...this.state.recordedSource, recordedRes],
                // });
              })
              .catch((err) => {
                console.log('Video Recording ERROR CATCH');
                console.log(err);
                MyAlertBoxController.show(
                  MyAlertBoxController.ACTIONS_OKAY,
                  'Error: Starting Video Recording faild. Another recording might be in progress.',
                );
              });
            ///TODO: Start Camera Here: SHIFTED TO CAMERA CALL BACK
          });
        }
      } else {
        console.log(
          `Invalid Durations DURATION_SEEK: ${durationSeek}, DURATION_PEAK: ${durationPeak}`,
        );
        // move next
      }
    };

    this.setTimerTimeoutValue = (timeoutValue) => {
      this.setKeyValue({
        key: 'timerTimeout',
        value: timeoutValue,
      });
    };

    this.shiftTimerTimeoutValue = (oldValue) => {
      if (oldValue._id + 1 <= 5) {
        let nextValueIndex = this.TIMER_TIMEOUT_OPTIONS.findIndex(
          (t) => t._id === oldValue._id + 1,
        );
        if (nextValueIndex > 0 && nextValueIndex <= 5) {
          this.setTimerTimeoutValue(this.TIMER_TIMEOUT_OPTIONS[nextValueIndex]);
        } else {
          this.setTimerTimeoutValue(this.TIMER_TIMEOUT_OPTIONS[0]);
        }
      } else {
        this.setTimerTimeoutValue(this.TIMER_TIMEOUT_OPTIONS[0]);
      }
    };

    this.setRecordingSpeedValue = (recordingSpeed) => {
      store.dispatch({
        type: SET_KEY_VALUE,
        payload: {
          key: 'recordingSpeed',
          value: recordingSpeed,
        },
      });
    };

    this.shiftRecordingSpeedValue = (oldValue) => {
      if (oldValue._id + 1 <= 5) {
        let nextValueIndex = this.RECORDING_SPEED_OPTIONS.findIndex(
          (t) => t._id === oldValue._id + 1,
        );
        if (nextValueIndex > 0 && nextValueIndex <= 5) {
          this.setRecordingSpeedValue(
            this.RECORDING_SPEED_OPTIONS[nextValueIndex],
          );
        } else {
          this.setRecordingSpeedValue(this.RECORDING_SPEED_OPTIONS[0]);
        }
      } else {
        this.setRecordingSpeedValue(this.RECORDING_SPEED_OPTIONS[0]);
      }
    };

    this.setTimerVisible = (visibility) => {
      this.setKeyValue({
        key: 'timerVisible',
        value: visibility,
      });
    };

    this.RunTimeout = () => {
      return new Promise((resolve, reject) => {
        //// ON COUNT DOWN START HIDIG OVERLAY
        this.timeoutValue = store.getState().EditorReducer.timerTimeout.value;
        // console.log(`>Timeout Value:${this.timeoutValue}`);
        if (this.timeoutValue === 0) {
          /// When no timer
          resolve(true);
        } else {
          /// Changing Editor mode
          ///TODO: Inspect the VIDEO_COUNTER_RUNNING mode and see to remove it or implement
          // MyLayoutManager.setEditorMode(
          //   MyLayoutManager.MODES.VIDEO_COUNTER_RUNNING,
          // );
          //// showing the timer
          this.setTimerVisible(true);
          MyLayoutManager.setEditorLayoutMode(MyLayoutManager.LAYOUT_MODE.NONE);
          this.onTimeOutValueChangeEVENT(this.timeoutValue);
          this.timeoutClock = setInterval(() => {
            this.timeoutValue--;
            if (this.onTimeOutValueChangeEVENT) {
              this.onTimeOutValueChangeEVENT(this.timeoutValue);
            }
            if (this.timeoutValue <= 0) {
              /// clearing interval: i.e clock
              clearInterval(this.timeoutClock);
              //// Resetting timer timout value ZERO
              ///TODO: If bug reset timer timeout to zero again
              // this.setTimerTimeoutValue(0);
              /// Hiding the Timer
              this.setTimerVisible(false);
              resolve(true);
            }
          }, 1000);
        }
      });
    };

    this.removeLastRecordedClip = () => {
      store.dispatch({
        type: REMOVE_LAST_RECORDED_CLIP,
      });
      MyRecordingController.setKeyValue({
        key: 'isChangeSaved',
        value: false,
      });
      MyLayoutManager.switchCamMode(true);
    };

    this.removeRecordedClipById = (clipId) => {
      store.dispatch({
        type: REMOVE_RECORDED_CLIP,
        payload: clipId,
      });
      MyRecordingController.setKeyValue({
        key: 'isChangeSaved',
        value: false,
      });
      MyEditingController.setPlayingMode('full');
      // MyEditingController.processVideo()
      //   .then((res) => {
      //     // MyLayoutManager.setEditorLayoutMode(
      //     //   MyLayoutManager.LAYOUT_MODE
      //     //     .ZERO_EDITOR_VIDEO_PREVIEW,
      //     // );
      //     // console.log('PROCESSED......');
      //   })
      //   .catch((err) => {
      //     // console.log('PROCESSING CATCH ERROR');
      //     MyAlertBoxController.show(
      //       MyAlertBoxController.ACTIONS_OKAY,
      //       err,
      //       (result) => false,
      //     );
      //     console.log(err);
      //   });
    };

    this.removeSelectedVideoClip = () => {
      const recordings = store.getState().EditorReducer.recorder.recordings;
      let selectedClipIndex = recordings.findIndex((r) => r.selected === true);
      if (selectedClipIndex >= 0) {
        let clip = recordings[selectedClipIndex];
        this.removeRecordedClipById(clip._id);
      }
    };

    this.toggleVideoClipSelected = (clipId) => {
      store.dispatch({
        type: TOGGLE_RECORDING_SELECTED,
        payload: clipId,
      });
    };

    this.onAddClockValueListner = (_clockValueListner) => {
      this.onClockValueChangeEVENT = _clockValueListner;
    };

    this.onAddTimeOutValueListner = (_timeoutValueListner) => {
      this.onTimeOutValueChangeEVENT = _timeoutValueListner;
    };
  }
}
const MyRecordingController = new RecordingController();
export default MyRecordingController;
