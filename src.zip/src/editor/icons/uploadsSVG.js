import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const UploadsSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29">
  <g id="Icon_feather-upload" data-name="Icon feather-upload" transform="translate(-3.5 -3.5)">
    <path id="Path_6" data-name="Path 6" d="M31.5,22.5v6a3,3,0,0,1-3,3H7.5a3,3,0,0,1-3-3v-6" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_7" data-name="Path 7" d="M25.5,12,18,4.5,10.5,12" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_8" data-name="Path 8" d="M18,4.5v18" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default UploadsSVG;
