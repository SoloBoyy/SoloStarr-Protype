import React, {useState} from 'react';
import {View, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import MyRecordingController from '../Controllers/recordingConroller';
import MyLayoutManager from '../Controllers/layoutManager';
const INITIAL_STATE = {
  outerSize: 60,
  innerSize: 43,
};

const RECORDING_STATE = {
  outerSize: 80,
  innerSize: 20,
};

const CaptureButton = (props) => {
  const [enabled, setEnabled] = useState(true);
  return (
    <TouchableOpacity
      activeOpacity={1}
      onPressIn={() => false}
      onPressOut={() => {
        setEnabled(false);
        setTimeout(() => setEnabled(true), 500);
      }}
      onPress={
        props.onPress
          ? () => {
              // console.log('On PRESS');
              if (enabled) {
                props.onPress();
              }
              // if (props.editorMode === MyLayoutManager.MODES.VIDEO_RECORDING) {
              //   MyRecordingController.setRecordingBtnEnabled(false);
              // }
            }
          : () => false
      }
      style={{
        width: props.recordingBtnEnabled
          ? RECORDING_STATE.outerSize
          : INITIAL_STATE.outerSize,
        height: props.recordingBtnEnabled
          ? RECORDING_STATE.outerSize
          : INITIAL_STATE.outerSize,
        borderRadius: 50,
        borderWidth: 4,
        borderColor: '#C30303',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View
        style={{
          width: props.recordingBtnEnabled
            ? RECORDING_STATE.innerSize
            : INITIAL_STATE.innerSize,
          height: props.recordingBtnEnabled
            ? RECORDING_STATE.innerSize
            : INITIAL_STATE.innerSize,
          borderRadius: 50,
          //   borderWidth: 5,
          borderColor: '#C30303',
          backgroundColor: '#C30303',
        }}></View>
    </TouchableOpacity>
  );
};
const mapStateToProps = (state) => ({
  recordingBtnEnabled: state.EditorReducer.recordingBtnEnabled,
  editorMode: state.EditorReducer.editorMode,
});
export default connect(mapStateToProps, null)(CaptureButton);
