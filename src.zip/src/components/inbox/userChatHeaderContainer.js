import React, {Component} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import ArrowBackWhiteSVG from '../../icons/arrowBackWhiteSVG';
import StarWhiteSVG from '../../icons/startWhiteSVG';
class UserChatHeaderContainer extends Component {
  state = {};
  render() {
    return (
      <View
        style={{
          width: '100%',
          height: 60,
          backgroundColor: SECONDRY_BLACK,
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => this.props.navigation.goBack()}
          style={{
            width: 50,
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <ArrowBackWhiteSVG size={16} />
        </TouchableOpacity>
        <View style={{flex: 1}}>{this.props.children}</View>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={this.props.onPressRight}
          style={{
            width: 50,
            height: '100%',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {this.props.rightIcon ? (
            this.props.rightIcon(props)
          ) : (
            <StarWhiteSVG size={16} />
          )}
        </TouchableOpacity>
      </View>
    );
  }
}

export default UserChatHeaderContainer;
