import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import MyTextIconButton from './myTextIconButton';
import Icon from 'react-native-vector-icons/FontAwesome5';

const ShareBox = (props) => {
  return (
    <View style={Styles.container}>
      <View style={{height: 30}}>
        <Text style={{color: 'white', alignSelf: 'center', marginTop: 5}}>
          Share
        </Text>
        <TouchableOpacity
          style={{
            alignSelf: 'flex-end',
            paddingRight: 10,
            paddingLeft: 10,
            marginRight: 20,
            marginTop: -15,
          }}>
          <Icon size={18} color={WHITE_COLOR} name="caret-right" />
        </TouchableOpacity>
      </View>
      <ScrollView horizontal style={Styles.scrollViewStyle}>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="username" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
      </ScrollView>
      <ScrollView horizontal style={Styles.scrollViewStyle}>
        <MyTextIconButton title="Message" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Snapchat" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Instagram" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Twitter" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Tiktok" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
      </ScrollView>
      <ScrollView horizontal style={Styles.scrollViewStyle}>
        <MyTextIconButton title="Save" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Duet" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Layer" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="More" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
        <MyTextIconButton title="Less" fontSize={12} size={60}>
          <View style={Styles.dimCmp} />
        </MyTextIconButton>
      </ScrollView>
    </View>
  );
};
export default ShareBox;

const Styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 330,
    backgroundColor: SECONDRY_BLACK,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  scrollViewStyle: {
    height: 80,
    width: '100%',
  },
  dimCmp: {
    width: 50,
    height: 50,
    borderRadius: 50,
    backgroundColor: WHITE_COLOR,
  },
});
