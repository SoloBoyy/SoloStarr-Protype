import React, {Component} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
const UserChatHeader = (props) => {
  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={() => false}
      style={{
        alignSelf: 'center',
        backgroundColor: SECONDRY_BLACK,
        minHeight: 40,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
      <View
        style={{
          flexDirection: 'row',
          alignSelf: 'center',
          backgroundColor: 'transparent',
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <View
          style={{
            minWidth: 35,
          }}>
          <Image
            style={[
              {
                width: 35,
                height: 36,
                borderRadius: 50,
                backgroundColor: '#f0f0f0',
                marginRight: 20,
              },
              {...props.imageStyle},
            ]}
            source={require('../../assets/userimg.jpg')}
          />
        </View>

        <Text
          style={{
            color: WHITE_COLOR,
            fontSize: 15,
            fontWeight: 'bold',
            textShadowColor: '#f0f0f0',
            textShadowRadius: 3,
          }}>
          Chris Gullette
        </Text>
      </View>
    </TouchableOpacity>
  );
};

export default UserChatHeader;
