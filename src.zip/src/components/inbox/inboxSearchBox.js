import React, {useRef} from 'react';
import {View, Text, TextInput, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {WHITE_COLOR} from '../../themes/colors';
const InboxSearchBox = (props) => {
  const isSearchMode = props.isSearchMode ? true : false;
  const textInputRef = useRef();
  return (
    <View
      style={{
        width: '100%',
        height: 50,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View
        style={{
          flex: 1,
          height: 35,
          backgroundColor: 'black',
          flexDirection: 'row',
          alignItems: 'center',
          borderRadius: 50,
          paddingLeft: 5,
          paddingRight: 5,
          ...props.style,
        }}>
        <Icon
          style={{color: WHITE_COLOR, width: 20, paddingLeft: 5}}
          name="search"
        />
        <TextInput
          ref={textInputRef}
          onFocus={() =>
            props.onChangeMode ? props.onChangeMode(true) : false
          }
          style={{flex: 1, color: 'white', marginBottom: -3}}
        />
      </View>
      {isSearchMode ? (
        <TouchableOpacity
          onPress={() => {
            if (props.onChangeMode) {
              props.onChangeMode(false);
            }
            textInputRef.current.blur();
          }}
          activeOpacity={1}
          style={{
            width: 60,
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{color: WHITE_COLOR}}>Cancel</Text>
        </TouchableOpacity>
      ) : (
        false
      )}
    </View>
  );
};
export default InboxSearchBox;
