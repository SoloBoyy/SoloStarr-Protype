import React, {Component} from 'react';
import {
  View,
  StatusBar,
  StyleSheet,
  Text,
  Dimensions,
  Platform,
  PermissionsAndroid,
} from 'react-native';
import ControlsOverlay from '../components/controlsOverlay';
import {RNCamera} from 'react-native-camera';
import MyLayoutManager from '../Controllers/layoutManager';
import MyRecordingController from '../Controllers/recordingConroller';
import {connect} from 'react-redux';
import RNFS from 'react-native-fs';
import MyAlertBoxController from '../Controllers/myAlertBoxController';
// file:///data/user/0/com.tkteditor/cache/Camera/jhkhkdfhksjfhfjfie15.mp4
class VideoMakingScreen extends Component {
  constructor() {
    super();
    this.state = {
      isFront: false,
      isRecording: false,
      recordedSource: [],
      isPlaying: false,
      isProcessing: false,
    };
    this.camera = null;
  }
  componentDidMount() {
    MyLayoutManager.setRootContext(this);
    MyRecordingController.setCameraRef(this.camera);
    this.checkStoragePermission()
      .then((granted) => {
        if (!granted) {
          PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
          )
            .then((granted) => {
              console.log('Permission Granted By User');
              MyRecordingController.checkMemory()
                .then((success) => console.log('Memory Available'))
                .catch((err) => {
                  MyAlertBoxController.show(
                    MyAlertBoxController.ACTIONS_OKAY,
                    err,
                    (result) => false,
                  );
                });
              this.checkCameraPermission();
            })
            .catch((err) => {
              console.log('PERMISSION NOT GRANGED');
              console.log(err);
            });
        } else {
          MyRecordingController.checkMemory()
            .then((success) => console.log('Memory Available'))
            .catch((err) => {
              MyAlertBoxController.show(
                MyAlertBoxController.ACTIONS_OKAY,
                err,
                (result) => false,
              );
            });
          console.log('PERMISSION ALREADY GRANTED');
        }
      })
      .catch((err) => {
        console.log('Error in Checking PERMISSION');
      });
  }

  // checkMemory = () => {
  //   return new Promise((resolve, reject) => {
  //     console.log('Checking memory');
  //     RNFS.getFSInfo()
  //       .then((info) => {
  //         let availableMemory = info.freeSpace / 1024 / 1024;
  //         if (availableMemory > 300) {
  //           resolve(true);
  //         } else {
  //           reject(
  //             `Memory Warning! Free space ${Math.round(availableMemory)} MB`,
  //           );
  //         }
  //       })
  //       .catch((err) => {
  //         console.log('ERROR In Checking Memory Info');
  //         console.log(err);
  //         reject('NO STORAGE PERMISSONS');
  //       });
  //   });
  // };

  checkStoragePermission = () => {
    return new Promise((resolve, reject) => {
      if (Platform.OS === 'android') {
        PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        )
          .then((result) => {
            if (result === 'granted') {
              resolve(true);
            } else {
              reject(false);
            }
          })
          .catch((err) => {
            reject(false);
          });
      } else {
        ////TODO:IOS, Permission add
        resolve(true);
      }
    });
  };

  checkCameraPermission = () => {
    return new Promise((resolve, reject) => {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA)
        .then((granted) => {
          if (!granted) {
            PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA)
              .then((granted) => {
                console.log('Permission Granted By User');
                checkAudioPermission()
                  .then((granted) => {
                    this.checkAudioPermission()
                      .then((granted) => {
                        resolve(true);
                      })
                      .catch((err) => {
                        console.log('Not Granted');
                      });
                  })
                  .catch((err) => {
                    reject(false);
                  });
              })
              .catch((err) => {
                console.log('PERMISSION NOT GRANGED');
                console.log(err);
                reject(false);
              });
          } else {
            console.log('PERMISSION ALREADY GRANTED');
            resolve(true);
          }
        })
        .catch((err) => {
          console.log('Error in Checking PERMISSION');
          reject(false);
        });
    });
  };
  checkAudioPermission = () => {
    return new Promise((resolve, reject) => {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO)
        .then((granted) => {
          if (!granted) {
            PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
            )
              .then((granted) => {
                console.log('Permission Granted By User');
                resolve(true);
              })
              .catch((err) => {
                console.log('PERMISSION NOT GRANGED');
                console.log(err);
                reject(false);
              });
          } else {
            console.log('PERMISSION ALREADY GRANTED');
            resolve(true);
          }
        })
        .catch((err) => {
          console.log('Error in Checking PERMISSION');
          reject(false);
        });
    });
  };
  toggleCam = () => {
    this.setState({isFront: !this.state.isFront});
  };

  render() {
    const {width, height} = Dimensions.get('window');

    return (
      <View style={[Styles.container, {width, height}]}>
        <StatusBar hidden />

        <RNCamera
          ref={(ref) => {
            this.camera = ref;
            MyRecordingController.setCameraRef(ref);
          }}
          zoom={this.props.camZoom}
          playSoundOnCapture={true}
          onRecordingStart={({nativeEvent}) => {
            console.log('ON RECORDING START');
            console.log(nativeEvent);
            MyRecordingController.startProgress();
          }}
          onRecordingEnd={() => {
            console.log('END CALLED');
          }}
          style={{
            width,
            height,
          }}
          type={
            this.state.isFront
              ? RNCamera.Constants.Type.front
              : RNCamera.Constants.Type.back
          }
          flashMode={this.props.flashMode}
          useCamera2Api={true}
          androidRecordAudioPermissionOptions={{
            title: 'Permission to use audio recording',
            message: 'We need your permission to use your audio',
            buttonPositive: 'Ok',
            buttonNegative: 'Cancel',
          }}
        />

        <ControlsOverlay />
      </View>
    );
  }
}
const mapStateToProps = (state) => ({
  flashMode: state.EditorReducer.flashMode,
  camZoom: state.EditorReducer.recorder.camZoom,
});
export default connect(mapStateToProps, null)(VideoMakingScreen);

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#111111',
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
});
