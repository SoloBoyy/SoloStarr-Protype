import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const MoodSVG = props => {
  const size = props.size ? props.size : 100;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<?xml version="1.0"?>
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="512" height="512" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
      <g xmlns="http://www.w3.org/2000/svg">
        <g>
          <path d="M497,51H15C6.716,51,0,57.716,0,66v380c0,8.284,6.716,15,15,15h482c8.284,0,15-6.716,15-15V66    C512,57.716,505.284,51,497,51z" fill="#c4c4c4" data-original="#000000" style="" class=""/>
        </g>
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      </g></svg>
      
`}
    />
  );
};
export default MoodSVG;
