import React, {Component} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';

const UserInfoItem = (props) => {
  const size = 55;
  const isSelected = true;
  return (
    <View
      style={{
        width: '100%',
        height: size + 10,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View style={{flex: 3, flexDirection: 'row', alignItems: 'center'}}>
        <Image
          style={{
            width: size,
            height: size,
            borderRadius: 50,
            backgroundColor: '#555555',
          }}
        />
        <View style={{padding: 10}}>
          <Text style={{color: WHITE_COLOR, fontSize: size / 3.5}}>
            username
          </Text>
          <Text style={{color: 'gray', fontSize: size / 5}}>username</Text>
        </View>
      </View>
    </View>
  );
};
export default UserInfoItem;
