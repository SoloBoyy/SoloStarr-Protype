import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const FeatherSendWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="21.425" height="21.425" viewBox="0 0 21.425 21.425">
  <g id="Icon_feather-send" data-name="Icon feather-send" transform="translate(-2 -1.586)">
    <path id="Path_2196" data-name="Path 2196" d="M26.956,3,16.5,13.456" transform="translate(-4.945)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_2197" data-name="Path 2197" d="M22.011,3,15.357,22.011l-3.8-8.555L3,9.654Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default FeatherSendWhiteSVG;
