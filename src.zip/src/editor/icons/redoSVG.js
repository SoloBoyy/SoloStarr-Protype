import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const RedoSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="263.917" height="263.92" viewBox="0 0 263.917 263.92">
  <path id="Icon_awesome-redo" fill="white" stroke="white" data-name="Icon awesome-redo" d="M182.828,0H165.276a4.443,4.443,0,0,0-4.443,4.654l1.481,30.639A91.812,91.812,0,1,0,153.9,162.926a4.443,4.443,0,0,0,.178-6.453l-12.587-12.587a4.443,4.443,0,0,0-6.064-.2,65.157,65.157,0,1,1,11.04-85.263l-37.587-1.8a4.443,4.443,0,0,0-4.654,4.443V78.61a4.443,4.443,0,0,0,4.443,4.443h74.164a4.442,4.442,0,0,0,4.443-4.443V4.443A4.443,4.443,0,0,0,182.828,0Z" transform="matrix(0.695, -0.719, 0.719, 0.695, -0.391, 134.711)"/>
</svg>
`}
    />
  );
};
export default RedoSVG;
