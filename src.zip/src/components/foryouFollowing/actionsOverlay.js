import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import MyTextIconButton from './myTextIconButton';
import {SECONDRY_BLACK} from '../../themes/colors';
import LikedWhiteSVG from '../../icons/likedWhiteSVG';
import LikedRedSVG from '../../icons/likedRedSVG';
import CommentWhiteSVG from '../../icons/commentWhiteSVG';
import ShareWhiteSVG from '../../icons/shareWhiteSVG';
import MyForYouController from '../../controllers/forYouController';
import LinearGradient from 'react-native-linear-gradient';
import {navigate} from '../../navigator';
// import CircleButton from '../';

const BUTTON_SIZE = 50;

const ActionsOverlay = (props) => {
  const [isLiked, setIsLiked] = useState(props.story.liked);

  useEffect(() => {
    setIsLiked(props.story.liked);
  }, [props.story.liked]);

  return (
    <View style={[Styles.container, {...props.style}]}>
      <MyTextIconButton
        onPress={() => {
          MyForYouController.setVideoPlayable(false);
          navigate('UserProfileScreen');
        }}
        size={BUTTON_SIZE}
        title="107k">
        {/* <View
          style={{
            width: 45,
            height: 45,
            backgroundColor: 'white',
            borderRadius: 50,
          }}
        /> */}
        <LinearGradient
          style={{
            width: 40,
            height: 40,
            borderRadius: 50,
          }}
          colors={['#f0f0f0', 'gray']}
        />
      </MyTextIconButton>
      <MyTextIconButton
        onPress={() => {
          setIsLiked(!isLiked);
          setTimeout(() => {
            props.onPressLike();
          }, 0);
        }}
        size={BUTTON_SIZE}
        title="107k">
        {isLiked ? <LikedRedSVG /> : <LikedWhiteSVG />}
      </MyTextIconButton>
      <MyTextIconButton
        onPress={props.onPressComment}
        size={BUTTON_SIZE}
        title="1.9k">
        <CommentWhiteSVG />
      </MyTextIconButton>
      <MyTextIconButton
        onPress={props.onPressShare}
        size={BUTTON_SIZE}
        title="107k">
        <ShareWhiteSVG />
      </MyTextIconButton>
    </View>
  );
};
export default ActionsOverlay;

const Styles = StyleSheet.create({
  container: {
    width: 70,
  },
});
