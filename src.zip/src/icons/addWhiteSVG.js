import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const addWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="22.076" height="22.076" viewBox="0 0 22.076 22.076">
  <path id="Icon_ionic-ios-add" data-name="Icon ionic-ios-add" d="M29.667,18.629H21.377V10.339a1.374,1.374,0,1,0-2.749,0v8.289H10.339a1.374,1.374,0,0,0,0,2.749h8.289v8.289a1.374,1.374,0,0,0,2.749,0V21.377h8.289a1.374,1.374,0,0,0,0-2.749Z" transform="translate(-8.965 -8.965)" fill="#fff"/>
</svg>
`}
    />
  );
};
export default addWhiteSVG;
