import React from 'react';
import {View} from 'react-native';

const StaticBar = (props) => {
  const peak = props.peak ? props.peak : 60;
  const seek = props.seek ? props.seek : 0;
  const clipsCount = props.clipsCount ? props.clipsCount : 0;
  const duration = props.duration ? props.duration : 0;
  const isFirstIndex = props.pIndex === 0 ? true : false;
  const isFullProgress = seek >= peak;
  const isLast = isFullProgress && clipsCount - 1 === props.pIndex;
  // console.log(`Seek ${seek} Peak: ${peak} isLast ${props.clipsCount}`);
  const roundBorderWidth = 20;
  return (
    <View
      style={{
        width: `${(duration / peak) * 100}%`,
        height: '100%',
        alignItems: 'flex-end',
        justifyContent: 'flex-start',
        backgroundColor: '#DD2E2E',
        borderTopLeftRadius: isFirstIndex ? roundBorderWidth : 0,
        borderBottomLeftRadius: isFirstIndex ? roundBorderWidth : 0,
        borderTopRightRadius: isLast ? roundBorderWidth : 0,
        borderBottomRightRadius: isLast ? roundBorderWidth : 0,
      }}>
      {!isLast ? (
        <View style={{width: 1, backgroundColor: 'black', height: '50%'}} />
      ) : (
        false
      )}
    </View>
  );
};
export default StaticBar;
