import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const ArrowBackSvg = (props) => {
  const size = props.size ? props.size : 18;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="19.011" height="19.011" viewBox="0 0 19.011 19.011">
      <path id="Icon_ionic-md-arrow-back" data-name="Icon ionic-md-arrow-back" d="M24.988,14.294H10.551L17.205,7.64,15.482,5.977,5.977,15.482l9.506,9.506,1.663-1.663L10.551,16.67H24.988Z" transform="translate(-5.977 -5.977)" fill="#fff"/>
    </svg>`}
    />
  );
};
export default ArrowBackSvg;
