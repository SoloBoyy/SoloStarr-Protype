import React, {Component} from 'react';

import {
  View,
  Text,
  ImageBackground,
  Image,
  Animated,
  PanResponder,
  StatusBar,
  Modal,
} from 'react-native';
// import Animated from 'react-native-reanimated';
import {
  PinchGestureHandler,
  PanGestureHandler,
  State,
} from 'react-native-gesture-handler';
import MaskedView from '@react-native-community/masked-view';
import CheckMarkGreenSVG from '../icons/checkMarkGreenSVG';
import {Svg, Defs, Rect, Mask, Circle} from 'react-native-svg';
import CircleButton from '../components/inbox/circleButton';
import {goBack} from '../navigator';
const AnimatedCircle = Animated.createAnimatedComponent(Circle);
class ImageCropScreen extends Component {
  constructor() {
    super();
    this.state = {};
    this.baseScale = new Animated.Value(1);
    this.pinchScale = new Animated.Value(1);
    this.mRef = null;
    this.selectCircleRef = null;
    this.lastScale = 1;
    this._translateX = new Animated.Value(0);
    this._translateY = new Animated.Value(0);
    this._translateX.setOffset(0);
    this._translateY.setOffset(0);
    this._absoluteX = new Animated.Value(0);
    this._absoluteY = new Animated.Value(0);
    this._lastOffset = {x: 0, y: 0};
    this.scale = Animated.multiply(this.baseScale, this.pinchScale);

    this.onGestureEvent = Animated.event(
      [{nativeEvent: {scale: this.pinchScale}}],
      {useNativeDriver: true},
    );
    this.onChangeGestureState = ({nativeEvent}) => {
      if (nativeEvent.oldState === State.ACTIVE) {
        this.lastScale *= nativeEvent.scale;
        this.baseScale.setValue(this.lastScale);
        this.pinchScale.setValue(1);
      }
    };

    this.onPanGestureEvent = Animated.event(
      [
        {
          nativeEvent: {
            translationX: this._translateX,
            translationY: this._translateY,
            x: this._absoluteX,
            y: this._absoluteY,
          },
        },
      ],
      {useNativeDriver: true},
    );
    this._onPanHandlerStateChange = (event) => {
      console.log(event.nativeEvent);
      if (event.nativeEvent.oldState === State.ACTIVE) {
        this._lastOffset.x += event.nativeEvent.translationX;
        this._lastOffset.y += event.nativeEvent.translationY;
        this._translateX.setOffset(this._lastOffset.x);
        this._translateX.setValue(0);
        this._translateY.setOffset(this._lastOffset.y);
        this._translateY.setValue(0);
      }
    };
  }

  handleGoBack = () => {
    goBack();
  };

  componentDidMount() {}
  render() {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'black',
        }}>
        <MaskedView
          style={{
            flex: 1,
            flexDirection: 'row',
            height: '100%',
          }}
          maskElement={
            <Animated.View
              ref={(e) => (this.mRef = e)}
              style={{
                backgroundColor: 'rgba(255,255,255,0.5)',
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Animated.View
                style={{
                  width: 200,
                  height: 200,
                  borderRadius: 100,
                  backgroundColor: 'black',
                  transform: [
                    {translateX: this._translateX},
                    {translateY: this._translateY},
                    {scale: this.scale},
                  ],
                }}
              />
            </Animated.View>
          }>
          <Image
            style={{width: '100%', height: '100%'}}
            source={require('../assets/SAMPLE02.jpg')}
          />
        </MaskedView>

        <Animated.View
          style={{
            width: '100%',
            height: '100%',
            backgroundColor: 'transparent',
            position: 'absolute',
            top: 0,
            left: 0,
          }}>
          <View
            style={{position: 'absolute', right: 20, bottom: 20, zIndex: 9999}}>
            <CircleButton
              onPress={() => this.handleGoBack()}
              size={45}
              style={{backgroundColor: 'black'}}
              invert
              Icon={() => (
                <CheckMarkGreenSVG
                  onPress={() => this.handleGoBack()}
                  size={25}
                />
              )}
            />
          </View>
          <PanGestureHandler
            onGestureEvent={this.onPanGestureEvent}
            onHandlerStateChange={this._onPanHandlerStateChange}
            maxPointers={1}
            minPointers={1}>
            <Animated.View
              style={{
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <PinchGestureHandler
                onGestureEvent={this.onGestureEvent}
                onHandlerStateChange={this.onChangeGestureState}>
                <Animated.View
                  style={{
                    width: '100%',
                    height: '100%',
                    transform: [
                      {translateX: this._translateX},
                      {translateY: this._translateY},
                      {scale: this.scale},
                    ],
                  }}
                />
              </PinchGestureHandler>
            </Animated.View>
          </PanGestureHandler>
        </Animated.View>
      </View>
    );
  }
}

export default ImageCropScreen;
