import React, {useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import MySquareButton from '../mySquareButton';
import BarSelect from './barSelect';
import {SECONDRY_BLACK} from '../../../themes/colors';
import MyRecordingController from '../../Controllers/recordingConroller';
import MyLayoutManager from '../../Controllers/layoutManager';
import {connect} from 'react-redux';
const TimerSelect = (props) => {
  //// TODO: Make the selected value presistable
  const [selectedValue, setSelectedValue] = useState({
    _id: '1234',
    title: '0s',
    value: 0,
    selected: true,
  });

  const _handleStartRecording = () => {
    MyRecordingController.setTimerTimeoutValue(selectedValue.value);
    // MyRecordingController.setRecordingBtnEnabled(true);
    MyRecordingController.toggleCam();
    MyLayoutManager.setBottomOptionMenuMode(false);
  };

  return (
    <View style={Styles.container}>
      <View style={{flex: 1}}>
        <View style={{height: 20}} />
        <BarSelect
          selectedValue={props.timerDefaultValue}
          options={[
            {_id: '1234', title: '0s', value: 0, selected: true},
            {_id: '123', title: '3s', value: 3, selected: false},
            {_id: '234', title: '5s', value: 5, selected: false},
            {_id: '345', title: '10s', value: 10, selected: false},
          ]}
          onSelect={(value) => {
            MyRecordingController.setKeyValue({
              key: 'timerDefaultValue',
              value: value.value,
            });
            MyRecordingController.setKeyValue({
              key: 'timerTimeout',
              value: value.value,
            });
            setSelectedValue(value);
          }}
        />
      </View>
      <MySquareButton onPress={_handleStartRecording} title="Start shooting" />
    </View>
  );
};
const mapStateToProps = (state) => ({
  timerDefaultValue: state.EditorReducer.timerDefaultValue,
});
export default connect(mapStateToProps, null)(TimerSelect);

const Styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 200,
    backgroundColor: SECONDRY_BLACK,
    alignSelf: 'center',
  },
  startShootButton: {},
});
