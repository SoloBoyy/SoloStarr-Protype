import React, {Component, useEffect, useState} from 'react';
import {View, TouchableOpacity} from 'react-native';
import Animated from 'react-native-reanimated';
import {SECONDRY_BLACK} from '../../themes/colors';
import TabButton from './tabButton';

const MyTabBar = ({state, descriptors, navigation, position, onChange}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  useEffect(() => {
    if (onChange) {
      onChange(state.routes[state.index]);
    }
  }, [state.index]);
  return (
    <View
      style={{
        flexDirection: 'row',
        height: 40,
        backgroundColor: SECONDRY_BLACK,
      }}>
      {state.routes.map((route, index) => {
        // const {options} = descriptors[route.key];
        // const label =
        //   options.tabBarLabel !== undefined
        //     ? options.tabBarLabel
        //     : options.title !== undefined
        //     ? options.title
        //     : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        // const onLongPress = () => {
        //   navigation.emit({
        //     type: 'tabLongPress',
        //     target: route.key,
        //   });
        // };

        // const inputRange = state.routes.map((_, i) => i);
        // const opacity = Animated.interpolate(position, {
        //   inputRange,
        //   outputRange: inputRange.map((i) => (i === index ? 1 : 0)),
        // });

        return (
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <TabButton
              {...{
                title: route.name,
                selected: isFocused,
                onPress,
              }}
            />
          </View>
        );
      })}
    </View>
  );
};

export default MyTabBar;

// <TouchableOpacity
//           accessibilityRole="button"
//           accessibilityState={isFocused ? {selected: true} : {}}
//           accessibilityLabel={options.tabBarAccessibilityLabel}
//           testID={options.tabBarTestID}
//           onPress={onPress}
//           onLongPress={onLongPress}
//           style={{flex: 1}}>
//           <Animated.Text style={{opacity}}>{label}</Animated.Text>
//         </TouchableOpacity>
