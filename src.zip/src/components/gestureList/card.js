import React, {useState} from 'react';
import {View, Text, Animated, Dimensions, TouchableOpacity} from 'react-native';
import {WHITE_COLOR} from '../../themes/colors';
export const CARD_HEIGHT = 70;
export const CARD_WIDTH = 70;
const Card = ({index, x, title, isTransparent, onPress}) => {
  const {height, width} = Dimensions.get('window');

  const position = Animated.subtract(index * CARD_WIDTH, x);
  const isDisapearing = -CARD_WIDTH;
  const isTop = width * 0.45;
  const isBottom = width * 0.45;
  const isApearing = width;

  const translateY = Animated.add(
    x,
    x.interpolate({
      inputRange: [0, index * CARD_WIDTH],
      outputRange: [0, -index * CARD_WIDTH],
      extrapolateRight: 'clamp',
    }),
  );
  const scale = position.interpolate({
    inputRange: [isDisapearing, isTop, isBottom, isApearing],
    outputRange: [0.3, 1, 1, 0.3],
    extrapolate: 'clamp',
  });
  const opacity = position.interpolate({
    inputRange: [isDisapearing, isTop, isBottom, isApearing],
    outputRange: [0.5, 1, 1, 0.5],
    extrapolate: 'clamp',
  });
  return (
    <Animated.View
      key={index}
      style={{
        width: CARD_WIDTH,
        height: CARD_HEIGHT,
        alignSelf: 'center',
        borderRadius: 50,
        justifyContent: 'flex-end',
        alignItems: 'center',
        marginBottom: 100,
        backgroundColor: isTransparent ? 'transparent' : 'black',
        opacity,
        transform: [{scale}],
      }}>
      <TouchableOpacity
        onPress={onPress}
        style={{
          width: '100%',
          height: '100%',
          alignSelf: 'center',
          borderRadius: 50,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: isTransparent ? 'transparent' : WHITE_COLOR,
        }}
      />
      <Text
        style={{
          color: isTransparent ? 'transparent' : 'white',
          position: 'absolute',
          transform: [{translateY: 20}],
        }}>
        {title}
      </Text>
    </Animated.View>
  );
};

export default Card;
