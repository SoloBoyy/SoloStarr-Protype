import produce from 'immer';
import {
  COMMENTED,
  LIKED,
  MENSIONED,
  FOLLOWED,
} from '../../components/inbox/activityTypeItem';
import {SET_ACTIVITY_TYPE_FILTER} from '../../controllers/types';
const state = {
  activities: [
    {_id: 100, username: 'Yesterday', desc: 'username', type: 'd'},
    {_id: 1, username: 'username', desc: 'username', type: LIKED},
    {_id: 2, username: 'username', desc: 'username', type: COMMENTED},
    {_id: 3, username: 'username', desc: 'username', type: MENSIONED},
    {_id: 4, username: 'username', desc: 'username', type: FOLLOWED},
    {_id: 5, username: 'username', desc: 'username', type: LIKED},
    {_id: 50, username: 'This Month', desc: 'username', type: 'd'},
    {_id: 6, username: 'username', desc: 'username', type: COMMENTED},
    {_id: 7, username: 'username', desc: 'username', type: MENSIONED},
    {_id: 8, username: 'username', desc: 'username', type: FOLLOWED},
    {_id: 9, username: 'username', desc: 'username', type: LIKED},
    {_id: 10, username: 'username', desc: 'username', type: COMMENTED},
    {_id: 11, username: 'username', desc: 'username', type: MENSIONED},
    {_id: 12, username: 'username', desc: 'username', type: FOLLOWED},
  ],
  typeFilter: '',
};

const ActivityReducer = (mState = {...state}, action) => {
  switch (action.type) {
    case SET_ACTIVITY_TYPE_FILTER:
      return produce(mState, (draftState) => {
        draftState.typeFilter = action.payload;
      });
    default:
      return {...mState};
  }
};
export default ActivityReducer;
