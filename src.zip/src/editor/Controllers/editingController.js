import store from '../../store';
import RNFS from 'react-native-fs';
// import RNVideoEditor from 'react-native-video-editor';
import {
  SET_EDITOR_LAYOUT_MODE,
  SET_EDITOR_KEY_VALUE,
  UPDATE_RECOORDED_CLIP_VALUE,
  HANDLE_PLAY_NEXT_CLIP,
  SET_VIDEO_PLAYING_MODE,
} from '../actionTypes';
// import uuid from 'react-native-uuid';
// import {RNFFmpeg, RNFFprobe} from 'react-native-ffmpeg';
import MyLayoutManager from './layoutManager';
// import MyVideoProcessingControllerFFmpeg from './videoProcessingControllerFFmpeg';
import MyRecordingController from './recordingConroller';
import MyAlertBoxController from './myAlertBoxController';
import {createThumbnail} from 'react-native-create-thumbnail';
class EditingController {
  constructor() {
    this.OUTPUTPATH = '';

    this.setEditingKeyValue = (key, value) => {
      store.dispatch({
        type: SET_EDITOR_KEY_VALUE,
        payload: {
          key,
          value,
        },
      });
    };

    this.getVideoInfo = (source) => {
      // ProcessingManager.getVideoInfo(source)
      //   .then(({duration, size, frameRate, bitrate}) => {
      //     console.log(
      //       `Video Info Duration ${duration} Size ${size} Framerate ${frameRate} Bitrate ${bitrate}`,
      //     );
      //   })
      //   .catch((err) => {
      //     console.log('CATCH, error in getting video info');
      //     console.log(err);
      //   });
    };

    this.extractPreviewforClip = (rec) => {
      if (rec.info.thumbnail === null) {
        createThumbnail({
          url: rec.source.uri,
          timeStamp: 10000,
        })
          .then((thumbnail) => {
            let mrec = {...rec};
            mrec.info = {
              duration: 0,
              thumbnail: {uri: thumbnail.path},
            };
            // console.log(mrec);
            store.dispatch({
              type: UPDATE_RECOORDED_CLIP_VALUE,
              payload: mrec,
            });
          })
          .catch((error) => {
            console.log('ERROR In Getting Vidio Info');
            console.log(error);
          });
      }

      // ProcessingManager.getVideoInfo(rec.source.uri)
      //   .then((vidInfo) => {
      //     console.log('=Video Info');
      //     console.log(vidInfo);
      //     const maximumSize = {
      //       width: vidInfo.size.width / 5,
      //       height: vidInfo.size.height / 5,
      //     };
      //     if (rec.info.thumbnail === null) {
      //       ProcessingManager.getPreviewForSecond(
      //         rec.source.uri,
      //         0,
      //         maximumSize,
      //       )
      //         .then((vidPreview) => {
      //           console.log('IMAGE PREVIEW');
      //           let mrec = {...rec};
      //           mrec.info = {
      //             duration: vidInfo.duration,
      //             thumbnail: vidPreview,
      //           };
      //           // console.log(mrec);
      //           store.dispatch({
      //             type: UPDATE_RECOORDED_CLIP_VALUE,
      //             payload: mrec,
      //           });
      //         })
      //         .catch((error) => {
      //           console.log('ERROR In Extracting and Saving video Preview');
      //           console.log(error);
      //         });
      //     }
      //     // rec.info.thumbnail = previewImage;
      //     // console.log('RECODING PREVIEW>>>>');
      //     // console.log(rec);
      //   })
      //   .catch((error) => {
      //     console.log('ERROR In Getting Vidio Info');
      //     console.log(error);
      //   });
    };

    this.handlePlayNext = () => {
      store.dispatch({
        type: HANDLE_PLAY_NEXT_CLIP,
      });
    };

    this.setPlayingMode = (mode) => {
      store.dispatch({
        type: SET_VIDEO_PLAYING_MODE,
        payload: mode,
      });
    };

    this.extractAndSaveVideoPreviews = () => {
      const recordings = store.getState().EditorReducer.recorder.recordings;

      recordings.forEach((rec) => {
        console.log('Recording');
        console.log(rec);
        this.extractPreviewforClip(rec);
        // rec.info.thumbnail = previewImage;
        // console.log('RECODING PREVIEW>>>>');
        // console.log(rec);
      });
    };

    this.checkIfRecordingExist = (recordings) => {
      return new Promise(async (resolve, reject) => {
        try {
          let validRecordings = [];
          let errorMessage = 'low memory Recordings ';
          let isError = false;
          for (let index = 0; index < recordings.length; index++) {
            const rec = recordings[index];
            let fileExists = RNFS.exists(rec);
            if (fileExists) {
              validRecordings.push(rec);
            } else {
              errorMessage = `${errorMessage} ${index + 1} `;
              isError = true;
            }
          }
          errorMessage = `${errorMessage} destroyed`;
          console.log('ERROR');
          console.log(errorMessage);
          if (isError) {
            console.log('RESOLVING WITH ERROR');
            resolve({
              error: errorMessage,
              isValid: false,
              recordings: validRecordings,
            });
          } else {
            console.log('RESOLVING WITH SUCCESS');
            resolve({isValid: true, recordings: validRecordings});
          }
        } catch (error) {
          reject(error);
        }
      });
    };

    this.processVideo = () => {
      return new Promise((resolve, reject) => {
        let recorder = store.getState().EditorReducer.recorder;
        let isChangeSaved = store.getState().EditorReducer.isChangeSaved;
        let initialVideoSource = store.getState().EditorReducer.editor
          .initialVideoSource;
        console.log('TEST 1, Checking Changes...');
        if (isChangeSaved) {
          console.log('Changes Already saved!');
          MyLayoutManager.setLoaderVisible(false, '');
          resolve(initialVideoSource);
        } else {
          console.log('TEST 2, Processing...');

          // let recordings = recorder.recordings.map((r) => r.source.uri);
          let recordings = [];

          /// checking of Slomo or fasto is there
          let needSpeedFilter = false;
          // for (let index = 0; index < recorder.recordings.length; index++) {
          //   const sr = recorder.recordings[index];
          //   if (sr.recordingSpeed !== 1) {
          //     needSpeedFilter = true;
          //     break;
          //   }
          // }

          if (needSpeedFilter) {
            // console.log('TEST 3, Need Speed Filter, Applying...');
            // this.applySpeedEffects(recorder.recordings)
            //   .then((res) => {
            //     recorder = store.getState().EditorReducer.recorder;
            //     MyLayoutManager.setLoaderVisible(true, `composing...`);
            //     for (
            //       let index = 0;
            //       index < recorder.recordings.length;
            //       index++
            //     ) {
            //       const sR = recorder.recordings[index];
            //       if (sR.recordingSpeed === 1) {
            //         recordings.push(sR.source.uri);
            //       } else {
            //         recordings.push(sR.processedSource.uri);
            //       }
            //     }
            //     // console.log('MERGIN VIDEOS');
            //     // console.log(recordings);
            //     //  recordings = recorder.recordings.map((r) => r.source.uri);
            //     // this.mergeVideos(recordings)
            //     //   .then((outputVideo) => {
            //     //     this.setEditingKeyValue('initialVideoSource', {
            //     //       uri: outputVideo,
            //     //     });
            //     //     MyRecordingController.setKeyValue({
            //     //       key: 'isChangeSaved',
            //     //       value: true,
            //     //     });
            //     //     MyLayoutManager.setLoaderVisible(false, '');
            //     //     resolve(outputVideo);
            //     //   })
            //     //   .catch((err) => {
            //     //     console.log('ERROR, In Videos ');
            //     //     console.log(err);
            //     //     MyLayoutManager.setLoaderVisible(false, '');
            //     //     reject(err);
            //     //   });
            //     let command = MyVideoProcessingControllerFFmpeg.prepareCasheOUTPUT().generateConcatinateCommand(
            //       recordings,
            //     );
            //     // console.log('++++++++++++++VIDEO CONCATINATING COMMAND');
            //     // console.log(command);
            //     MyVideoProcessingControllerFFmpeg.executeFFmpegCmd(command)
            //       .then((outputVideo) => {
            //         this.setEditingKeyValue('initialVideoSource', {
            //           uri: outputVideo,
            //         });
            //         MyRecordingController.setKeyValue({
            //           key: 'isChangeSaved',
            //           value: true,
            //         });
            //         MyLayoutManager.setLoaderVisible(false, '');
            //         resolve(outputVideo);
            //         // let convertCmd = MyVideoProcessingControllerFFmpeg.prepareCasheOUTPUT().generateConvertionCommand(
            //         //   outputVideo,
            //         // );
            //         // MyLayoutManager.setLoaderVisible(true, 'convertin...');
            //         // MyVideoProcessingControllerFFmpeg.executeFFmpegCmd(
            //         //   convertCmd,
            //         // )
            //         //   .then((convertedVideo) => {
            //         //     this.setEditingKeyValue('initialVideoSource', {
            //         //       uri: convertedVideo,
            //         //     });
            //         //     MyRecordingController.setKeyValue({
            //         //       key: 'isChangeSaved',
            //         //       value: true,
            //         //     });
            //         //     MyLayoutManager.setLoaderVisible(false, '');
            //         //     resolve(convertedVideo);
            //         //   })
            //         //   .catch((err) => {
            //         //     reject(err);
            //         //   });
            //       })
            //       .catch((err) => {
            //         MyLayoutManager.setLoaderVisible(false, '');
            //         console.log('CATCH ERROR in Concatinating');
            //         console.log(err);
            //       });
            //     // this.mergeVideos(recordings)
            //     //   .then((res) => {
            //     //     MyLayoutManager.setLoaderVisible(false, '');
            //     //     resolve(true);
            //     //   })
            //     //   .catch((err) => {
            //     //     console.log('ERROR IN MERTING');
            //     //     console.log(err);
            //     //     MyLayoutManager.setLoaderVisible(false, '');
            //     //     reject(err);
            //     //   });
            //   })
            //   .catch((err) => {
            //     MyLayoutManager.setLoaderVisible(false, '');
            //     reject(err);
            //   });
          } else {
            recordings = recorder.recordings.map((r) => r.source.uri);
            if (recordings.length > 0) {
              this.checkIfRecordingExist(recordings)
                .then((checkRes) => {
                  if (checkRes.isValid) {
                    this.mergeVideos(checkRes.recordings)
                      .then((outputVideo) => {
                        this.setEditingKeyValue('initialVideoSource', {
                          uri: outputVideo,
                        });
                        this.setEditingKeyValue('playingSource', {
                          uri: outputVideo,
                        });

                        MyRecordingController.setKeyValue({
                          key: 'isChangeSaved',
                          value: true,
                        });
                        MyLayoutManager.setLoaderVisible(false, '');
                        // InteractionManager.runAfterInteractions(() => {
                        //   this.extractAndSaveVideoPreviews();
                        // });

                        resolve(outputVideo);
                      })
                      .catch((err) => {
                        console.log('ERROR, In Videos ');
                        console.log(err);
                        MyLayoutManager.setLoaderVisible(false, '');
                        reject(err);
                      });
                  } else {
                    MyAlertBoxController.show(
                      MyAlertBoxController.ACTIONS_OKAY,
                      'Low Memory, clear you cashe and restart app',
                      (result) => {
                        reject('Operation Abort');
                      },
                    );
                  }
                })
                .catch((err) => {
                  console.log('ERROR, Low Memory ');
                  console.log(err);
                  MyLayoutManager.setLoaderVisible(false, '');
                  reject(err);
                });
            } else {
              this.setEditingKeyValue('initialVideoSource', null);
              this.setEditingKeyValue('playingSource', null);

              MyRecordingController.setKeyValue({
                key: 'isChangeSaved',
                value: true,
              });
              MyLayoutManager.setLoaderVisible(false, '');
              resolve(null);
            }

            // let command = MyVideoProcessingControllerFFmpeg.prepareCasheOUTPUT().generateConcatinateCommand(
            //   recordings,
            // );
            // // console.log('++++++++++++++VIDEO CONCATINATING COMMAND');
            // // console.log(command);
            // MyVideoProcessingControllerFFmpeg.executeFFmpegCmd(command)
            //   .then((outputVideo) => {
            //     this.setEditingKeyValue('initialVideoSource', {
            //       uri: outputVideo,
            //     });
            //     MyRecordingController.setKeyValue({
            //       key: 'isChangeSaved',
            //       value: true,
            //     });
            //     MyLayoutManager.setLoaderVisible(false, '');
            //     resolve(outputVideo);
            //   })
            //   .catch((err) => {
            //     MyLayoutManager.setLoaderVisible(false, '');
            //     console.log('CATCH ERROR in Concatinating');
            //     console.log(err);
            //   });
          }

          // console.log('>>>>>PREPARED RECORDINGS');
          // console.log(recordings);

          //// TODO: where speed is Less then 1 or grater than 1 do make slowmos.. or fastoos

          // this.getInfo(recordings[0].uri);
          // this.prepareVideo(this.prepareCommand(recordings))
          //   .then((res) => {
          //     resolve(true);
          //   })
          //   .catch((err) => {
          //     reject(err);
          //   });
        }
      });
    };

    this.getInfo = (uri) => {
      //   return new Promise((resolve, reject) => {
      // console.log('>>>>>>>>>>>>>>>>>GETTTING INFOR');
      // RNFFprobe.getMediaInformation(uri)
      //   .then((info) => {
      //     // console.log('Result: ' + JSON.stringify(info));
      //     // console.log('Media Information');
      //     // console.log('Path: ' + info.path);
      //     // console.log('Format: ' + info.format);
      //     // console.log('Duration: ' + info.duration);
      //     // console.log('Start time: ' + info.startTime);
      //     // console.log('Bitrate: ' + info.bitrate);
      //     if (info.streams) {
      //       for (var i = 0; i < info.streams.length; i++) {
      //         // console.log('Stream id: ' + info.streams[i].index);
      //         // console.log('Stream type: ' + info.streams[i].type);
      //         // console.log('Stream codec: ' + info.streams[i].codec);
      //         // console.log('Stream full codec: ' + info.streams[i].fullCodec);
      //         // console.log('Stream format: ' + info.streams[i].format);
      //         // console.log('Stream full format: ' + info.streams[i].fullFormat);
      //         // console.log('Stream width: ' + info.streams[i].width);
      //         // console.log('Stream height: ' + info.streams[i].height);
      //         // console.log('Stream bitrate: ' + info.streams[i].bitrate);
      //         // console.log('Stream sample rate: ' + info.streams[i].sampleRate);
      //         // console.log(
      //         //   'Stream sample format: ' + info.streams[i].sampleFormat,
      //         // );
      //         // console.log(
      //         //   'Stream channel layout: ' + info.streams[i].channelLayout,
      //         // );
      //         // console.log('Stream sar: ' + info.streams[i].sampleAspectRatio);
      //         // console.log('Stream dar: ' + info.streams[i].displayAspectRatio);
      //         // console.log(
      //         //   'Stream average frame rate: ' +
      //         //     info.streams[i].averageFrameRate,
      //         // );
      //         // MyVideoProcessingControllerFFmpeg.setAvgFrameRate(
      //         //   info.streams[i].averageFrameRate
      //         //     ? info.streams[i].averageFrameRate
      //         //     : 12,
      //         // );
      //         // console.log(
      //         //   'Stream real frame rate: ' + info.streams[i].realFrameRate,
      //         // );
      //         // console.log('Stream time base: ' + info.streams[i].timeBase);
      //         // console.log(
      //         //   'Stream codec time base: ' + info.streams[i].codecTimeBase,
      //         // );
      //         // if (info.streams[i].metadata) {
      //         //   console.log(
      //         //     'Stream metadata encoder: ' +
      //         //       info.streams[i].metadata.encoder,
      //         //   );
      //         //   console.log(
      //         //     'Stream metadata rotate: ' + info.streams[i].metadata.rotate,
      //         //   );
      //         //   console.log(
      //         //     'Stream metadata creation time: ' +
      //         //       info.streams[i].metadata.creation_time,
      //         //   );
      //         //   console.log(
      //         //     'Stream metadata handler name: ' +
      //         //       info.streams[i].metadata.handler_name,
      //         //   );
      //         // }
      //         // if (info.streams[i].sidedata) {
      //         //   console.log(
      //         //     'Stream side data displaymatrix: ' +
      //         //       info.streams[i].sidedata.displaymatrix,
      //         //   );
      //         // }
      //       }
      //     }
      //   })
      //   .catch((err) => {
      //     console.log('Error In getting infor');
      //     console.log(err);
      //   });
      // //   });
    };

    this.prepareCommand = (recordings) => {
      // this.OUTPUTPATH = `${RNFS.DownloadDirectoryPath}/abcmyvideo05.mp4`;
      // console.log(`>>>>>RECORD TEST01-1: output path ${this.OUTPUTPATH}`);
      // // let command = '';
      // let output = ` -map "[outv]" -map "[outa]" -time_base 1/13 ${this.OUTPUTPATH}`;
      // //// Preparing inputs
      // let inputs = '';
      // let complexFilters = '';
      // for (let index = 0; index < recordings.length; index++) {
      //   const source = recordings[index];
      //   inputs = `${inputs} -i ${source.uri}`;
      //   // complexFilters = `${complexFilters}[${index}]`;
      //   complexFilters = `${complexFilters}[ ${index}:v:0] [${index}:a:0]`;
      // }
      // let complexFilterCMD = ` -filter_complex "${complexFilters}concat=n=${recordings.length}:v=1:a=1[outv][outa]"`;
      // console.log('>>>>>RECORD TEST01-2: PREPARED COMMAND');
      // const preparedCommand = `${inputs}${complexFilterCMD}${output}`;
      // console.log(preparedCommand);
      // return preparedCommand;
    };

    this.applySpeedEffects = (recordings) => {
      // return new Promise(async (resolve, reject) => {
      //   MyLayoutManager.setLoaderVisible(true, 'preparing...');
      //   try {
      //     for (let index = 0; index < recordings.length; index++) {
      //       console.log(`================= CLIP[${index}] ===============`);
      //       MyLayoutManager.setLoaderVisible(
      //         true,
      //         `preparing ${index + 1}/${recordings.length}`,
      //       );
      //       const singleRecording = recordings[index];
      //       if (
      //         singleRecording.recordingSpeed !== 1 &&
      //         singleRecording.isProcessed !== true
      //       ) {
      //         console.log('Preparing Command...');
      //         const processCommand = MyVideoProcessingControllerFFmpeg.prepareCasheOUTPUT().generateVideoSpeedControllerCommand(
      //           singleRecording.source.uri,
      //           singleRecording.recordingSpeed,
      //         );
      //         console.log(`Command Prepared!`);
      //         console.log(processCommand);
      //         console.log('Processing...');
      //         let processedUri = await MyVideoProcessingControllerFFmpeg.executeFFmpegCmd(
      //           processCommand,
      //         );
      //         MyRecordingController.updateClipProcessedSource(
      //           singleRecording._id,
      //           {uri: processedUri},
      //         );
      //         console.log(`Processed And Updated ${index}`);
      //       } else {
      //         console.log('SKIPPING....');
      //         console.log(singleRecording);
      //       }
      //     }
      //     MyLayoutManager.setLoaderVisible(true, `applied`);
      //     resolve(true);
      //   } catch (error) {
      //     console.log('Apply Speed Effects, CATCH Error');
      //     console.log(error);
      //     reject(error);
      //   }
      // });
    };

    this.mergeVideos = (urls) => {
      return new Promise((resolve, reject) => {
        // console.log('MERGING VIDEOS ....');
        // console.log(urls);
        // RNVideoEditor.merge(
        //   urls,
        //   (results) => {
        //     console.log('ERROR IN MERGED VIDEOS ');
        //     console.log(results);
        //     reject(results);
        //   },
        //   (results, file) => {
        //     //   alert('Success : ' + results + ' file: ' + file);
        //     console.log('SUCCSESS MERGED');
        //     console.log(results);
        //     console.log('FILES');
        //     console.log(file);
        //     ///TODO: just comment for testing, remove comment
        //     // this.setEditingKeyValue('initialVideoSource', {
        //     //   uri: `file:///${file}`,
        //     // });
        //     resolve(`file:///${file}`);

        //     /// TESTING ...

        //     // console.log('VIDEO PROCSSING TEST 1, Preparing Command ');
        //     // let vpccommand = MyVideoProcessingControllerFFmpeg.prepareCasheOUTPUT().generateVideoSpeedControllerCommand(
        //     //   `file:///${file}`,
        //     //   2,
        //     // );
        // console.log('VIDEO PROCSSING TEST 2, Prepared ');
        // console.log(vpccommand);

        // console.log('PROCESSING VIDEO ...');
        // MyVideoProcessingControllerFFmpeg.executeFFmpegCmd(vpccommand)
        //   .then((output) => {
        //     console.log('OUTPUT AT');
        //     console.log(output);
        //   this.setEditingKeyValue('initialVideoSource', {
        //     uri: output,
        //   });
        //   resolve(output);
        // })
        // .catch((err) => {
        //   console.log('Error in EXECUTING FFMPEG Command');
        //   console.log(err);
        // });

        //// TESTING ENDING...
        //   },
        // );
        resolve('');
      });
    };

    this.executeCommand = (command) => {
      return new Promise((resolve, reject) => {
        // console.log('>>>>>RECORD TEST02-1: PREPARE VIDEO START');
        // RNFFmpeg.execute(command)
        //   .then((result) => {
        //     // console.log(
        //     //   '==================================================RESULT====================================',
        //     // );
        //     // console.log(result);
        //     // console.log('==================================SUPPOSED URL');
        //     // console.log(this.OUTPUTPATH);
        //     resolve(true);
        //   })
        //   .catch((err) => {
        //     console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>CATCH ERROR IN PROCESSING');
        //     console.log(err);
        //     reject(err);
        //   });
      });
    };

    // this.prepareVideoPlaybackSpeedCommand = () => {

    // }
  }
}
const MyEditingController = new EditingController();
export default MyEditingController;
