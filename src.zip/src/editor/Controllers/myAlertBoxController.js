import MyRecordingController from './recordingConroller';

class AlertBoxController {
  constructor() {
    this.RESULTS = {
      YES: 'Yes',
      NO: 'No',
      DISCARD: 'Discard',
      OKAY: 'Okay',
    };
    this._handleOnResult = null;
    this.ACTIONS_NO_DISCARD = [
      {_id: 1, title: this.RESULTS.NO},
      {_id: 2, title: this.RESULTS.DISCARD},
    ];
    this.ACTION_NO_YES = [
      {_id: 1, title: this.RESULTS.NO},
      {_id: 2, title: this.RESULTS.YES},
    ];
    this.ACTIONS_OKAY = [{_id: 1, title: this.RESULTS.OKAY}];
    this.onAlertResult = (result) => {
      if (this._handleOnResult) {
        this._handleOnResult(result);
        MyRecordingController.setKeyValue({
          key: 'alerBoxVisible',
          value: false,
        });
        MyRecordingController.setKeyValue({
          key: 'alertBox',
          value: {actions: [], message: ''},
        });
      }
    };
    this.show = (actions, message, onResult = (result) => '') => {
      this._handleOnResult = onResult;
      MyRecordingController.setKeyValue({
        key: 'alertBox',
        value: {actions, message},
      });

      MyRecordingController.setKeyValue({
        key: 'alerBoxVisible',
        value: true,
      });
    };
  }
}
const MyAlertBoxController = new AlertBoxController();
export default MyAlertBoxController;
