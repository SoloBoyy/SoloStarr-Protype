import React, {Component} from 'react';
import {StyleSheet, View, FlatList} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import SearchTabPage from './searchTabPage';
import SoundItemComponent from './soundItem';
import SoundTextComponent from './soundText';

class SavedTabPage extends Component {
  state = {
    sounds: [
      {id: 1, songName: 'Song Name', songDescription: 'Description'},
      {id: 2, songName: 'Song Name', songDescription: 'Description'},
      {id: 3, songName: 'Song Name', songDescription: 'Description'},
      {id: 4, songName: 'Song Name', songDescription: 'Description'},
      {id: 5, songName: 'Song Name', songDescription: 'Description'},
    ],
  };
  render() {
    const isSearchEnabled = this.props.isSearchEnabled ? true : false;

    if (isSearchEnabled) {
      return <SearchTabPage />;
    } else {
      return (
        <View style={styles.container}>
          <SoundTextComponent text={'Saved'} />
          <FlatList
            showsVerticalScrollIndicator={false}
            data={this.state.sounds}
            renderItem={({item}) => (
              <SoundItemComponent
                songName={item.songName}
                songDescription={item.songDescription}
                isSaved
              />
            )}
            keyExtractor={(item) => item.id}
          />
        </View>
      );
    }
  }
}

export default SavedTabPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: SECONDRY_BLACK,
  },
});
