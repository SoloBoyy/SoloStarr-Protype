import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CheckMarkWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      onPress={props.onPress ? props.onPress : () => false}
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="28.243" height="20.121" viewBox="0 0 28.243 20.121">
  <path id="Icon_feather-check" data-name="Icon feather-check" d="M30,9,13.5,25.5,6,18" transform="translate(-3.879 -6.879)" fill="none" stroke="#63F420" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
</svg>
`}
    />
  );
};
export default CheckMarkWhiteSVG;
