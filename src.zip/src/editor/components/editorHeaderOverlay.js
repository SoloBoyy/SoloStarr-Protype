import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MyButton from './myButton';
import {connect} from 'react-redux';
import ProgressHeaders from './progressBar/progressHeaders';
import TabBarButton from './tabBarButton';
import MyLayoutManager from '../Controllers/layoutManager';
import {goBack} from '../../navigator';
import MyRecordingController from '../Controllers/recordingConroller';

const MyHorizonButton = (props) => {
  const [btnsVisible, setBtnsVisible] = useState(true);
  return (
    <View>
      <MyButton
        onPress={() => {
          setBtnsVisible(!btnsVisible);
        }}
        name="times"
      />
      {btnsVisible ? (
        <View>
          <View style={{height: 10}} />
          <TouchableOpacity
            onPress={() => {
              goBack();
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton name="times" color="red" />
            <Text style={{color: 'white'}}>{`  Delete`}</Text>
          </TouchableOpacity>
          <View style={{height: 15}} />
          <TouchableOpacity
            onPress={() => {
              MyRecordingController.resetEditor();
            }}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <MyButton name="redo" />
            <Text style={{color: 'white'}}>{`  Start Over`}</Text>
          </TouchableOpacity>
        </View>
      ) : (
        false
      )}
    </View>
  );
};
{
  /* <MyButton
              onPress={() => {
                goBack();
              }}
              name="times"
            /> */
}

const HeaderOverlay = (props) => {
  const [mode, setModes] = useState('video');

  return (
    <View style={{flex: 1, flexDirection: 'row', alignItems: 'center'}}>
      <View style={{flex: 1}}>
        {/* {props.editorLayoutMode.H_L_CROSS ? (
            <View style={{position: 'absolute', top: 0, left: 0}}>
              <MyHorizonButton />
            </View>
          ) : (
            false
          )} */}
        {props.editorLayoutMode.H_L_ARROW_LEFT ? (
          <MyButton
            onPress={() => MyLayoutManager.navigateTo('VideoMakingScreen')}
            name="arrow-left"
          />
        ) : (
          false
        )}
      </View>
      <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <TabBarButton mode="editor" />
        </View>
      </View>
      <View style={{flex: 1, alignItems: 'flex-end'}}>
        {props.editorLayoutMode.H_R_CHECK ? <MyButton name="check" /> : false}
      </View>
    </View>
  );
};

const mapStateToProps = (state) => ({
  editorLayoutMode: state.EditorReducer.editorLayoutMode,
});
export default connect(mapStateToProps, null)(HeaderOverlay);
