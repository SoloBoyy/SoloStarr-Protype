import React, {Component} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import LikedWhiteSVG from '../../icons/likedWhiteSVG';
import CommentWhiteSVG from '../../icons/commentWhiteSVG';
import MensionWhiteSVG from '../../icons/mensionWhiteSVG';
import PersonWhiteSVG from '../../icons/personWhiteSVG';
export const LIKED = 'liked';
export const COMMENTED = 'commented';
export const MENSIONED = 'mensioned';
export const FOLLOWED = 'followed';

const ActivityRightIcon = (props) => {
  switch (props.type) {
    case LIKED:
      return (
        <View
          style={{
            width: 40,
            height: 55,
            borderRadius: 10,
            backgroundColor: '#555555',
          }}
        />
      );

    case COMMENTED:
      return <CommentWhiteSVG style={{marginRight: 5}} size={25} />;

    case FOLLOWED:
      return <PersonWhiteSVG style={{marginRight: 5}} />;

    case MENSIONED:
      return <MensionWhiteSVG style={{marginRight: 5}} />;

    default:
      return false;
  }
};

const ActivityTypeItem = (props) => {
  const size = 55;
  const isSelected = true;
  return (
    <View
      style={{
        width: '100%',
        height: size + 10,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View style={{flex: 3, flexDirection: 'row', alignItems: 'center'}}>
        <Image
          style={{
            width: size,
            height: size,
            borderRadius: 50,
            backgroundColor: '#555555',
          }}
        />
        <View style={{padding: 10}}>
          <Text style={{color: WHITE_COLOR, fontSize: size / 3.5}}>
            username
          </Text>
          <Text style={{color: 'gray', fontSize: size / 5}}>username</Text>
        </View>
      </View>
      <View style={{flex: 1, alignItems: 'flex-end'}}>
        <TouchableOpacity
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <ActivityRightIcon {...{type: props.type}} />
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default ActivityTypeItem;
