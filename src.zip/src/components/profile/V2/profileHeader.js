import React from 'react';
import {View, Text, Dimensions, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK} from '../../../themes/colors';
import TabButton from '../tabButton';
const {width} = Dimensions.get('window');
const ProfileHeader = (props) => {
  return (
    <View style={{width, backgroundColor: 'transparent', marginBottom: 10}}>
      <Text
        style={{
          color: 'white',
          alignSelf: 'center',
          fontWeight: 'bold',
          fontSize: 16,
        }}>
        Chris Gullete
      </Text>
      <View style={{height: 10}} />
      <View
        style={{
          height: 35,
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <TouchableOpacity
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <TabButton
            {...{
              title: 'Series',
              selected: false,
              onPress: () => console.log('Clicked'),
            }}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <TabButton
            {...{
              title: 'Posts',
              selected: true,
              onPress: () => console.log('Clicked'),
            }}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <TabButton
            {...{
              title: 'Liked',
              selected: false,
              onPress: () => console.log('Clicked'),
            }}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ProfileHeader;
