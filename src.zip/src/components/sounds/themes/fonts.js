export const EXTRA_SMALL = 10;
export const SMALL = 12;
export const MEDIUM = 14;
export const LARGE = 17;
export const EXTRA_LARGE = 20;
