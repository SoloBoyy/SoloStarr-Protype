import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const TimerSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="28.118" height="28.125" viewBox="0 0 28.118 28.125">
  <g id="Icon_ionic-ios-timer" data-name="Icon ionic-ios-timer" transform="translate(-3.938 -3.938)">
    <path id="Path_15" data-name="Path 15" d="M18,32.063A14.063,14.063,0,0,1,8.241,7.875,1.129,1.129,0,0,1,9.809,9.5a11.8,11.8,0,1,0,9.316-3.248v4.4a1.132,1.132,0,1,1-2.264,0V5.07a1.131,1.131,0,0,1,1.132-1.132A14.063,14.063,0,0,1,18,32.063Z" fill="#f0f0f0"/>
    <path id="Path_16" data-name="Path 16" d="M12.368,11.384l7,5.027A2.117,2.117,0,0,1,16.9,19.856a2.044,2.044,0,0,1-.492-.492l-5.027-7a.705.705,0,0,1,.984-.984Z" fill="#f0f0f0"/>
  </g>
</svg>
`}
    />
  );
};
export default TimerSVG;
