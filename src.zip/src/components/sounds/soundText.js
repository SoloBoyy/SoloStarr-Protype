import React, {Component} from 'react';
import {StyleSheet, View, Text} from 'react-native';

import {
  DARK_GRAY,
  LIGHT_GRAY,
  SECONDRY_BLACK,
  WHITE_COLOR,
} from '../../themes/colors';

export default class SoundTextComponent extends Component {
  render() {
    const {text} = this.props;
    return (
      <View style={styles.container}>
        <Text style={styles.textStyle}>{text}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    height: 30,
    width: '85%',
    alignSelf: 'center',
    backgroundColor: SECONDRY_BLACK,
  },
  textStyle: {color: WHITE_COLOR, fontSize: 20, fontWeight: 'bold'},
});
