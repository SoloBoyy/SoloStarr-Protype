import React, {Component} from 'react';
import {View, Text, StatusBar, Image} from 'react-native';
import CircleButton from '../components/inbox/circleButton';
import CheckMarkWhiteSVG from '../icons/checkMarkWhiteSVG';
import CrossMarkWhiteSVG from '../icons/crossMarkWhiteSVG';
import {goBack, navigate} from '../navigator';
import {SECONDRY_BLACK, WHITE_COLOR} from '../themes/colors';
class BostCoinPermissionScreen extends Component {
  state = {};
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={false} backgroundColor={SECONDRY_BLACK} />
        <View
          style={{
            flex: 1.6,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Image
            source={require('../assets/userimg.jpg')}
            style={{
              height: 200,
              borderRadius: 20,
              width: '33%',
              backgroundColor: WHITE_COLOR,
            }}
          />
        </View>
        <View style={{flex: 1}}>
          <View
            style={{
              height: '100%',
              width: '70%',
              alignSelf: 'center',
              justifyContent: 'space-evenly',
            }}>
            <Text style={{fontSize: 25, fontWeight: 'bold', color: 'white'}}>
              Use Boost Coin ?
            </Text>
            <Text style={{color: 'white'}}>
              Boost coins push your video to larger audiance for 30 minutes
            </Text>
            <Text style={{color: 'white'}}>Boost Coin Balance: 3</Text>
          </View>
        </View>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View style={{flexDirection: 'row'}}>
            <CircleButton
              onPress={() => navigate('BoostCoinBuyScreen')}
              Icon={() => <CheckMarkWhiteSVG size={20} />}
              size={35}
              invert
            />
            <View style={{width: 50}} />
            <CircleButton
              onPress={() => goBack()}
              Icon={() => <CrossMarkWhiteSVG size={13} />}
              size={35}
              invert
            />
          </View>
        </View>
      </View>
    );
  }
}

export default BostCoinPermissionScreen;
