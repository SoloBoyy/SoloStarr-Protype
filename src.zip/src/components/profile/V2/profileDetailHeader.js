import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  Dimensions,
  TouchableOpacity,
  ImageBackground,
  StatusBar,
  Linking,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome5';
import ProfileStartBlueSVG from '../../../icons/profileStartBlueSVG';
import StarWhiteSVG from '../../../icons/startWhiteSVG';
import {navigate} from '../../../navigator';
import ProfileDetailHeaderEditOverlay from './profileDetailHeaderEditOverlay';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../../themes/colors';
import MyAlertBoxController from '../../../editor/Controllers/myAlertBoxController';
import SocialLinksModal from './socialLinks';
import {useSelector} from 'react-redux';
import CommentWhiteSVG from '../../../icons/commentWhiteSVG';
const {width, height} = Dimensions.get('window');

const ProfileState = ({title, value, onPress, activeOpacity}) => {
  const size = 15;
  return (
    <TouchableOpacity
      onPress={onPress ? () => onPress() : () => false}
      activeOpacity={activeOpacity}
      style={{alignItems: 'center'}}>
      <Text style={{color: 'white', fontSize: size, fontWeight: '700'}}>
        {value}
      </Text>
      <Text style={{color: 'white', fontSize: size - 5}}>{title}</Text>
    </TouchableOpacity>
  );
};

const ProfileDetailHeader = (props) => {
  const [isEditingMode, setEditingMode] = useState(false);
  const [username, setUserName] = useState('Chris Gullette');
  const [desc, setDesc] = useState(
    'In publishing and graphic design, Lorem ipsum is a',
  );
  const NAME = 'Chris Gullette';
  const USERNAME = '@chrisgullette';
  const socialLinkRef = useRef();
  const [socialLinkCods, setSocialLinkCods] = useState({top: 0, left: 0});
  const [linksVisible, setLinksVisible] = useState(false);
  const [weblink, setWebLink] = useState('solostar.com');
  const [isUserNameMode, setUserNameMode] = useState(false);
  const profileImage = useSelector(
    (store) => store.ForYouReducer.layout.profileImage,
  );
  const toggleScreenMode = () => {
    if (isUserNameMode) {
      setUserNameMode(false);
      setUserName(NAME);
    } else {
      setUserNameMode(true);
      setUserName(USERNAME);
    }
  };
  const openWebLink = () => {
    let result = weblink.search('http');
    let weblink_ = '';
    if (result === 0) {
      weblink_ = weblink;
    } else {
      weblink_ = `http://${weblink}`;
    }

    Linking.canOpenURL(weblink_).then((canOpen) => {
      if (canOpen) {
        Linking.openURL(weblink_)
          .then((res) => {
            console.log('URL OPEN NOW');
          })
          .catch((err) => {
            console.log('Error in Opening URL');
            MyAlertBoxController.show(
              MyAlertBoxController.ACTIONS_OKAY,
              'Cannot Open This URL',
              (res) => false,
            );
          });
      } else {
        MyAlertBoxController.show(
          MyAlertBoxController.ACTIONS_OKAY,
          'Invalid URL',
          (res) => false,
        );
      }
    });
  };
  return (
    <View style={{width, height: height - StatusBar.currentHeight}}>
      <ImageBackground
        imageStyle={{
          transform: [...profileImage.transform, {scale: profileImage.scale}],
          overflow: 'hidden',
          backgroundColor: SECONDRY_BLACK,
        }}
        resizeMode="contain"
        source={require('../../../assets/SAMPLE02.jpg')}
        style={{
          flex: 1,
          backgroundColor: 'white',
          overflow: 'hidden',
        }}>
        <View style={{flex: 1}}></View>

        <LinearGradient
          locations={[0, 0.7, 1]}
          style={{flex: 1}}
          colors={['rgba(0,0,0, 0)', SECONDRY_BLACK, SECONDRY_BLACK]}>
          <View style={{flex: 1, justifyContent: 'flex-end'}}>
            <View style={{width: '90%', alignSelf: 'center'}}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <Text
                  onPress={toggleScreenMode}
                  style={{fontSize: 25, color: 'white'}}>
                  {username}
                </Text>
                <ProfileStartBlueSVG style={{marginTop: 3, marginLeft: 5}} />
              </View>
              <View style={{height: 10}} />
              <Text style={{color: 'white', maxWidth: '60%'}}>{desc}</Text>
              <View style={{height: 10}} />
              <Text
                onPress={() => openWebLink()}
                style={{
                  color: 'white',
                  textDecorationLine: 'underline',
                }}>
                {weblink}
              </Text>
            </View>
            <View style={{height: 40}} />
            <View
              style={{
                flexDirection: 'row',
                width: 200,
                alignSelf: 'center',
                justifyContent: 'space-evenly',
              }}>
              <ProfileState
                onPress={() => {
                  navigate('FollowScreen', {
                    target: 'Followers',
                  });
                }}
                key={10}
                {...{title: 'Followers', value: '127k'}}
              />
              <ProfileState
                onPress={() => {
                  navigate('FollowScreen', {
                    target: 'Follwing',
                  });
                }}
                key={11}
                {...{title: 'Followings', value: '127k'}}
              />
              <ProfileState key={12} {...{title: 'Likes', value: '127'}} />
            </View>

            <View style={{height: 40}} />
            <View style={{flexDirection: 'row', alignSelf: 'center'}}>
              <View key={21}>
                <TouchableOpacity
                  key={22}
                  onPress={() => false}
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Icon name="ellipsis-h" color="white" size={23} />
                </TouchableOpacity>
              </View>
              <View style={{width: 10}} />
              <TouchableOpacity
                onPress={() => setEditingMode(true)}
                key={19}
                style={{
                  width: 200,
                  height: 35,
                  borderRadius: 50,
                  backgroundColor: 'black',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text key={20} style={{color: 'white'}}>
                  Edit Profile
                </Text>
              </TouchableOpacity>
              <View style={{width: 10}} />

              <View key={25}>
                <TouchableOpacity
                  ref={socialLinkRef}
                  // onLayout={(e) => {
                  //   socialLinkRef.current.measure(
                  //     (x, y, width, height, pageX, pageY) => {
                  //       //   console.log(
                  //       //     `\n>X: ${x}, Y: ${y} \n>WIDTH: ${width}, HEIGHT: ${height} \n>PAGE-X: ${pageX}, PAGE-Y: ${pageY}`,
                  //       //   );
                  //       setSocialLinkCods({top: pageY - 170, left: pageX - 50});
                  //     },
                  //   );
                  // }}
                  key={90}
                  onPress={() => setLinksVisible(true)}
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',

                    alignItems: 'center',
                  }}>
                  <Icon
                    onPress={() => setLinksVisible(true)}
                    key={63}
                    style={{fontSize: 23}}
                    color={'white'}
                    name={false ? 'times' : 'paperclip'}
                  />
                </TouchableOpacity>
              </View>
            </View>
            <View height={70} />
          </View>
        </LinearGradient>
      </ImageBackground>
      <ProfileDetailHeaderEditOverlay
        visible={isEditingMode}
        onChangeName={(text) => setUserName(text)}
        onChangeDesc={(desc) => setDesc(desc)}
        onChangeWeb={(web) => setWebLink(web)}
        setVisible={(value) => setEditingMode(value)}
      />
      <SocialLinksModal
        setVisible={(value) => setLinksVisible(value)}
        from={socialLinkRef}
        visible={linksVisible}
      />
    </View>
  );
};

export default ProfileDetailHeader;
