import React, {Component} from 'react';
import {
  View,
  Text,
  StatusBar,
  FlatList,
  ScrollView,
  Dimensions,
  Animated,
  Easing,
} from 'react-native';
import PostTabContent from '../components/profile/postTabContent';
import ProfileDetailHeader from '../components/profile/profileDetailHeader';
import ProfileHeader from '../components/profile/profileHeader';
import SingleSnap from '../components/profile/singleSnap';
import TabButton from '../components/profile/tabButton';
import {SECONDRY_BLACK} from '../themes/colors';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import MyTabBar from '../components/profile/myTabBar';
import SeriesTabContent from '../components/profile/seriesTabContent';
import LikedTabContent from '../components/profile/likedTabContent';
import MyProfileAnimController from './profileAnimController';
const Tab = createMaterialTopTabNavigator();
// const posts = [
//   {_id: 1, imageSource: require('../assets/dummy01.png')},
//   {_id: 2, imageSource: require('../assets/dummy02.PNG')},
//   {_id: 3, imageSource: require('../assets/dummy03.PNG')},
//   {_id: 4, imageSource: require('../assets/dummy04.PNG')},
//   {_id: 5, imageSource: require('../assets/dummy05.PNG')},
// ];
class MyProfileScreen extends Component {
  constructor() {
    super();
    this.yOffset = new Animated.Value(0);
    this.seriesRef = null;
    this.postsRef = null;
    this.likedRef = null;
    this.headerHeight = this.yOffset.interpolate({
      inputRange: [0, 200],
      outputRange: [0, -200],
      extrapolate: 'clamp',
    });
    this.headerVisible = this.yOffset.interpolate({
      inputRange: [0, 100, 200],
      outputRange: [0, 0.5, 1],
      extrapolate: 'clamp',
    });
    this.state = {
      headerHeight: 40,
      tabHeight: 40,
      currentTab: 'Series',
    };
  }

  scrollToTop = () => {
    // console.log('Scrolling to top');
    // let oldTab = this.state.currentTab;
    // this.setState({currentTab: ''});
    // this.yOffset.setValue(0);
    // this.setState({currentTab: oldTab});
  };

  render() {
    const topOffset = 0;
    const {height} = Dimensions.get('window');

    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={true} backgroundColor={SECONDRY_BLACK} />
        <ProfileHeader
          {...{
            style: {zIndex: 999},
            imageStyle: {
              opacity: this.headerVisible,
              transform: [{scale: this.headerVisible}],
            },
            scrollToTop: this.scrollToTop,
            onHeaderLayout: (headerHeight) => this.setState({headerHeight}),
          }}
        />

        <ProfileDetailHeader
          navigation={this.props.navigation}
          style={{zIndex: -999}}
        />
        <Animated.View
          style={{
            height,
            width: '100%',
            transform: [{translateY: this.headerHeight}],
          }}>
          {/* POSTS  */}
          <Tab.Navigator
            tabBar={(props) => (
              <MyTabBar
                {...props}
                onChange={(value) => {
                  MyProfileAnimController.setCurrentTab(value.name);
                  MyProfileAnimController.scrollToTop();
                  this.yOffset.setValue(1);
                  setTimeout(() => this.setState({currentTab: value.name}), 1);
                }}
              />
            )}>
            <Tab.Screen
              name="Series"
              children={(props) => (
                <View
                  style={{
                    height:
                      height - (this.state.headerHeight + this.state.tabHeight),
                    backgroundColor: SECONDRY_BLACK,
                  }}>
                  <SeriesTabContent
                    {...{
                      title: 'Series',
                      currentTab: this.state.currentTab,
                      y: this.yOffset,
                      style: {transform: [{translateY: this.headerHeight}]},
                    }}
                  />
                </View>
              )}
            />
            <Tab.Screen
              name="Posts"
              children={(props) => (
                <View
                  style={{
                    height:
                      height -
                      (this.state.headerHeight +
                        this.state.tabHeight +
                        StatusBar.currentHeight),
                    backgroundColor: SECONDRY_BLACK,
                  }}>
                  <PostTabContent
                    {...{
                      title: 'Posts',
                      currentTab: this.state.currentTab,
                      y: this.yOffset,
                      style: {transform: [{translateY: this.headerHeight}]},
                    }}
                  />
                </View>
              )}
            />
            <Tab.Screen
              name="Liked"
              children={() => (
                <View
                  style={{
                    height:
                      height -
                      (this.state.headerHeight +
                        this.state.tabHeight +
                        StatusBar.currentHeight),
                    backgroundColor: SECONDRY_BLACK,
                  }}>
                  <LikedTabContent
                    {...{
                      title: 'Liked',
                      currentTab: this.state.currentTab,
                      y: this.yOffset,
                      style: {transform: [{translateY: this.headerHeight}]},
                    }}
                  />
                </View>
              )}
            />
          </Tab.Navigator>
        </Animated.View>
      </View>
    );
  }
}

export default MyProfileScreen;
