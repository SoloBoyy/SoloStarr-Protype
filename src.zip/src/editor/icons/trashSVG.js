import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const TrashSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="54" height="57.614" viewBox="0 0 54 57.614">
  <g id="Group_1078" data-name="Group 1078" transform="translate(-61 -30)">
    <line id="Line_72" data-name="Line 72" x2="6" y2="49" transform="translate(64.5 37.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2"/>
    <line id="Line_73" data-name="Line 73" x1="6" y2="49" transform="translate(105.5 37.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2"/>
    <g id="Rectangle_230" data-name="Rectangle 230" transform="translate(61 30)" fill="none" stroke="#fff" stroke-width="2">
      <rect width="54" height="8" rx="4" stroke="none"/>
      <rect x="1" y="1" width="52" height="6" rx="3" fill="none"/>
    </g>
    <line id="Line_74" data-name="Line 74" x2="35" transform="translate(70.5 86.5)" fill="none" stroke="#fff" stroke-width="2"/>
    <g id="Group_1076" data-name="Group 1076">
      <line id="Line_75" data-name="Line 75" y1="15" x2="14" transform="translate(66.5 37.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_76" data-name="Line 76" x1="34" y2="34" transform="translate(69.5 37.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_77" data-name="Line 77" x1="33" y2="33" transform="translate(76.5 53.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_78" data-name="Line 78" y1="15" x2="14" transform="translate(93.5 71.5)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
    </g>
    <g id="Group_1077" data-name="Group 1077" transform="translate(66.5 37.5)">
      <line id="Line_75-2" data-name="Line 75" x1="14" y1="15" transform="translate(29)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_76-2" data-name="Line 76" x2="34" y2="34" transform="translate(6)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_77-2" data-name="Line 77" x2="33" y2="33" transform="translate(0 16)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
      <line id="Line_78-2" data-name="Line 78" x1="14" y1="15" transform="translate(2 34)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="1.5"/>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default TrashSVG;
