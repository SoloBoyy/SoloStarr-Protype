import React, {Component} from 'react';
import {
  View,
  StatusBar,
  StyleSheet,
  Text,
  Dimensions,
  PermissionsAndroid,
  Platform,
} from 'react-native';
// import ControlsOverlay from '../components/controlsOverlay';
// import {RNCamera} from 'react-native-camera';
import Video from 'react-native-video';
// import RNFS from 'react-native-fs';
// import {RNFFmpeg, RNFFmpegConfig, RNFFprobe} from 'react-native-ffmpeg';
// file:///data/user/0/com.tkteditor/cache/Camera/jhkhkdfhksjfhfjfie15.mp4
class VideoMakingScreen extends Component {
  state = {
    isFront: false,
    isRecording: false,
    recordedSource: [],
    isPlaying: false,
    isProcessing: false,
    output: `/video30.mp4`,
  };
  componentDidMount() {
    if (Platform.OS === 'android') {
      PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      )
        .then((granted) => {})
        .catch((err) => {
          console.log('PERMISSION NOT GRANGED');
          console.log(err);
        });
    }

    // RNFFmpegConfig.getExternalLibraries().then((externalLibraries) => {
    //   console.log(externalLibraries);
    // });
  }
  toggleCam = () => {
    this.setState({isFront: !this.state.isFront});
  };

  _handlePlayVideo = () => {
    this.setState({isPlaying: !this.state.isPlaying});
  };

  _handleVideoRecording = () => {
    if (this.state.isRecording) {
      // console.log('Stoping.!!! RECORD VIDEO');
      this.camera.stopRecording();
    } else {
      // console.log('Starting... RECORD VIDEO');
      this.camera
        .recordAsync({
          mirrorVideo: false,
          orientation: 'portrait',
        })
        .then((recordedRes) => {
          // console.log('VIDEO RECORDING RESULT');
          // console.log(recordedRes);

          this.setState({
            recordedSource: [...this.state.recordedSource, recordedRes],
          });
        })
        .catch((err) => {
          console.log('Video Recording ERROR CATCH');
          console.log(err);
        });
    }
    this.setState({isRecording: !this.state.isRecording});
  };

  prepareCommand = () => {
    // let command = '';
    let output = ` -map "[outv]" -map "[outa]" -time_base 1/24 ${this.state.output}`;

    //// Preparing inputs
    let inputs = '';
    let complexFilters = '';
    for (let index = 0; index < this.state.recordedSource.length; index++) {
      const source = this.state.recordedSource[index];
      inputs = `${inputs} -i ${source.uri}`;
      // complexFilters = `${complexFilters}[${index}]`;
      complexFilters = `${complexFilters}[ ${index}:v:0] [${index}:a:0]`;
    }

    let complexFilterCMD = ` -filter_complex "${complexFilters}concat=n=${this.state.recordedSource.length}:v=1:a=1[outv][outa]"`;

    // console.log('PREPARED COMMAND');
    const preparedCommand = `${inputs}${complexFilterCMD}${output}`;
    console.log(preparedCommand);
    return preparedCommand;
  };

  _handleProcessVideo = () => {
    if (this.state.isProcessing) {
    } else {
      // const command = this.prepareCommand();
      // RNFFmpeg.execute(command)
      //   .then((result) => {
      //     console.log(
      //       '==================================================RESULT====================================',
      //     );
      //     console.log(result);
      //     console.log('==================================SUPPOSED URL');
      //     console.log(this.state.output);
      //     this.setState(
      //       {
      //         recordedSource: [
      //           ...this.state.recordedSource,
      //           {
      //             uri: `file://${this.state.output}`,
      //           },
      //         ],
      //       },
      //       () => {
      //         console.log('=================================URLS ');
      //         console.log(this.state.recordedSource);
      //       },
      //     );
      //   })
      //   .catch((err) => {
      //     console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>CATCH ERROR IN PROCESSING');
      //     console.log(err);
      //   });
    }
  };

  render() {
    const {width, height} = Dimensions.get('window');
    return (
      <View style={[Styles.container, {width, height}]}>
        <StatusBar hidden />
        {this.state.isPlaying ? (
          <View>
            {this.state.recordedSource.length > 0 ? (
              <View
                key={`${Math.random() * 10000} ABC`}
                style={{borderWidth: 5, borderColor: 'black'}}>
                <Video
                  key={0}
                  repeat
                  resizeMode="contain"
                  source={{
                    uri: this.state.recordedSource[
                      this.state.recordedSource.length - 1
                    ].uri,
                  }} // Can be a URL or a local file.
                  ref={(ref) => {
                    this.player = ref;
                  }} // Store reference
                  onError={(err) => console.log(err)}
                  style={{
                    width: 100,
                    height: 100,
                  }}
                />
              </View>
            ) : (
              false
            )}
          </View>
        ) : (
          false
          // <RNCamera
          //   ref={(ref) => {
          //     this.camera = ref;
          //   }}
          //   playSoundOnCapture={true}
          //   onRecordingStart={({nativeEvent}) => {
          //     console.log('ON RECORDING START');
          //     console.log(nativeEvent);
          //   }}
          //   onRecordingEnd={() => {
          //     console.log('ON RECORDING END');
          //   }}
          //   style={{
          //     width,
          //     height,
          //   }}
          //   type={
          //     this.state.isFront
          //       ? RNCamera.Constants.Type.front
          //       : RNCamera.Constants.Type.back
          //   }
          //   flashMode={RNCamera.Constants.FlashMode.on}
          //   useCamera2Api={true}
          //   androidRecordAudioPermissionOptions={{
          //     title: 'Permission to use audio recording',
          //     message: 'We need your permission to use your audio',
          //     buttonPositive: 'Ok',
          //     buttonNegative: 'Cancel',
          //   }}
          // />
        )}

        <Text
          onPress={this._handleVideoRecording}
          style={{
            backgroundColor: 'black',
            color: 'white',
            padding: 10,
            borderRadius: 5,
            position: 'absolute',
            bottom: 20,
            right: 0,
          }}>
          {this.state.isRecording ? 'STOP' : 'RECORD'}
        </Text>
        <Text
          onPress={this._handlePlayVideo}
          style={{
            backgroundColor: 'black',
            color: 'white',
            padding: 10,
            borderRadius: 5,
            position: 'absolute',
            bottom: 20,
            left: 0,
          }}>
          {this.state.isPlaying ? 'STOP' : 'PLAY'}
        </Text>
        <Text
          onPress={
            this.state.isProcessing
              ? () => false
              : () => this._handleProcessVideo()
          }
          style={{
            backgroundColor: 'black',
            color: 'white',
            padding: 10,
            borderRadius: 5,
            position: 'absolute',
            bottom: 20,
            left: width / 2.5,
          }}>
          {this.state.isProcessing ? 'PROCESSING...' : 'PROCESS'}
        </Text>
        {/* <ControlsOverlay /> */}
      </View>
    );
  }
}

export default VideoMakingScreen;

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#111111',
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
});
