import React, {useState} from 'react';
import {View, Text, ScrollView, FlatList} from 'react-native';
import {SECONDRY_BLACK} from '../../../themes/colors';
import ProfileSnapPost from './profileSnapPost';

const ProfileTabContent = (props) => {
  const [posts, setPosts] = useState([
    {
      _id: 1,
      imageSource: require('../../../assets/dummy01.jpg'),
      isLoaded: false,
    },
    {
      _id: 2,
      imageSource: require('../../../assets/dummy02.jpg'),
      isLoaded: false,
    },
    {
      _id: 3,
      imageSource: require('../../../assets/dummy03.jpg'),
      isLoaded: false,
    },
    {
      _id: 4,
      imageSource: require('../../../assets/dummy04.jpg'),
      isLoaded: false,
    },
    {
      _id: 5,
      imageSource: require('../../../assets/dummy05.jpg'),
      isLoaded: false,
    },
    {
      _id: 6,
      imageSource: require('../../../assets/dummy01.jpg'),
      isLoaded: false,
    },
    {
      _id: 7,
      imageSource: require('../../../assets/dummy02.jpg'),
      isLoaded: false,
    },
    {
      _id: 8,
      imageSource: require('../../../assets/dummy03.jpg'),
      isLoaded: false,
    },
    {
      _id: 9,
      imageSource: require('../../../assets/dummy04.jpg'),
      isLoaded: false,
    },
    // {_id: 10, imageSource: require('../../../assets/dummy05.jpg')},
    // {_id: 11, imageSource: require('../../../assets/dummy01.jpg')},
    // {_id: 12, imageSource: require('../../../assets/dummy02.jpg')},
    // {_id: 13, imageSource: require('../../../assets/dummy03.jpg')},
    // {_id: 14, imageSource: require('../../../assets/dummy04.jpg')},
    // {_id: 15, imageSource: require('../../../assets/dummy05.jpg')},
    // {_id: 16, imageSource: require('../../../assets/dummy05.jpg')},
    // {_id: 17, imageSource: require('../../../assets/dummy01.jpg')},
    // {_id: 18, imageSource: require('../../../assets/dummy02.jpg')},
    // {_id: 19, imageSource: require('../../../assets/dummy03.jpg')},
    // {_id: 20, imageSource: require('../../../assets/dummy04.jpg')},
    // {_id: 21, imageSource: require('../../../assets/dummy05.jpg')},
  ]);

  const setIsLoaded = (index) => {
    let mposts = [...posts];
    mposts[index].isLoaded = true;
    setPosts(mposts);
  };

  return (
    <View style={{flex: 1, backgroundColor: 'black'}}>
      <ScrollView nestedScrollEnabled>
        <FlatList
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{paddingTop: 20}}
          numColumns={2}
          data={posts}
          renderItem={({item, index}) => (
            <ProfileSnapPost {...{index, item, onLoad: setIsLoaded}} />
          )}
          keyExtractor={(item) => `${item._id}-sdflkjsdf`}
        />
      </ScrollView>
    </View>
  );
};
export default ProfileTabContent;
