import React, {Component} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import ArrowBackWhiteSVG from '../../icons/arrowBackWhiteSVG';
import UploadWhiteSVG from '../../icons/uploadWhiteSVG';
import {goBack} from '../../navigator';
class SoundHeaderContainer extends Component {
  state = {};
  render() {
    return (
      <View
        style={{
          width: '100%',
          height: 50,
          backgroundColor: SECONDRY_BLACK,
          flexDirection: 'row',
        }}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => goBack()}
          style={{
            width: 50,
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <ArrowBackWhiteSVG size={16} />
        </TouchableOpacity>
        <View style={{flex: 1}}>{this.props.children}</View>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={this.props.onPressRight}
          style={{
            width: 50,
            height: '100%',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {this.props.noRightIcon ? false : <UploadWhiteSVG size={16} />}
        </TouchableOpacity>
      </View>
    );
  }
}

export default SoundHeaderContainer;
