import React, {Component, useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import MyInboxController from '../../controllers/inboxController';
import {LIGHT_GRAY, SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';

const InboxChatItem = (props) => {
  const size = 55;
  const isSelected = props.isSelected ? true : false;
  const selectable = props.selectable ? true : false;
  const [itemSelected, setItemSelected] = useState(isSelected);
  const singleChat = props.singleChat
    ? props.singleChat
    : MyInboxController.getDummy('username');

  return (
    <TouchableOpacity
      onPress={
        props.onPress
          ? () => props.onPress()
          : () => setItemSelected(!itemSelected)
      }
      activeOpacity={1}
      style={{
        width: '100%',
        height: size + 10,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View style={{flex: 3, flexDirection: 'row', alignItems: 'center'}}>
        <Image
          style={{
            width: size,
            height: size,
            borderRadius: 50,
            backgroundColor: '#555555',
          }}
        />
        <View style={{padding: 10}}>
          <Text style={{color: WHITE_COLOR, fontSize: size / 3.5}}>
            {singleChat.username}
          </Text>
          <Text style={{color: 'gray', fontSize: size / 5}}>
            {singleChat.desc === ''
              ? 'This is where messages goes . 2d'
              : singleChat.desc}
          </Text>
        </View>
        {selectable ? (
          <View style={{flex: 1, alignItems: 'flex-end'}}>
            <TouchableOpacity
              style={{
                flex: 1,
                marginRight: 10,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              {itemSelected ? (
                <View
                  style={{
                    height: 15,
                    width: 15,
                    backgroundColor: WHITE_COLOR,
                    borderRadius: 20,
                    borderColor: WHITE_COLOR,
                    borderWidth: 2,
                  }}
                />
              ) : (
                <View
                  style={{
                    height: 15,
                    width: 15,
                    borderRadius: 20,
                    borderColor: LIGHT_GRAY,
                    borderWidth: 2,
                  }}
                />
              )}
            </TouchableOpacity>
          </View>
        ) : (
          false
        )}
      </View>
    </TouchableOpacity>
  );
};
export default InboxChatItem;
