import React, {PureComponent} from 'react';
import {View, Text, StatusBar, Dimensions, FlatList} from 'react-native';
import ViewPager from '@react-native-community/viewpager';
import {connect} from 'react-redux';
// import ForYouFollowingTabPage from '../components/foryouFollowing/forYouFollowingTabPage';
import {SECONDRY_BLACK} from '../../themes/colors';
import ForYouItem from './forYouItem';
import MyForYouController from '../../controllers/forYouController';
//  React.useEffect(() => {
//    const unsubscribe = navigation.addListener('focus', () => {
//      // The screen is focused
//      // Call any action
//    });

//    // Return the function to unsubscribe from the event so it gets removed on unmount
//    return unsubscribe;
//  }, [navigation]);
class ForYouTabPage extends PureComponent {
  constructor() {
    super();
    this.state = {
      // stories: [
      //   {_id: 0, title: 'abc0', bgColor: '#CE4760', liked: false, comments: []},
      //   {_id: 1, title: 'abc1', bgColor: '#283F3B', liked: false, comments: []},
      //   {_id: 2, title: 'abc2', bgColor: '#2374AB', liked: false, comments: []},
      //   {_id: 3, title: 'abc3', bgColor: '#CD8987', liked: false, comments: []},
      // ],
      scrollEnabled: true,
      currentPage: 0, //// TODOIOS:
    };
    this.DIMENSIONS = Dimensions.get('window');
    this.storyFlatListRef = null;
    this.CONTENT_WIDTH = 0;
    this.INITIALIZED = 0;
  }

  componentDidMount() {
    setTimeout(() => {
      this.INITIALIZED = 1;
      if (this.storyFlatListRef) {
        this.storyFlatListRef.scrollToOffset({animated: false, offset: 10});
      }

      // this.storyFlatListRef.scrollToIndex({index: 2, animated: true});
      // this.storyFlatListRef.scrollToOffset({animated: true, offset: 1});
    }, 100);
  }

  toggleMainScrollEnabled = (value) => {
    this.setState({toggleMainScrollEnabled: value});
  };

  onNext = (index) => {
    if (index < this.props.stories.length - 1) {
      this.storyFlatListRef.scrollToIndex({index: index + 1});
    }
  };

  onPrevious = (index) => {
    if (index > 0) {
      this.storyFlatListRef.scrollToIndex({index: index - 1});
    }
  };

  _handleTransition = (nativeEvent) => {
    let offsets = nativeEvent.contentOffset.y;
    let modul = offsets % this.CONTENT_HEIGHT;
    let currentIndex = (offsets - modul) / this.CONTENT_HEIGHT;
    let scrollLeft = nativeEvent.velocity.y < 0 ? true : false;
    let velocityY =
      nativeEvent.velocity.y < 0
        ? -nativeEvent.velocity.y
        : nativeEvent.velocity.y;
    if (velocityY > 1.6) {
      if (scrollLeft) {
        // console.log('GOING NEXT: VELOCITY');
        this.onNext(currentIndex);
      } else {
        this.storyFlatListRef.scrollToIndex({index: currentIndex});
      }
    } else if (modul < 140) {
      this.storyFlatListRef.scrollToIndex({index: currentIndex});
    } else {
      // console.log('GOING NEXT: OFFSET');
      this.onNext(currentIndex);
    }
  };

  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={true} backgroundColor={SECONDRY_BLACK} />
        <ViewPager
          onPageSelected={({nativeEvent}) =>
            this.setState({currentPage: nativeEvent.position})
          }
          orientation="vertical"
          style={{flex: 1}}
          initialPage={0}>
          {this.props.stories.map((item, index) => (
            <ForYouItem
              key={`${index}`}
              {...{
                story: item,
                currentIndex: index,
                currentPage: this.state.currentPage,
              }}
            />
          ))}
        </ViewPager>

        {/* <FlatList
          showsVerticalScrollIndicator={false}
          scrollEventThrottle={16}
          data={this.props.stories}
          ref={(e) => (this.storyFlatListRef = e)}
          renderItem={({item, index}) => (
            <ForYouItem
              {...{
                story: item,
              }}
            />
          )}
          keyExtractor={(item) =>
            `${item._id}-${Math.round(Math.random() * 1000)}`
          }
          onLayout={({nativeEvent}) => {
            this.CONTENT_HEIGHT = nativeEvent.layout.height;
          }}
          onScroll={({nativeEvent}) => {
            if (this.INITIALIZED === 0) {
              this.INITIALIZED = 1;
              this._handleTransition({contentOffset: {x: 1}, velocity: {x: 1}});
            }
          }}
          onScrollEndDrag={({nativeEvent}) => {
            this._handleTransition(nativeEvent);
          }}
          getItemLayout={(data, index) => ({
            length: this.DIMENSIONS.height,
            offset: this.DIMENSIONS.height * index,
            index,
          })}
        /> */}
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  stories: state.ForYouReducer.stories,
});
export default connect(mapStateToProps, null)(ForYouTabPage);
