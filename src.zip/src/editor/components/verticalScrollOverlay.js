import React, {useEffect, useState} from 'react';
import {View, Text} from 'react-native';
import {useSelector} from 'react-redux';
import VerticalScroll from 'rn-vertical-slider';
import MyRecordingController from '../Controllers/recordingConroller';
const barBorderRadius = 10;
const barWidth = 27;
const VerticalScrollOverlay = (props) => {
  const [zoomValue, setZoomValue] = useState(1);
  const camZoom = useSelector((store) => store.EditorReducer.recorder.camZoom);
  // useEffect(() => {
  //   setZoomValue(Math.round(camZoom * 100));
  // }, [camZoom]);
  let valueZ = Math.round(camZoom * 100);
  return (
    <View
      style={{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',
        zIndex: 9999,
      }}>
      <Text
        style={{
          color: 'white',
          fontSize: 12,
        }}>{`${valueZ}%`}</Text>
      <VerticalScroll
        value={valueZ}
        disabled={false}
        min={0}
        max={100}
        ballIndicatorHeight={barWidth}
        ballIndicatorWidth={barWidth}
        showBallIndicator
        onChange={(value) => {
          setTimeout(() => {
            MyRecordingController.setRecorderKeyValue('camZoom', value / 100);
          }, 5);
        }}
        onComplete={(value) => {
          console.log('COMPLETE', value);
        }}
        renderIndicator={(props) => (
          <View
            style={{
              width: barWidth,
              height: barWidth,
              backgroundColor: '#E4E4E4',
              marginLeft: 120,
              borderRadius: barBorderRadius,
              elevation: 1,
            }}
          />
        )}
        width={barWidth}
        height={200}
        step={1}
        borderRadius={barBorderRadius}
        minimumTrackTintColor={'gray'}
        maximumTrackTintColor={'gray'}
        ballIndicatorColor={'gray'}
      />
    </View>
  );
};

export default VerticalScrollOverlay;
