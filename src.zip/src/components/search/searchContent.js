import React from 'react';
import {View, Text} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import ResultsTabPage from './resultsTabPage';
import UsersTabPage from './usersTabPage';
import HashtagTabPage from './hashtagTabPage';
import MyTabBar from '../profile/myTabBar';

const Tab = createMaterialTopTabNavigator();

const SearchContent = (props) => {
  return (
    <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
      <Tab.Navigator
        sceneContainerStyle={{backgroundColor: SECONDRY_BLACK}}
        style={{backgroundColor: SECONDRY_BLACK}}
        initialRouteName="Results"
        tabBar={(props) => (
          <MyTabBar
            {...props}
            onChange={(value) => {
              console.log(value);
            }}
          />
        )}>
        <Tab.Screen name="Results" component={ResultsTabPage} />
        <Tab.Screen name="Users" component={UsersTabPage} />
        <Tab.Screen name="Hashtags" component={HashtagTabPage} />
      </Tab.Navigator>
    </View>
  );
};
export default SearchContent;
