import React, {Component} from 'react';
import {View, Text, Image, Animated, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import Icon from 'react-native-vector-icons/FontAwesome5';
import MyProfileAnimController from '../../screens/profileAnimController';

const ProfileHeader = (props) => {
  return (
    <View
      onLayout={({nativeEvent}) =>
        props.onHeaderLayout
          ? props.onHeaderLayout(nativeEvent.layout.height)
          : () => false
      }
      style={[
        {
          width: '100%',
          minHeight: 40,
          backgroundColor: SECONDRY_BLACK,
          padding: 5,
          paddingLeft: 10,
          paddingRight: 10,
        },
        {...props.style},
      ]}>
      <TouchableOpacity
        activeOpacity={1}
        onPress={() => MyProfileAnimController.scrollToTop()}
        style={{
          alignSelf: 'center',
          backgroundColor: SECONDRY_BLACK,
          minHeight: 40,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <View
          style={{
            flexDirection: 'row',
            alignSelf: 'center',
            backgroundColor: 'transparent',
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              minWidth: 35,
            }}>
            <Animated.Image
              style={[
                {
                  width: 35,
                  height: 36,
                  borderRadius: 50,
                  backgroundColor: '#f0f0f0',
                  marginRight: 20,
                },
                {...props.imageStyle},
              ]}
              source={require('../../assets/userimg.jpg')}
            />
          </View>

          <Text
            style={{
              color: WHITE_COLOR,
              fontSize: 15,
              fontWeight: 'bold',
              textShadowColor: '#f0f0f0',
              textShadowRadius: 3,
            }}>
            Chris Gullette
          </Text>
        </View>
        <Icon
          style={{
            color: WHITE_COLOR,
            fontSize: 20,
            padding: 10,
          }}
          name="ellipsis-h"
        />
      </TouchableOpacity>
    </View>
  );
};
export default ProfileHeader;
