export const PRIMARY_RED = '#C30303';
export const SECONDRY_BLACK = '#222222';
export const WHITE_COLOR = 'white';
export const GRAY_COLOR = '#f0f0f0';
export const DARK_GRAY = '#494949';
export const LIGHT_GRAY = '#C4C4C4';
