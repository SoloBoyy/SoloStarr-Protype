import store from '../../store';
import {
  SET_EDITOR_MODE,
  SET_EDITOR_LAYOUT_MODE,
  SET_MODE,
  SET_BOTTOM_MENU_MODE,
  SET_LOADER_KEY_VALUE,
  SET_KEY_VALUE,
} from '../actionTypes';
import MyLayoutModal from './myLayoutModal';
import MyRecordingController from './recordingConroller';
class LayoutManager {
  constructor() {
    this.rootContext = null;
    this.VIDEO_MAKING_MODE = 'VIDEO_MAKING_MODE';
    this.VIDEO_EDITING_MODE = 'VIDEO_EDITING_MODE';
    this.MODES = {
      VIDEO_NONE_MODE: 'VIDEO_NONE_MODE',
      VIDEO_COUNTER_RUNNING: 'VIDEO_COUNTER_RUNNING',
      VIDEO_CREATOR_INITIAL: 'VIDEO_CREATOR_INITIAL',
      VIDEO_RECORDING: 'VIDEO_RECORDING',
      VIDEO_RECORDING_PAUSE: 'VIDEO_RECORDING_PAUSE',
      VIDEO_RECORDING_COMPLETED: 'VIDEO_RECORDING_COMPLETED',
      VIDEO_RECORDED_AFTER_OPTIONS: 'VIDEO_RECORDED_AFTER_OPTIONS',
      EDITOR_INITIAL_AUTO_PLAY_OPTIONS: 'EDITOR_INITIAL_AUTO_PLAY_OPTIONS',
    };

    this.setRootContext = (_context) => {
      this.rootContext = _context;
    };

    this.navigateTo = (routeName) => {
      if (this.rootContext) {
        this.rootContext.props.navigation.push(routeName);
      }
    };

    this.LAYOUT_MODE = {
      NONE: new MyLayoutModal(),

      ZERO_CAM_ON: new MyLayoutModal()
        .setEnabled(MyLayoutModal.H_L_CROSS)
        .setEnabled(MyLayoutModal.H_C_TABS)
        .setEnabled(MyLayoutModal.SIDE_BAR_CONTROLS)
        .setEnabled(MyLayoutModal.F_C_CAPTURE_INITIAL),

      ONE_CAM_RUNNING: new MyLayoutModal()
        .setEnabled(MyLayoutModal.H_RECORDING_BAR)
        .setEnabled(MyLayoutModal.F_C_CAPTURE_INITIAL)
        .setEnabled(MyLayoutModal.CAM_ZOOM_SCROLL_BAR),

      TWO_CAM_PAUSE: new MyLayoutModal()
        .setEnabled(MyLayoutModal.H_RECORDING_BAR)
        .setEnabled(MyLayoutModal.SIDE_BAR_CONTROLS)
        .setEnabled(MyLayoutModal.F_C_CAPTURE_INITIAL)
        .setEnabled(MyLayoutModal.F_L_UNDO)
        .setEnabled(MyLayoutModal.F_R_NEXT_ARROW),

      THREE_CAM_RUNNING: new MyLayoutModal()
        .setEnabled(MyLayoutModal.H_RECORDING_BAR)
        .setEnabled(MyLayoutModal.SIDE_BAR_CONTROLS)
        .setEnabled(MyLayoutModal.F_L_UNDO)
        .setEnabled(MyLayoutModal.F_R_NEXT_ARROW),

      FOUR_CAM_RECORDING_COMPLETED: new MyLayoutModal()
        .setEnabled(MyLayoutModal.F_L_UNDO)
        .setEnabled(MyLayoutModal.F_R_NEXT_ARROW)
        .setEnabled(MyLayoutModal.F_C_CAPTURE_INITIAL)
        .setEnabled(MyLayoutModal.H_RECORDING_BAR),

      ZERO_EDITOR_VIDEO_PREVIEW: new MyLayoutModal()
        .setEnabled(MyLayoutModal.SIDE_BAR_CONTROLS)
        .setEnabled(MyLayoutModal.H_C_TABS)
        .setEnabled(MyLayoutModal.H_L_ARROW_LEFT)
        .setEnabled(MyLayoutModal.F_VIDEO_CLIPS_TIMELINE),
    };

    this.setMode = (mode) => {
      store.dispatch({
        type: SET_MODE,
        payload: mode,
      });
    };
    this.setEditorMode = (modeStr) => {
      store.dispatch({
        type: SET_EDITOR_MODE,
        payload: modeStr,
      });
    };
    this.setEditorLayoutMode = (mode) => {
      store.dispatch({
        type: SET_EDITOR_LAYOUT_MODE,
        payload: mode,
      });
    };

    this.initialize = () => {
      this.setMode(this.VIDEO_MAKING_MODE);
      this.setEditorMode(this.MODES.VIDEO_CREATOR_INITIAL);
      this.setEditorLayoutMode(this.LAYOUT_MODE.ZERO_CAM_ON);
    };

    this.setBottomOptionMenuMode = (value) => {
      store.dispatch({
        type: SET_BOTTOM_MENU_MODE,
        payload: value,
      });
    };

    this.switchCamMode = (spescialCase = false) => {
      let editorMode = store.getState().EditorReducer.editorMode;
      let durationPeak = store.getState().EditorReducer.recorder.durationPeak;
      let durationSeek = store.getState().EditorReducer.recorder.durationSeek;

      // console.log('TEST 04 - Initial Cam Mode');
      // console.log(editorMode);
      if (spescialCase) {
        if (durationSeek === 0) {
          this.setEditorMode(this.MODES.VIDEO_CREATOR_INITIAL);
          this.setEditorLayoutMode(this.LAYOUT_MODE.ZERO_CAM_ON);
          console.log('SWITCHED CAM MODE: CAM PAUSED');
        } else if (durationSeek < durationPeak) {
          this.setEditorMode(this.MODES.VIDEO_RECORDING_PAUSE);
          this.setEditorLayoutMode(this.LAYOUT_MODE.TWO_CAM_PAUSE);
          console.log('SWITCHED CAM MODE: CAM PAUSED');
        }
      } else {
        switch (editorMode) {
          case this.MODES.VIDEO_CREATOR_INITIAL:
            this.setEditorMode(this.MODES.VIDEO_RECORDING);
            this.setEditorLayoutMode(this.LAYOUT_MODE.ONE_CAM_RUNNING);
            console.log('SWITCHED CAM MODE: CAM RUNNING');
            break;

          case this.MODES.VIDEO_RECORDING:
            this.setEditorMode(this.MODES.VIDEO_RECORDING_PAUSE);
            this.setEditorLayoutMode(this.LAYOUT_MODE.TWO_CAM_PAUSE);
            console.log('SWITCHED CAM MODE: CAM PAUSED');
            break;

          case this.MODES.VIDEO_RECORDING_PAUSE:
            this.setEditorMode(this.MODES.VIDEO_RECORDING);
            this.setEditorLayoutMode(this.LAYOUT_MODE.ONE_CAM_RUNNING);
            console.log('SWITCHED CAM MODE: CAM RUNNING');
            break;

          case this.MODES.VIDEO_COUNTER_RUNNING:
            this.setEditorMode(this.MODES.VIDEO_RECORDING);
            this.setEditorLayoutMode(this.LAYOUT_MODE.ONE_CAM_RUNNING);
            console.log('SWITCHED CAM MODE: CAM RUNNInG');
            break;

          case this.MODES.VIDEO_RECORDING_COMPLETED:
            if (durationSeek < durationPeak) {
              this.setEditorMode(this.MODES.VIDEO_RECORDING_PAUSE);
              this.setEditorLayoutMode(this.LAYOUT_MODE.TWO_CAM_PAUSE);
              console.log('SWITCHED CAM MODE: CAM PAUSED');
            } else {
              this.setEditorMode(this.MODES.VIDEO_RECORDING_COMPLETED);
              this.setEditorLayoutMode(
                this.LAYOUT_MODE.FOUR_CAM_RECORDING_COMPLETED,
              );
              console.log('SWITCHED CAM MODE: CAM RECORDING COMPLETED');
            }
            break;
          default:
            this.initialize();
            break;
        }
      }
    };

    this.initializeEditor = () => {
      this.setMode(this.VIDEO_EDITING_MODE);
      // this.setEditorMode(this.MODES.EDITOR_INITIAL_AUTO_PLAY_OPTIONS);
      // this.setEditorLayoutMode(this.LAYOUT_MODE.ZERO_EDITOR_VIDEO_PREVIEW);
    };

    this.fromEditorToVideoMaking = () => {
      this.setMode(this.VIDEO_MAKING_MODE);
      // this.setEditorMode(this.MODES.VIDEO_RECORDING_PAUSE);
      // this.setEditorLayoutMode(this.LAYOUT_MODE.TWO_CAM_PAUSE);
    };

    this.switchEditorMode = () => {
      let editorMode = store.getState().EditorReducer.editorMode;
      switch (editorMode) {
        case this.MODES.EDITOR_INITIAL_AUTO_PLAY_OPTIONS:
          break;
        default:
          this.initializeEditor();
          break;
      }
    };

    this.setLoaderVisible = (visible, message) => {
      return new Promise((resolve, reject) => {
        store.dispatch({
          type: SET_KEY_VALUE,
          payload: {
            key: 'loader',
            value: {
              visible,
              message,
            },
          },
        });
        resolve(true);
      });
    };

    this.setRecordingSpeedVisible = (visible) => {
      store.dispatch({
        type: SET_KEY_VALUE,
        payload: {
          key: 'recordingSpeedVisible',
          value: visible,
        },
      });
    };
    this.toggleRecordingSpeed = () => {
      let recordingSpeedVisible = store.getState().EditorReducer
        .recordingSpeedVisible;
      this.setRecordingSpeedVisible(!recordingSpeedVisible);
    };
    this.setRecordingSpeedValue = (recordingSpeed) => {
      store.dispatch({
        type: SET_KEY_VALUE,
        payload: {
          key: 'recordingSpeed',
          value: recordingSpeed,
        },
      });
    };
    this.toggleFlashMode = () => {
      let flashMode = store.getState().EditorReducer.flashMode;
      // console.log(`TEST-1, FlashMode ${flashMode}`);
      if (flashMode === 0) {
        // console.log(`TEST-2 Turning On`);
        MyRecordingController.setKeyValue({key: 'flashMode', value: 2});
      } else {
        // console.log(`TEST-2 Turning Off`);
        MyRecordingController.setKeyValue({key: 'flashMode', value: 0});
      }
    };
  }
}
const MyLayoutManager = new LayoutManager();
export default MyLayoutManager;
