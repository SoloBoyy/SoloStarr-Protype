import React, {Component} from 'react';

import {
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

class HomeScreen extends Component {
  state = {};
  render() {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <StatusBar backgroundColor={'black'} />
        <TouchableOpacity
          onPress={() => {
            this.props.navigation.push('EditorNavigator');
          }}
          style={Styles.btnCircle}>
          <Text style={Styles.btnText}>Editor</Text>
        </TouchableOpacity>
        <View style={{height: 20}} />
        <TouchableOpacity
          onPress={() => {
            this.props.navigation.push('ProfileScreen');
          }}
          style={Styles.btnCircle}>
          <Text style={Styles.btnText}>Profile</Text>
        </TouchableOpacity>
        <View style={{height: 20}} />

        <TouchableOpacity
          onPress={() => {
            this.props.navigation.push('InboxNavigator');
          }}
          style={Styles.btnCircle}>
          <Text style={Styles.btnText}>Inbox</Text>
        </TouchableOpacity>
        <View style={{height: 20}} />

        <TouchableOpacity
          onPress={() => {
            this.props.navigation.push('SearchScreen');
          }}
          style={Styles.btnCircle}>
          <Text style={Styles.btnText}>Search</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export default HomeScreen;

const Styles = StyleSheet.create({
  btnCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnText: {
    color: 'white',
  },
});
