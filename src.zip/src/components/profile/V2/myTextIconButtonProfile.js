import React, {Component} from 'react';
import {TouchableOpacity, Text, View} from 'react-native';
import IconFA5 from 'react-native-vector-icons/FontAwesome5';
class MyTextIconButtonProfile extends Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    const size = this.props.size ? this.props.size : 35;
    const topMargin = this.props.topMargin ? this.props.topMargin : 0;
    const color = 'white';
    const backgroundColor = '#2A2A2A';
    const title = this.props.title ? this.props.title : '';
    return (
      <TouchableOpacity
        onPress={this.props.onPress ? () => this.props.onPress() : () => false}
        style={{
          width: size * 0.9,
          height: title === '' ? size : size * 1.6,
          alignItems: 'center',
          marginTop: topMargin,
        }}>
        <View
          style={{
            width: size * 0.6,
            height: size * 0.6,
            elevation: 0,
            borderRadius: 50,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          {/* <IconFA5 name={iconName} color={color} size={size * 0.85} /> */}
          {/* <Icon color={color} size={size * 0.85} /> */}
          {React.cloneElement(this.props.children, {color, size: size * 0.5})}
        </View>
        {title !== '' ? (
          <Text
            style={{
              fontSize: size * 0.17,
              fontWeight: 'bold',
              color,
            }}>
            {title}
          </Text>
        ) : (
          false
        )}
      </TouchableOpacity>
    );
  }
}
export default MyTextIconButtonProfile;
