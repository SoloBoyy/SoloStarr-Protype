import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const SearchWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="23.996" height="23.996" viewBox="0 0 23.996 23.996">
  <g id="Icon_feather-search" data-name="Icon feather-search" transform="translate(-3.5 -3.5)">
    <path id="Path_3746" data-name="Path 3746" d="M23.684,14.092A9.592,9.592,0,1,1,14.092,4.5,9.592,9.592,0,0,1,23.684,14.092Z" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_3747" data-name="Path 3747" d="M30.191,30.191l-5.216-5.216" transform="translate(-4.109 -4.109)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default SearchWhiteSVG;
