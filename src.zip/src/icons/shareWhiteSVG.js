import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const ShareWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="29.012" height="24.549" viewBox="0 0 29.012 24.549">
  <path id="Icon_ionic-ios-share-alt" data-name="Icon ionic-ios-share-alt" d="M31.268,16.2,21.347,6.919a.507.507,0,0,0-.394-.169c-.309.014-.7.232-.7.563v4.655a.3.3,0,0,1-.253.288c-9.865,1.512-14.02,8.895-15.49,16.559-.056.3.352.584.541.345,3.6-4.535,7.98-7.5,14.906-7.552a.348.348,0,0,1,.3.337v4.57a.6.6,0,0,0,1.02.373l9.991-9.443a.776.776,0,0,0,.246-.591A.942.942,0,0,0,31.268,16.2Z" transform="translate(-3.496 -5.749)" stroke="#fff" stroke-width="2"/>
</svg>
`}
    />
  );
};
export default ShareWhiteSVG;
