import React, {useState} from 'react';
import {View, Text, Dimensions, ScrollView} from 'react-native';
import CommentItem from './commentItem';
import AddCommentBox from './addCommentBox';
import {SECONDRY_BLACK} from '../../../themes/colors';
const CommentSheet = (props) => {
  const {width, height} = Dimensions.get('window');
  const [isReplyBoxVisible, setReplyBoxVisible] = useState(false);

  const TOP_BORDER_RADIOUS = 20;

  return (
    <View
      style={{
        width: '100%',
        backgroundColor: SECONDRY_BLACK,
        padding: 10,
        maxHeight: height * 0.65,
        borderTopRightRadius: TOP_BORDER_RADIOUS,
        borderTopLeftRadius: TOP_BORDER_RADIOUS,
      }}>
      {/* <View style={{width: '100%'}}> */}
      <ScrollView>
        {/* <CommentItem
          onShowReplyBox={() => {
            console.log('Opening Reply box');
            setReplyBoxVisible(true);
          }}
        /> */}
        {props.story.comments.map((comment) => (
          <CommentItem
            commentItem={comment}
            onShowReplyBox={() => setReplyBoxVisible(true)}
          />
        ))}

        {/* <CommentItem onShowReplyBox={() => setReplyBoxVisible(true)} />
        <CommentItem onShowReplyBox={() => setReplyBoxVisible(true)} />
        <CommentItem onShowReplyBox={() => setReplyBoxVisible(true)} /> */}
      </ScrollView>
      {/* </View> */}
      <View>
        <AddCommentBox
          storyId={props.story._id}
          onCloseReplyBox={() => setReplyBoxVisible(false)}
          isReplyBoxVisible={isReplyBoxVisible}
          placeholder="Add Comment"
        />
      </View>
    </View>
  );
};
export default CommentSheet;
