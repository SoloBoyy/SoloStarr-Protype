import React, {Component} from 'react';
import {
  View,
  StyleSheet,
  StatusBar,
  Dimensions,
  Text,
  Platform,
} from 'react-native';
import EditorControlsOverlay from '../components/editorControlsOverlay';
import MyButton from '../components/myButton';
import Icon from 'react-native-vector-icons/FontAwesome5';
import MyLayoutManager from '../Controllers/layoutManager';
import Video from 'react-native-video';
import {connect} from 'react-redux';
import MyEditingController from '../Controllers/editingController';
class VideoEditingScreen extends Component {
  constructor() {
    super();
    this.canRerender = false;
    this.state = {
      showingVideo: true,
      dummySpeed: [0.5, 1, 1.5],
    };
  }
  componentDidMount() {
    MyLayoutManager.setRootContext(this);
  }
  componentDidUpdate(prevProps, prevState) {
    if (this.canRerender) {
      this.canRerender = false;
      if (Platform.OS === 'ios') {
        this.setState({showingVideo: false}, () => {
          this.setState({showingVideo: true});
        });
      }
    }
  }
  render() {
    // console.log('EDITOR OUTPUT');
    // console.log(this.props.editor);
    // console.log('this.props.editor.videoRepeate');
    // console.log(this.props.editor.videoRepeate);
    // console.log(this.props.editor.playingMode);
    const {width, height} = Dimensions.get('window');
    return (
      <View style={[Styles.container, {width, height}]}>
        <StatusBar hidden />
        {/* <View style={{position: 'absolute', top: 30, left: 20, zIndex: 99}}>
          <MyButton
            onPress={() => this.props.navigation.goBack()}
            name="arrow-left"
            size={40}
          />
        </View> */}

        {this.props.editor.playingSource ? (
          this.state.showingVideo ? (
            <Video
              key={0}
              rate={this.props.editor.playingSpeed}
              repeat={this.props.editor.videoRepeate}
              resizeMode="cover"
              source={this.props.editor.playingSource} // Can be a URL or a local file.
              ref={(ref) => {
                this.player = ref;
              }} // Store reference
              onError={(err) => {
                console.log('Video Playing Error');
                console.log(err);
              }}
              onEnd={() => {
                this.canRerender = true;
                MyEditingController.handlePlayNext();
              }}
              // onProgress={() => console.log('Progressn')}
              style={{
                width,
                height,
              }}
            />
          ) : (
            <View style={{flex: 1, backgroundColor: 'white'}} />
          )
        ) : (
          <Text style={{color: 'white', fontSize: 30, alignSelf: 'center'}}>
            EMPTY SOURCE
          </Text>
        )}
        {/* <Text style={{color: 'white'}}>TESXt</Text> */}
        <EditorControlsOverlay playingSpeed={this.props.editor.playingSpeed} />
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  editor: state.EditorReducer.editor,
});
export default connect(mapStateToProps, null)(VideoEditingScreen);

const Styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#111111',
  },
});
