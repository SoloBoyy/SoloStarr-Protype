import React, {Component} from 'react';
import {View, Text, StatusBar, TouchableOpacity} from 'react-native';
import {} from 'react-native-gesture-handler';
import StartWhiteSVG from '../icons/startWhiteSVG';
import {SECONDRY_BLACK} from '../themes/colors';

const AuthButton = (props) => {
  return (
    <TouchableOpacity
      onPress={props.onPress ? props.onPress : () => false}
      style={{
        width: 150,
        height: 35,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'black',
        borderRadius: 10,
      }}>
      <Text style={{color: 'white'}}>{props.title}</Text>
    </TouchableOpacity>
  );
};

class LoginScreen extends Component {
  state = {};
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar backgroundColor={SECONDRY_BLACK} />
        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
          <View
            style={{
              backgroundColor: 'black',
              width: 150,
              height: 150,
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <StartWhiteSVG
              style={{transform: [{rotateZ: '-15deg'}]}}
              size={80}
            />
            <Text
              style={{
                color: 'white',
                fontSize: 17,
                fontWeight: 'bold',
                marginTop: 10,
              }}>
              SoloStarr
            </Text>
          </View>
        </View>
        <View style={{flex: 1.2, alignItems: 'center'}}>
          <Text style={{color: 'white', fontSize: 18}}>Login</Text>
          <View style={{height: 40}} />
          <AuthButton
            {...{title: 'Apple', onPress: () => this.props.onAuth(true)}}
          />
          <View style={{height: 20}} />
          <AuthButton
            {...{title: 'Google', onPress: () => this.props.onAuth(true)}}
          />
          <View style={{height: 20}} />

          <AuthButton
            {...{title: 'Facebook', onPress: () => this.props.onAuth(true)}}
          />
          <View style={{height: 20}} />

          <AuthButton
            {...{title: 'Yahoo', onPress: () => this.props.onAuth(true)}}
          />
        </View>
      </View>
    );
  }
}

export default LoginScreen;
