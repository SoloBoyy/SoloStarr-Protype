import React, {Component} from 'react';
import {
  View,
  Text,
  StatusBar,
  FlatList,
  Animated,
  Dimensions,
} from 'react-native';
import ProfileFollowBoxItem from '../components/profile/followBoxItem';
import ProfileHeader from '../components/profile/profileHeader';
import ProfileSearchBox from '../components/profile/searchBox';
import TabButton from '../components/profile/tabButton';
import {SECONDRY_BLACK} from '../themes/colors';
import MyTabBar from '../components/profile/myTabBar';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const Tab = createMaterialTopTabNavigator();

class FollowerScreen extends Component {
  constructor() {
    super();
    this.state = {
      followers: [
        {_id: 1},
        {_id: 2},
        {_id: 3},
        {_id: 4},
        {_id: 5},
        {_id: 6},
        {_id: 7},
        {_id: 8},
        {_id: 9},
        {_id: 10},
        {_id: 11},
        {_id: 12},
        {_id: 13},
        {_id: 14},
        {_id: 15},
        {_id: 16},
        {_id: 17},
        {_id: 18},
        {_id: 19},
        {_id: 20},
        {_id: 21},
      ],
      followings: [
        {_id: 1},
        {_id: 2},
        {_id: 3},
        {_id: 4},
        {_id: 5},
        {_id: 6},
        {_id: 7},
        {_id: 8},
        {_id: 8},
      ],
      initialRouteName: 'Followings',
    };

    this.height = Dimensions.get('window').height;
    this.width = Dimensions.get('window').width;
    this.yOffset = new Animated.Value(0);
    this.headerHeight = this.yOffset.interpolate({
      inputRange: [0, 50],
      outputRange: [0, -50],
      extrapolate: 'clamp',
    });
    this.headerVisible = this.yOffset.interpolate({
      inputRange: [0, 100, 200],
      outputRange: [0, 0.5, 1],
      extrapolate: 'clamp',
    });
  }

  componentDidMount() {
    console.log('Target');
    console.log(this.props.route?.params.target);
    this.setState({initialRouteName: this.props.route?.params.target});
  }
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar hidden={false} backgroundColor={SECONDRY_BLACK} />
        <ProfileHeader />
        <View style={{height: 10}} />
        {/* <View
          style={{
            height: 40,
            flexDirection: 'row',
            backgroundColor: SECONDRY_BLACK,
          }}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <TabButton {...{title: '127k Followers', selected: true}} />
          </View>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <TabButton {...{title: '127k Followings', selected: false}} />
          </View>
        </View> */}

        <View style={{height: 10}} />
        <Animated.View
          style={[
            {
              height: this.height,
              width: this.width,
            },
          ]}>
          <Tab.Navigator
            initialRouteName={this.props.route?.params.target}
            style={{backgroundColor: SECONDRY_BLACK}}
            tabBar={(props) => (
              <MyTabBar
                {...props}
                onChange={(value) => {
                  console.log(value);
                }}
              />
            )}>
            <Tab.Screen
              name={`${this.state.followers.length} Followers`}
              children={(props) => (
                <View
                  style={{
                    width: '100%',
                    alignSelf: 'center',
                    backgroundColor: SECONDRY_BLACK,
                  }}>
                  <View
                    style={{
                      width: '90%',
                      alignSelf: 'center',
                      backgroundColor: SECONDRY_BLACK,
                    }}>
                    <View style={{height: 10}} />
                    <Animated.View
                      style={{transform: [{translateY: this.headerHeight}]}}>
                      <ProfileSearchBox />
                    </Animated.View>
                    <View style={{height: 10}} />
                    <AnimatedFlatList
                      style={{transform: [{translateY: this.headerHeight}]}}
                      onScroll={Animated.event(
                        [
                          {
                            nativeEvent: {
                              contentOffset: {
                                y: this.yOffset,
                              },
                            },
                          },
                        ],
                        {useNativeDriver: true}, //83tert <-- Add this
                      )}
                      showsVerticalScrollIndicator={false}
                      data={this.state.followers}
                      renderItem={({item, index}) => (
                        <ProfileFollowBoxItem {...{follower: item}} />
                      )}
                      keyExtractor={(item) =>
                        `${Math.round(Math.random() * 10000)}${item._id}`
                      }
                    />
                  </View>
                </View>
              )}
            />
            <Tab.Screen
              name={`${this.state.followings.length} Followings`}
              children={(props) => (
                <View
                  style={{
                    width: '100%',
                    alignSelf: 'center',
                    backgroundColor: SECONDRY_BLACK,
                  }}>
                  <View
                    style={{
                      width: '90%',
                      alignSelf: 'center',
                      backgroundColor: SECONDRY_BLACK,
                    }}>
                    <View style={{height: 10}} />
                    <ProfileSearchBox />
                    <View style={{height: 10}} />
                    <AnimatedFlatList
                      showsVerticalScrollIndicator={false}
                      data={this.state.followings}
                      renderItem={({item, index}) => (
                        <ProfileFollowBoxItem {...{follower: item}} />
                      )}
                      keyExtractor={(item) =>
                        `${Math.round(Math.random() * 10000)}${item._id}`
                      }
                    />
                  </View>
                </View>
              )}
            />
          </Tab.Navigator>
        </Animated.View>
      </View>
    );
  }
}

export default FollowerScreen;
