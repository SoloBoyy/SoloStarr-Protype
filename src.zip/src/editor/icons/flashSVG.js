import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const FlashSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="24.14" height="32" viewBox="0 0 24.14 32">
  <g id="thunder" transform="translate(-62.879)">
    <g id="Group_6" data-name="Group 6" transform="translate(62.879)">
      <path id="Path_17" data-name="Path 17" d="M87.019,10.113H76.054L81.883,0H68.7L62.879,16.638h9.359L68.09,32ZM65.5,14.778,70.021,1.86h8.643L72.835,11.973H82.951L72.008,24.626l2.66-9.849H65.5Z" transform="translate(-62.879)" fill="#f0f0f0"/>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default FlashSVG;
