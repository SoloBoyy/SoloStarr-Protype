import React, {useEffect, useRef, useState} from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  Text,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import {
  TapGestureHandler,
  State,
  LongPressGestureHandler,
} from 'react-native-gesture-handler';
import {useSelector} from 'react-redux';
import MyForYouController from '../../controllers/forYouController';
import ActionsOverlay from './actionsOverlay';
import DescTags from './descTags';
import ForYouOverlay, {BOTTOM_MARGIN} from './forYouOverlay';

import OverlayModal from './overlayModal';
import CommentSheet from './commentSheet';
import ShareSheet from './shareBox';
import {SIZE} from './hitBox';
import VideoPlayer from 'react-native-video';
import LinearGradient from 'react-native-linear-gradient';
import {useKeyboard} from '../keybordHeight';

const {width, height} = Dimensions.get('window');

const ForYouItem = (props) => {
  const doubleTapRef = useRef();
  const singleTapRef = useRef();
  const playerRef = useRef();

  /// Comments Sheet Visible
  const layout = useSelector((state) => state.ForYouReducer.layout);
  // const [csVisible, setCSVisible] = useState(false);
  const setCSVisible = (value) => {
    // console.log(`Comment Sheet visible ${value}`);
    MyForYouController.setCommentVisible(props.story._id, value);
  };
  const [isPlaying, setIsPlaying] = useState(false);
  // const isPlaying = props.currentIndex === props.currentPage;

  useEffect(() => {
    setIsPlaying(props.currentIndex === props.currentPage);
  }, [props.currentIndex, props.currentPage]);

  /// Social Sheet Visible
  const [ssVisible, setSSVisible] = useState(false);
  const handleTap = ({nativeEvent}) => {
    switch (nativeEvent.state) {
      case State.ACTIVE:
        if (isPlaying === false) {
          setIsPlaying(true);
        }
        MyForYouController.toggleADOverlay();
        // setIsPlaying(!isPlaying);
        break;
    }
  };

  useEffect(() => {
    if (props.story.commentsVisible || ssVisible) {
      MyForYouController.setVideoPlayable(false);
    } else {
      MyForYouController.setVideoPlayable(true);
    }
  }, [props.story.commentsVisible, ssVisible]);

  const handleDoubleTap = ({nativeEvent}) => {
    switch (nativeEvent.state) {
      case State.ACTIVE:
        MyForYouController.likeStory(props.story._id, !props.story.liked);
        break;
    }
  };
  // TODOIOS
  const [currentKeybordHeight, setKeybordHeight] = useState(0);
  const keybordHeight = useKeyboard();
  const isIOS = Platform.OS === 'ios';
  // console.log(
  //   `IsPlaying: ${isPlaying}, PLAYABLE: ${layout.FOR_YOU_VIDEO_PLAYABLE}`,
  // );
  return (
    <View
      style={{
        width,
        height,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#333333',
      }}>
      <LongPressGestureHandler
        onHandlerStateChange={({nativeEvent}) => {
          if (nativeEvent.state === State.ACTIVE) {
            console.log('Long  Press Active');
            setIsPlaying(false);
          }
          if (nativeEvent.state === State.END) {
            console.log('Long Press End');
            setIsPlaying(true);
          }
        }}
        waitFor={singleTapRef}>
        <TapGestureHandler
          ref={singleTapRef}
          onHandlerStateChange={handleTap}
          waitFor={doubleTapRef}>
          <TapGestureHandler
            onHandlerStateChange={handleDoubleTap}
            ref={doubleTapRef}
            numberOfTaps={2}>
            <View
              style={{
                ...StyleSheet.absoluteFillObject,
                backgroundColor: 'black',
              }}>
              {/* <Text>
                {!(isPlaying && layout.FOR_YOU_VIDEO_PLAYABLE)
                  ? 'Paused'
                  : 'Playing'}
              </Text> */}
              <VideoPlayer
                key={`${props.currentIndex}`}
                resizeMode="cover"
                style={{
                  flex: 1,
                  backgroundColor: 'black',
                }}
                paused={!(isPlaying && layout.FOR_YOU_VIDEO_PLAYABLE)}
                source={props.story.source}
                repeat
              />
            </View>
          </TapGestureHandler>
        </TapGestureHandler>
      </LongPressGestureHandler>
      {/* Comments Sheet TODOIOS*/}
      <OverlayModal
        setVisible={(value) => {
          setCSVisible(value);
        }}
        visible={props.story.commentsVisible}>
        {isIOS ? (
          <KeyboardAvoidingView
            behavior="padding"
            keyboardVerticalOffset={currentKeybordHeight}>
            <CommentSheet story={props.story} />
          </KeyboardAvoidingView>
        ) : (
          <CommentSheet story={props.story} />
        )}
      </OverlayModal>

      {/* Share Sheet */}
      <OverlayModal
        setVisible={(value) => {
          setSSVisible(value);
        }}
        visible={ssVisible}>
        <ShareSheet />
      </OverlayModal>

      {layout.VIEW_AD_ENABLED ? (
        <>
          <ActionsOverlay
            {...{
              story: props.story,
              onPressComment: () => setCSVisible(true),
              onPressShare: () => setSSVisible(true),
              onPressLike: () =>
                MyForYouController.likeStory(
                  props.story._id,
                  !props.story.liked,
                ),
            }}
            style={{position: 'absolute', bottom: BOTTOM_MARGIN, right: 0}}
          />
          <DescTags
            style={{
              position: 'absolute',
              bottom: BOTTOM_MARGIN + SIZE + 10,
              alignSelf: 'flex-start',
            }}
          />

          <View
            style={{
              position: 'absolute',
              bottom: BOTTOM_MARGIN - 5,
              left: 30,
              alignItems: 'center',
            }}>
            <LinearGradient
              style={{
                width: 40,
                height: 40,
                borderRadius: 50,
              }}
              colors={['#f0f0f0', 'gray']}
            />
            <Text style={{fontSize: 10, color: 'white'}}>Come & Go</Text>
          </View>
        </>
      ) : (
        false
      )}
    </View>
  );
};

export default ForYouItem;
