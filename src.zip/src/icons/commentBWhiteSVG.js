import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CommentBWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="66" height="28" viewBox="0 0 66 28">
  <defs>
    <clipPath id="clip-path">
      <rect width="35" height="8" fill="none"/>
    </clipPath>
  </defs>
  <g id="Group_707" data-name="Group 707" transform="translate(-176 -45)">
    <g id="Rectangle_1592" data-name="Rectangle 1592" transform="translate(176 45)" fill="none" stroke="#fff" stroke-width="2.5">
      <rect width="66" height="28" rx="14" stroke="none"/>
      <rect x="1.25" y="1.25" width="63.5" height="25.5" rx="12.75" fill="none"/>
    </g>
    <g id="Repeat_Grid_20" data-name="Repeat Grid 20" transform="translate(192 55)" clip-path="url(#clip-path)">
      <g transform="translate(-193 -55)">
        <circle id="Ellipse_379" data-name="Ellipse 379" cx="4" cy="4" r="4" transform="translate(193 55)" fill="#fff"/>
      </g>
      <g transform="translate(-180 -55)">
        <circle id="Ellipse_379-2" data-name="Ellipse 379" cx="4" cy="4" r="4" transform="translate(193 55)" fill="#fff"/>
      </g>
      <g transform="translate(-167 -55)">
        <circle id="Ellipse_379-3" data-name="Ellipse 379" cx="4" cy="4" r="4" transform="translate(193 55)" fill="#fff"/>
      </g>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default CommentBWhiteSVG;
