import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const UploadBlackSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="22.625" height="22.625" viewBox="0 0 22.625 22.625">
  <g id="Icon_feather-upload" data-name="Icon feather-upload" transform="translate(-3.5 -3.5)">
    <path id="Path_2202" data-name="Path 2202" d="M25.125,22.5v4.583a2.292,2.292,0,0,1-2.292,2.292H6.792A2.292,2.292,0,0,1,4.5,27.083V22.5" transform="translate(0 -4.25)" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_2203" data-name="Path 2203" d="M21.958,10.229,16.229,4.5,10.5,10.229" transform="translate(-1.417)" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
    <path id="Path_2204" data-name="Path 2204" d="M18,4.5V18.25" transform="translate(-3.188)" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/>
  </g>
</svg>
`}
    />
  );
};
export default UploadBlackSVG;
