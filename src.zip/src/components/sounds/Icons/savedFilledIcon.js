import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const SavedFilledSvg = props => {
  const size = props.size ? props.size : 18;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="21.361" height="26.75" viewBox="0 0 21.361 26.75">
      <path id="Icon_feather-bookmark" data-name="Icon feather-bookmark" d="M26.361,28.75l-9.431-6.736L7.5,28.75V7.194A2.694,2.694,0,0,1,10.194,4.5H23.667a2.694,2.694,0,0,1,2.694,2.694Z" transform="translate(-6.25 -3.25)" fill="#fff" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"/>
    </svg>
           
`}
    />
  );
};
export default SavedFilledSvg;
