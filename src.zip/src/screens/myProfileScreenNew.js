import React, {Component, useRef} from 'react';
import {
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  Modal,
  Platform,
  Dimensions,
  FlatList,
  Image,
} from 'react-native';
import ProfileHeader from '../components/profile/V2/profileHeader';
import ProfileDetailHeader from '../components/profile/V2/profileDetailHeader';
import PostTabContent from '../components/profile/V2/postsTabContent';
import {SECONDRY_BLACK} from '../themes/colors';

const {width, height} = Dimensions.get('window');

class MyProfileScreenNew extends Component {
  constructor() {
    super();
    this.state = {};
    this.HEADER_HEIGHT = Platform.OS === 'ios' ? 110 : 90; ///TODOIOS 90 -> 110
  }

  render() {
    // const {height} = Dimensions.get('window');
    return (
      <View style={{flex: 1, backgroundColor: 'black'}}>
        <StatusBar backgroundColor={SECONDRY_BLACK} />
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          <View
            style={{
              width,
              height: height + this.HEADER_HEIGHT,
              borderBottomLeftRadius: 50,
              borderBottomRightRadius: 50,
              backgroundColor: SECONDRY_BLACK,
              justifyContent: 'space-between',
            }}>
            <ProfileDetailHeader />
            <ProfileHeader />
          </View>
          <View style={{height: height - this.HEADER_HEIGHT}}>
            <PostTabContent />
          </View>
        </ScrollView>

        {/* <Modal
          animationType="none"
          transparent={true}
          visible={this.state.modalVisible}
          onRequestClose={() => {
            this.setState({modalVisible: false});
          }}>
          <View style={{flex: 1, backgroundColor: 'rgba(0,0,0,0.5)'}}>
            <MyProfileDIM
              {...{
                top: this.state.selectedCmp.top,
                left: this.state.selectedCmp.left,
                value: this.state.selectedCmp.value,
              }}
            />
          </View>
        </Modal> */}
      </View>
    );
  }
}

export default MyProfileScreenNew;
