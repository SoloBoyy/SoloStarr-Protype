import React, {Component} from 'react';

import {
  View,
  Text,
  ImageBackground,
  Image,
  Animated,
  PanResponder,
  StatusBar,
} from 'react-native';
// import Animated from 'react-native-reanimated';
import {
  PinchGestureHandler,
  PanGestureHandler,
  State,
} from 'react-native-gesture-handler';
import CircleButton from '../components/inbox/circleButton';
import MyForYouController from '../controllers/forYouController';
import CheckMarkGreenSVG from '../icons/checkMarkGreenSVG';
import {goBack} from '../navigator';
class ImageEditingScreen extends Component {
  constructor() {
    super();
    this.baseScale = new Animated.Value(1);
    this.pinchScale = new Animated.Value(1);
    this.mRef = null;
    this.lastScale = 1;
    this._translateX = new Animated.Value(0);
    this._translateY = new Animated.Value(0);
    this._absoluteX = new Animated.Value(0);
    this._absoluteY = new Animated.Value(0);
    this._lastOffset = {x: 0, y: 0};
    this.scale = Animated.multiply(this.baseScale, this.pinchScale);
    this.scaleValue = 1;
    this._translateXValue = 0;
    this._translateYValue = 0;
    this.scale.addListener(({value}) => {
      this.scaleValue = value;
    });
    this._translateX.addListener(({value}) => {
      this._translateXValue = value;
    });
    this._translateY.addListener(({value}) => {
      this._translateYValue = value;
    });

    this.onGestureEvent = Animated.event(
      [{nativeEvent: {scale: this.pinchScale}}],
      {useNativeDriver: true},
    );
    this.onChangeGestureState = ({nativeEvent}) => {
      if (nativeEvent.oldState === State.ACTIVE) {
        this.lastScale *= nativeEvent.scale;
        this.baseScale.setValue(this.lastScale);
        this.pinchScale.setValue(1);
      }
    };

    this.onPanGestureEvent = Animated.event(
      [
        {
          nativeEvent: {
            translationX: this._translateX,
            translationY: this._translateY,
            x: this._absoluteX,
            y: this._absoluteY,
          },
        },
      ],
      {useNativeDriver: true},
    );
    this._onPanHandlerStateChange = (event) => {
      if (event.nativeEvent.oldState === State.ACTIVE) {
        this._lastOffset.x += event.nativeEvent.translationX;
        this._lastOffset.y += event.nativeEvent.translationY;
        this._translateX.setOffset(this._lastOffset.x);
        this._translateX.setValue(0);
        this._translateY.setOffset(this._lastOffset.y);
        this._translateY.setValue(0);

        // this.mRef.measure((x, y, width, height, pageX, pageY) => {
        //   console.log(
        //     `x:${pageX} y:${pageY} StatusBarHeigh:${StatusBar.currentHeight}`,
        //   );
        // });
      }
    };
  }

  handleSaveImage = () => {
    ///TODO: Save TransitionX, Y and Scale
    MyForYouController.setProfileKeyValue('scale', this.scaleValue);
    MyForYouController.setProfileKeyValue('transform', [
      {translateX: this._translateXValue},
      {translateY: this._translateYValue},
    ]);

    goBack();
  };

  render() {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'black',
        }}>
        <PanGestureHandler
          onGestureEvent={this.onPanGestureEvent}
          onHandlerStateChange={this._onPanHandlerStateChange}
          maxPointers={1}
          minPointers={1}>
          <Animated.View
            ref={(e) => (this.mRef = e)}
            style={{
              width: '100%',
              height: '100%',
              transform: [
                {translateX: this._translateX},
                {translateY: this._translateY},
              ],
            }}>
            <PinchGestureHandler
              onGestureEvent={this.onGestureEvent}
              onHandlerStateChange={this.onChangeGestureState}>
              <Animated.Image
                style={{
                  width: '100%',
                  height: '100%',
                  backgroundColor: 'black',
                  transform: [{scale: this.scale}],
                }}
                resizeMode="contain"
                source={require('../assets/SAMPLE02.jpg')}
              />
            </PinchGestureHandler>
          </Animated.View>
        </PanGestureHandler>
        <View style={{position: 'absolute', right: 20, bottom: 20}}>
          <CircleButton
            onPress={() => this.handleSaveImage()}
            size={45}
            style={{backgroundColor: 'black'}}
            invert
            Icon={() => (
              <CheckMarkGreenSVG
                onPress={() => this.handleSaveImage()}
                size={25}
              />
            )}
          />
        </View>
      </View>
    );
  }
}

export default ImageEditingScreen;

//  <PinchGestureHandler
//    onGestureEvent={this.onGestureEvent}
//    onHandlerStateChange={this.onChangeGestureState}>
//    <Animated.Image
//      style={{
//        width: '100%',
//        height: '100%',
//        backgroundColor: 'black',
//        transform: [{scale: this.scale}, {translateX: 0}],
//      }}
//      source={require('../assets/SAMPLE01.jpg')}
//    />
//  </PinchGestureHandler>;
