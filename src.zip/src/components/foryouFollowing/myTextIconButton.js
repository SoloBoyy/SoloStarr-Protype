import React, {Component} from 'react';
import {TouchableOpacity, Text, View} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
class MyTextIconButton extends Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    const size = this.props.size ? this.props.size : 35;
    const topMargin = this.props.topMargin ? this.props.topMargin : 0;
    const color = 'white';
    // const backgroundColor = 'rgba(0,0,0, 0.5)';
    const backgroundColor = 'transparent';
    // const backgroundColor = '#2A2A2A';
    const fontSize = this.props.fontSize ? this.props.fontSize : size * 0.3;
    const title = this.props.title ? this.props.title : '';
    return (
      <TouchableOpacity
        onPress={this.props.onPress ? () => this.props.onPress() : () => false}
        style={{
          width: size * 1.2,
          height: title === '' ? size : size * 1.6,
          alignItems: 'center',
          marginTop: topMargin,
        }}>
        <View
          style={{
            width: size,
            height: size,
            elevation: 0,
            backgroundColor,
            borderRadius: 50,
            justifyContent: 'center',
            alignItems: 'center',
            elevation: 0,
            borderWidth: 2,
            borderColor: backgroundColor,
          }}>
          {/* <IconFA5 name={iconName} color={color} size={size * 0.85} /> */}
          {/* <Icon color={color} size={size * 0.85} /> */}
          {React.cloneElement(this.props.children, {color, size: size * 0.6})}
        </View>
        {title !== '' ? (
          <Text
            style={{
              fontSize,
              fontWeight: 'bold',
              textShadowColor: SECONDRY_BLACK,
              textShadowRadius: 5,
              color,
            }}>
            {title}
          </Text>
        ) : (
          false
        )}
      </TouchableOpacity>
    );
  }
}
export default MyTextIconButton;
