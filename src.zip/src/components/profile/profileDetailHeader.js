import React, {Component, useRef, useState} from 'react';
import {
  View,
  Text,
  Image,
  Animated,
  Modal,
  TouchableOpacity,
} from 'react-native';

import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {navigate} from '../../navigator';
const ProfileState = ({title, value, onPress, activeOpacity}) => {
  const size = 15;
  return (
    <TouchableOpacity
      onPress={onPress ? () => onPress() : () => false}
      activeOpacity={activeOpacity}
      style={{alignItems: 'center'}}>
      <Text style={{color: 'white', fontSize: size, fontWeight: '700'}}>
        {value}
      </Text>
      <Text style={{color: 'white', fontSize: size - 5}}>{title}</Text>
    </TouchableOpacity>
  );
};

const ProfileDetailHeader = (props) => {
  let linksRef = null;
  const [linksLayout, setLinksLayout] = useState({x: 0, y: 0});
  const [linksVisible, setLinksVisible] = useState(false);

  return (
    <Animated.View
      key={0}
      onLayout={({nativeEvent}) =>
        setLinksLayout({
          x: nativeEvent.layout.x,
          y: nativeEvent.layout.y + nativeEvent.layout.height,
        })
      }
      style={[{width: '100%', height: 200}, {...props.style}]}>
      <View
        key={1}
        style={{
          width: '100%',
          height: 200,
          backgroundColor: SECONDRY_BLACK,
          flexDirection: 'row',
        }}>
        <View
          key={2}
          style={{
            width: 120,
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 10,
          }}>
          <View
            key={3}
            style={{
              flex: 1,
              width: '100%',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image
              key={4}
              style={{
                width: '90%',
                height: '95%',
                backgroundColor: '#f0f0f0',
                borderRadius: 25,
              }}
              source={require('../../assets/userimg.jpg')}
            />
          </View>
          <Text
            key={5}
            style={{
              color: 'white',
              height: 20,
              alignSelf: 'center',
              textAlign: 'center',
              fontSize: 12,
            }}>
            @chrisgullette1
          </Text>
        </View>

        <View key={6} style={{flex: 1, height: '100%'}}>
          <View key={7} style={{flex: 1}}>
            <View key={8} style={{height: 10}} />
            <View
              key={9}
              style={{
                width: '90%',
                alignSelf: 'center',
                flexDirection: 'row',
                padding: 10,
                justifyContent: 'space-around',
              }}>
              <ProfileState
                onPress={() => {
                  // props.navigation.navigate('FollowScreen', {
                  //   target: 'Followers',
                  // });
                  navigate('FollowScreen', {
                    target: 'Followers',
                  });
                }}
                key={10}
                {...{title: 'Followers', value: '127k'}}
              />
              <ProfileState
                onPress={() => {
                  navigate('FollowScreen', {
                    target: 'Followings',
                  });
                }}
                key={11}
                {...{title: 'Following', value: '127'}}
              />
              <ProfileState
                activeOpacity={1}
                key={12}
                {...{title: 'Likes', value: '3.0M'}}
              />
            </View>
            <View key={13} style={{height: 8}} />
            <View key={14} style={{width: '90%', alignSelf: 'center'}}>
              <Text
                key={15}
                style={{
                  color: 'white',
                  textAlign: 'center',
                  fontSize: 12,
                  fontWeight: 'bold',
                }}>
                Lorem ipsum, or lipsum as it is sometimes known, is dummy text
                used in laying out print.
              </Text>
            </View>
            <View key={16} style={{flex: 1}} />
            <View
              key={17}
              style={{
                width: '100%',
                height: 35,
                justifyContent: 'space-between',
                flexDirection: 'row',
              }}>
              <View key={18} style={{flex: 1}}>
                <TouchableOpacity
                  key={19}
                  style={{
                    width: '90%',
                    height: '100%',
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Text key={20} style={{color: 'white'}}>
                    Edit Profile
                  </Text>
                </TouchableOpacity>
              </View>
              <View key={21} ref={(e) => (linksRef = e)} style={{width: 50}}>
                <TouchableOpacity
                  key={22}
                  onPress={() => setLinksVisible(true)}
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 50,
                    backgroundColor: 'black',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Icon
                    onPress={() => setLinksVisible(true)}
                    key={23}
                    style={{fontSize: 23}}
                    color={WHITE_COLOR}
                    name={linksVisible ? 'times' : 'paperclip'}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </View>
      <View
        key={24}
        style={{width: '100%', height: 10, backgroundColor: SECONDRY_BLACK}}
      />
      <Modal
        key={25}
        animationType="none"
        transparent={false}
        visible={linksVisible}
        onRequestClose={() => {
          setLinksVisible(false);
        }}>
        <View
          key={26}
          activeOpacity={0}
          onPress={() => setLinksVisible(false)}
          style={{flex: 1, backgroundColor: 'rgba(0,0,0, 0.3)'}}>
          <View
            key={27}
            style={{
              width: 150,
              height: 50,
              position: 'absolute',
              top: linksLayout.y - 50,
              right: 10,
            }}>
            <Text
              key={28}
              style={{
                width: '100%',
                height: '100%',
              }}
              onPress={() => setLinksVisible(false)}>{`  `}</Text>
          </View>
          <View
            key={29}
            style={{
              height: 150,
              width: 40,
              position: 'absolute',
              top: linksLayout.y + 5,
              right: 12,
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              key={30}
              style={{
                width: 35,
                height: 35,
                borderRadius: 50,
                backgroundColor: 'black',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Icon
                key={31}
                style={{fontSize: 23}}
                color={WHITE_COLOR}
                name="instagram"
              />
            </TouchableOpacity>
            <TouchableOpacity
              key={32}
              style={{
                width: 35,
                height: 35,
                borderRadius: 50,
                backgroundColor: 'black',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Icon
                key={33}
                style={{fontSize: 23}}
                color={WHITE_COLOR}
                name="snapchat"
              />
            </TouchableOpacity>
            <TouchableOpacity
              key={34}
              style={{
                width: 35,
                height: 35,
                borderRadius: 50,
                backgroundColor: 'black',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Icon
                key={35}
                style={{fontSize: 23}}
                color={WHITE_COLOR}
                name="youtube"
              />
            </TouchableOpacity>
            <TouchableOpacity
              key={36}
              style={{
                width: 35,
                height: 35,
                borderRadius: 50,
                backgroundColor: 'black',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Icon
                key={37}
                style={{
                  fontSize: 23,
                  transform: [{rotateZ: '45deg'}, {scaleX: 0.7}],
                }}
                color={WHITE_COLOR}
                name="thumbtack"
              />
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </Animated.View>
  );
};

export default ProfileDetailHeader;
