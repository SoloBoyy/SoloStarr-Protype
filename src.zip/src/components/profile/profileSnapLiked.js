import React, {useState} from 'react';
import {View, Text, FlatList} from 'react-native';
import SingleSnap from './singleSnap';

const ProfileSnapLiked = (props) => {
  const [liked, setliked] = useState([
    {_id: 1, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 2, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 3, imageSource: require('../../assets/dummy03.jpg')},
    {_id: 4, imageSource: require('../../assets/dummy01.jpg')},
    {_id: 5, imageSource: require('../../assets/dummy02.jpg')},
    {_id: 6, imageSource: require('../../assets/dummy03.jpg')},
  ]);
  return (
    <View style={{width: '100%'}}>
      <View style={{width: '100%', marginTop: 10}}>
        <Text
          style={{
            color: 'white',
            fontSize: 18,
            marginLeft: 20,
          }}>
          {props.title ? props.title : 'Series'}
        </Text>
      </View>
      <View style={{width: '100%'}}>
        <FlatList
          numColumns={3}
          showsHorizontalScrollIndicator={false}
          data={liked}
          renderItem={({item, index}) => (
            <SingleSnap {...{imageSource: item.imageSource}} />
          )}
          keyExtractor={(item) =>
            `${Math.round(Math.random() * 10000)}${item._id}`
          }
        />
      </View>
    </View>
  );
};

export default ProfileSnapLiked;
