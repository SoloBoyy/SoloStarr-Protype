import React, {useState} from 'react';
import {View, Text} from 'react-native';
import {WHITE_COLOR} from '../../../themes/colors';
import SingleComment from './singleComment';
import Icon from 'react-native-vector-icons/FontAwesome5';
const comment = {
  text: '',
  likes: 215,
};

const CommentItem = (props) => {
  const [expanded, setExpanded] = useState(false);
  const isPreview = props.isPreview ? true : false;
  const [singleCommentItem, setSingleCommentItem] = useState({
    user: {
      username: 'atamuhiuldin',
      avatar: '',
    },
    age: '21d',
    comment,
    replies: [comment, comment, comment],
  });
  if (!isPreview) {
    return (
      <View style={{width: '100%', minHeight: 100}}>
        <SingleComment
          commentItem={props.commentItem}
          onShowReplyBox={props.onShowReplyBox}
          onToggleExpand={() => setExpanded(!expanded)}
          expanded={expanded}
          repliesCount={3}
        />
        {expanded ? (
          <View style={{backgroundColor: '#222222', borderRadius: 5}}>
            <SingleComment commentItem={props.commentItem} isReply />
            <SingleComment commentItem={props.commentItem} isReply />
            <SingleComment commentItem={props.commentItem} isReply />
          </View>
        ) : (
          false
        )}
      </View>
    );
  } else {
    return (
      <View style={{width: '100%', minHeight: 70}}>
        <Icon
          onPress={props.onCloseReplyBox}
          style={{
            alignSelf: 'flex-end',
            padding: 10,
            marginBottom: -20,
          }}
          name="times"
          color={WHITE_COLOR}
        />
        <SingleComment
          onToggleExpand={() => setExpanded(!expanded)}
          expanded={expanded}
          isPreview={isPreview}
          repliesCount={3}
        />
      </View>
    );
  }
};
export default CommentItem;
