import React, {useEffect, useRef} from 'react';
import {View, Text} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import MyTabBar from '../profile/myTabBar';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import TrandingTabPage from './trandingTabPage';
import PopularTabPage from './popularTabPage';
import TravelTabPage from './travelTabPage';
const Tab = createMaterialTopTabNavigator();

const LandingContent = (props) => {
  const tabRef = useRef();
  useEffect(() => {}, []);
  return (
    <View style={{flex: 1, backgroundColor: '#f7f7f7'}}>
      <Tab.Navigator
        ref={tabRef}
        sceneContainerStyle={{backgroundColor: SECONDRY_BLACK}}
        style={{backgroundColor: SECONDRY_BLACK}}
        tabBar={(props) => (
          <MyTabBar
            {...props}
            onChange={(value) => {
              console.log(value);
            }}
          />
        )}>
        <Tab.Screen name="Tranding" component={TrandingTabPage} />
        <Tab.Screen initialParams name="Popular" component={PopularTabPage} />
        <Tab.Screen name="Travel" component={TravelTabPage} />
      </Tab.Navigator>
    </View>
  );
};
export default LandingContent;
