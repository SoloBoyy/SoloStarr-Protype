// import RNFS from 'react-native-fs';
// import {RNFFmpeg} from 'react-native-ffmpeg';
// class VideoProcessingControllerFFmpeg {
//   constructor() {
//     this.OUTPUT_URL = '';
//     this.AVG_FRAME_RATE = 12;

//     this.setAvgFrameRate = (fr) => {
//       this.AVG_FRAME_RATE = fr;
//     };
//     this.executeFFmpegCmd = (command) => {
//       return new Promise((resolve, reject) => {
//         // console.log('>>>>>RECORD TEST02-1: PREPARE VIDEO START');
//         RNFFmpeg.execute(command)
//           .then((result) => {
//             // console.log(
//             //   '==================================================RESULT====================================',
//             // );
//             // console.log(result);
//             // console.log('==================================SUPPOSED URL');
//             //   console.log(this.OUTPUTPATH);
//             let outputPath = this.OUTPUT_URL;
//             this.OUTPUT_URL = '';
//             resolve(outputPath);
//           })
//           .catch((err) => {
//             console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>CATCH ERROR IN PROCESSING');
//             console.log(err);
//             reject(err);
//           });
//       });
//     };

//     this.executeMultipleCommands = (commands) => {
//       return new Promise(async (resolve, reject) => {
//         const outputs = [];
//         try {
//           for (let index = 0; index < commands.length; index++) {
//             const cmd = commands[index];
//             let output = await this.executeFFmpegCmd(cmd);
//             /// Dispatch and update.
//             outputs.push(output);
//           }
//           resolve(outputs);
//         } catch (error) {
//           reject(error);
//         }
//       });
//     };

//     this.prepareCasheOUTPUT = (outputUrl = null) => {
//       if (outputUrl === null) {
//         this.OUTPUT_URL = `file://${RNFS.DownloadDirectoryPath}/TK_${Math.round(
//           Math.random() * Math.random() * 10000000000,
//         )}${Math.round(Math.random() * Math.random() * 10000000000)}.mp4`;
//       } else {
//         this.OUTPUT_URL = outputUrl;
//       }
//       // console.log('PREPARED OUTPUT');
//       // console.log(this.OUTPUT_URL);
//       return this;
//     };

//     this.generateVideoSpeedControllerCommand = (inputUri, videoSpeed) => {
//       const command = `-i ${inputUri}  -q 5 -filter:v "setpts=PTS/${videoSpeed}" -filter:a "atempo=${videoSpeed}"  -f mp4 ${this.OUTPUT_URL}`;
//       // const command1 = `-itsscale 3 -i ${inputUri} -c copy ${this.OUTPUT_URL}`;
//       // const command2 = `-i ${inputUri} -filter:v "setpts=0.5*PTS" ${this.OUTPUT_URL}`;
//       // const command1 = `-i ${inputUri} -filter_complex "[0:v]setpts=2*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]"  ${this.OUTPUT_URL}`;
//       return command;
//     };

//     this.generateConvertionCommand = (input) => {
//       const command = `-i ${input} -c:v mpeg4 ${this.OUTPUT_URL}`;
//       return command;
//     };
//     // -profile:v 15
//     this.generateConcatinateCommand = (recordings) => {
//       // let command = '';
//       let output = ` -map "[outv]" -map "[outa]" -time_base 1/30  ${this.OUTPUT_URL}`;

//       //// Preparing inputs
//       let inputs = '';
//       let complexFilters = '';
//       for (let index = 0; index < recordings.length; index++) {
//         const source = recordings[index];
//         inputs = `${inputs} -i ${source}`;
//         // complexFilters = `${complexFilters}[${index}]`;
//         complexFilters = `${complexFilters}[${index}:v:0] [${index}:a:0]`;
//       }

//       let complexFilterCMD = ` -q 5 -filter_complex "${complexFilters}concat=n=${recordings.length}:v=1:a=1[outv][outa]"`;

//       console.log('>>>>>RECORD TEST01-2: PREPARED COMMAND');
//       const preparedCommand = `${inputs}${complexFilterCMD}${output}`;
//       console.log(preparedCommand);
//       return preparedCommand;
//     };
//   }
// }
// const MyVideoProcessingControllerFFmpeg = new VideoProcessingControllerFFmpeg();
// export default MyVideoProcessingControllerFFmpeg;
