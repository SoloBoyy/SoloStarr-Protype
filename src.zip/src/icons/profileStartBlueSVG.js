import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const ProfileStarBlueSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="29" height="29" viewBox="0 0 29 29">
  <path id="Polygon_1" data-name="Polygon 1" d="M18.385,0,20.3,4.454l4.815-.569L24.546,8.7,29,10.615,26.1,14.5,29,18.385,24.546,20.3l.569,4.815L20.3,24.546,18.385,29,14.5,26.1,10.615,29,8.7,24.546l-4.815.569L4.454,20.3,0,18.385,2.9,14.5,0,10.615,4.454,8.7,3.885,3.885,8.7,4.454,10.615,0,14.5,2.9Z" fill="#0dc6ff"/>
</svg>
`}
    />
  );
};
export default ProfileStarBlueSVG;
