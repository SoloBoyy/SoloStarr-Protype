import React, {useEffect, useState} from 'react';
import {View, Text, FlatList} from 'react-native';
import {useSelector} from 'react-redux';
import ActivityTypeItem, {
  COMMENTED,
  LIKED,
  MENSIONED,
  FOLLOWED,
} from './activityTypeItem';
import InboxChatItem from './inboxChatItem';
import InboxSearchBox from './inboxSearchBox';

const ActivityTabPage = (props) => {
  const [isSearchModeEnabled, setSearchMode] = useState(false);
  const [displayActivities, setDisplayActivities] = useState([]);
  const activities = useSelector((store) => store.ActivityReducer.activities);
  const typeFilter = useSelector((store) => store.ActivityReducer.typeFilter);

  useEffect(() => {
    if (typeFilter === '') {
      setDisplayActivities(activities);
    } else {
      let act = activities.filter((a) => a.type === typeFilter);
      setDisplayActivities(act);
    }
  }, [typeFilter, activities]);

  return (
    <View style={{flex: 1}}>
      <View style={{width: '90%', alignSelf: 'center'}}>
        <InboxSearchBox
          isSearchMode={isSearchModeEnabled}
          onChangeMode={(value) => setSearchMode(value)}
        />
        <FlatList
          data={displayActivities}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => {
            if (item.type === 'd') {
              return (
                <View
                  style={{
                    width: '100%',
                    height: 40,
                  }}>
                  <Text
                    style={{fontSize: 20, fontWeight: 'bold', color: 'white'}}>
                    {item.username}
                  </Text>
                </View>
              );
            } else {
              return <ActivityTypeItem {...{type: item.type}} />;
            }
          }}
          keyExtractor={(item) => `${item._id}${item.username}`}
        />

        {/* <ActivityTypeItem {...{type: COMMENTED}} />
        <ActivityTypeItem {...{type: MENSIONED}} />
        <ActivityTypeItem {...{type: FOLLOWED}} />
        <ActivityTypeItem {...{type: COMMENTED}} /> */}
      </View>
    </View>
  );
};
export default ActivityTabPage;
