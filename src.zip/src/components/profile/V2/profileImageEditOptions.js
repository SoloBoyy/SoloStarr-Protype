import React from 'react';

import {View, Text, TouchableOpacity, Modal} from 'react-native';
import Popover, {PopoverPlacement} from 'react-native-popover-view';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {navigate} from '../../../navigator';
import {WHITE_COLOR} from '../../../themes/colors';
const ProfileImageEditOptions = (props) => {
  return (
    <Popover
      backgroundStyle={{backgroundColor: 'transparent'}}
      popoverStyle={{
        height: 200,
        width: 200,
        backgroundColor: 'transparent',
        marginLeft: -13,
      }}
      placement={PopoverPlacement.BOTTOM}
      from={props.from}
      key={25}
      isVisible={props.visible ? true : false}
      onRequestClose={() => {
        if (props.setVisible) {
          props.setVisible(false);
        }
      }}>
      <View
        key={29}
        style={{
          height: 150,
          width: '100%',
        }}>
        <TouchableOpacity
          onPress={() => false}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 5,
            width: '100%',
            justifyContent: 'flex-end',
          }}>
          <Text style={{color: 'white'}}>Change Picture </Text>
          <View
            key={30}
            style={{
              width: 35,
              height: 35,
              borderRadius: 50,
              backgroundColor: 'white',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={props.onReframePicture}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 5,
            width: '100%',
            justifyContent: 'flex-end',
          }}>
          <Text style={{color: 'white'}}>Reframe Picture </Text>
          <View
            key={30}
            style={{
              width: 35,
              height: 35,
              borderRadius: 50,
              backgroundColor: 'white',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={props.onProfileReframe}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 5,
            width: '100%',
            justifyContent: 'flex-end',
          }}>
          <Text style={{color: 'white'}}>Profile Picture reframe </Text>
          <View
            key={30}
            style={{
              width: 35,
              height: 35,
              borderRadius: 50,
              backgroundColor: 'white',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          />
        </TouchableOpacity>
      </View>
    </Popover>
  );
};

export default ProfileImageEditOptions;
