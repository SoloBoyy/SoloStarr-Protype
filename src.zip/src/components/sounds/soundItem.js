import React, {Component} from 'react';
import {StyleSheet, View, Image, Text, TouchableOpacity} from 'react-native';
import {DARK_GRAY, SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import SoundSVG from './Images/soundImage';
import AddIconSVG from './Icons/addIcon';
import SavedIconSVG from './Icons/savedIcon';
import SavedFilledIconSVG from './Icons/savedFilledIcon';

export default class SoundItemComponent extends Component {
  state = {
    isSaved: false,
  };
  toggleSave = () => {
    this.setState({isSaved: !this.state.isSaved});
  };
  componentDidMount() {
    this.setState({isSaved: this.props.isSaved});
  }
  render() {
    const {
      songName,
      songDescription,
      onPressItem,
      onPressSave,
      onPressAdd,
      isSaved,
    } = this.props;
    return (
      <TouchableOpacity onPress={onPressItem} style={styles.container}>
        <View style={styles.flexStyle}>
          <SoundSVG />
        </View>
        <View style={[styles.flexStyle, {flex: 2.5}]}>
          <Text numberOfLines={1} style={{color: WHITE_COLOR}}>
            {songName}
          </Text>
          <Text numberOfLines={1} style={{color: DARK_GRAY}}>
            {songDescription}
          </Text>
        </View>
        <View style={[styles.flexStyle, {alignItems: 'flex-end', flex: 0.5}]}>
          <TouchableOpacity onPress={this.toggleSave}>
            {this.state.isSaved ? <SavedFilledIconSVG /> : <SavedIconSVG />}
          </TouchableOpacity>
        </View>
        <View style={[styles.flexStyle, {alignItems: 'flex-end', flex: 0.5}]}>
          <TouchableOpacity onPress={onPressAdd}>
            <AddIconSVG />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    height: 70,
    width: '85%',
    alignSelf: 'center',
    backgroundColor: SECONDRY_BLACK,
    flexDirection: 'row',
  },
  flexStyle: {flex: 1, justifyContent: 'center', alignItems: 'flex-start'},
});
