import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const SoundSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="17.601" height="30.238" viewBox="0 0 17.601 30.238">
  <path id="Icon_ionic-ios-musical-note" data-name="Icon ionic-ios-musical-note" d="M25.615,3.389c-.33.063-8.3,1.695-8.592,1.751a.623.623,0,0,0-.57.563h0V23.639a1.939,1.939,0,0,1-.169.823,1.874,1.874,0,0,1-1.132.893c-.232.077-.548.148-.921.232-1.695.38-4.528,1.027-4.528,3.642a3.262,3.262,0,0,0,2.461,3.312,5.282,5.282,0,0,0,.97.07,8.322,8.322,0,0,0,3.6-.928,3.788,3.788,0,0,0,1.695-3.361V12.171a.558.558,0,0,1,.45-.548L25.4,10.287a1.129,1.129,0,0,0,.9-1.1V3.923A.556.556,0,0,0,25.615,3.389Z" transform="translate(-9.203 -2.873)" fill="#f0f0f0" stroke="#f0f0f0" stroke-width="1"/>
</svg>
`}
    />
  );
};
export default SoundSVG;
