import React, {Component} from 'react';
import {View, Text, StatusBar} from 'react-native';
import {SECONDRY_BLACK} from '../themes/colors';
import SearchAllBox from '../components/search/searchAllBox';
import SearchContent from '../components/search/searchContent';
import LandingContent from '../components/search/landingContent';
class SearchScreen extends Component {
  state = {
    isSearchModeEnabled: false,
  };
  render() {
    return (
      <View style={{flex: 1, backgroundColor: SECONDRY_BLACK}}>
        <StatusBar
          hidden={false}
          barStyle="light-content"
          backgroundColor={SECONDRY_BLACK}
        />
        <SearchAllBox
          onChangeMode={(value) => this.setState({isSearchModeEnabled: value})}
          isSearchMode={this.state.isSearchModeEnabled}
        />
        <View style={{flex: 1}}>
          {this.state.isSearchModeEnabled ? (
            <SearchContent />
          ) : (
            <LandingContent />
          )}
        </View>
      </View>
    );
  }
}

export default SearchScreen;
