import React, {Component} from 'react';
import {StyleSheet, View, Image, Text, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from './themes/colors';
import {LARGE} from './themes/fonts';
import ArrowBackIcon from './Icons/arrowBackIcon';
import UploadIcon from './Icons/uploadIcon';
import SearchBarComponent from './searchbar';

export default class HeaderComponent extends Component {
  render() {
    const {
      onPressBack,
      onPressUpload,
      onPressCancel,
      isSearchEnabled,
    } = this.props;

    if (isSearchEnabled === true) {
      return (
        <View style={styles.container}>
          <View style={[styles.flexStyle, {flex: 3, marginLeft: 20}]}>
            <SearchBarComponent />
          </View>
          <View style={styles.flexStyle}>
            <TouchableOpacity onPress={onPressCancel}>
              <Text style={{color: WHITE_COLOR}}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return (
        <View style={styles.container}>
          <View style={styles.flexStyle}>
            <TouchableOpacity onPress={onPressBack}>
              <ArrowBackIcon />
            </TouchableOpacity>
          </View>

          <View style={[styles.flexStyle, {flex: 3}]}>
            <SearchBarComponent />
          </View>
          <View style={styles.flexStyle}>
            <TouchableOpacity onPress={onPressUpload}>
              <UploadIcon />
            </TouchableOpacity>
          </View>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    backgroundColor: SECONDRY_BLACK,
  },
  flexStyle: {flex: 1, justifyContent: 'center', alignItems: 'center'},
  headerTextStyle: {
    fontSize: LARGE,
    color: WHITE_COLOR,
  },
});
