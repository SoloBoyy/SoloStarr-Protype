import React, {useState} from 'react';
import {View, Text, FlatList} from 'react-native';
import {useSelector} from 'react-redux';
import InboxChatItem from './inboxChatItem';
import InboxSearchBox from './inboxSearchBox';
const MessagesTabPage = (props) => {
  const [isSearchModeEnabled, setSearchMode] = useState(false);
  const chat = useSelector((store) => store.InboxReducer.chat);
  return (
    <View style={{flex: 1}}>
      <View style={{width: '90%', alignSelf: 'center'}}>
        <InboxSearchBox
          isSearchMode={isSearchModeEnabled}
          onChangeMode={(value) => setSearchMode(value)}
        />

        <FlatList
          data={chat}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => (
            <InboxChatItem
              {...{
                singleChat: item,
                onPress: () => {
                  props.navigation.push('ChatScreen', {chatId: item._id});
                },
              }}
            />
          )}
          keyExtractor={(item) => item._id}
        />
      </View>
    </View>
  );
};
export default MessagesTabPage;
