import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity, ScrollView} from 'react-native';
import {
  PRIMARY_RED,
  SECONDRY_BLACK,
  WHITE_COLOR,
  GRAY_COLOR,
} from '../../../themes/colors';

const OptionSelect = (props) => {
  const option = props.option
    ? props.option
    : {_id: '1', title: '', selected: false};
  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={() => {
        if (props.onSelect) {
          props.onSelect(option);
        }
      }}
      style={{
        width: 50,
        height: 35,
        borderRadius: 3,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: option.selected ? WHITE_COLOR : 'transparent',
        margin: 2,
      }}>
      <Text style={{color: option.selected ? SECONDRY_BLACK : GRAY_COLOR}}>
        {option.title}
      </Text>
    </TouchableOpacity>
  );
};

const BarSelect = (props) => {
  const [options, setOptions] = useState(props.options ? props.options : []);
  const [selectedValue, setSelectedValue] = useState(
    props.selectedValue !== undefined ? props.selectedValue : 1,
  );
  useEffect(() => {
    // const selectedIndex = options.findIndex((o) => o.value === selectedValue);
    // console.log(`UPDATING CMP, VALUE: ${selectedValue}`);
    let opts = [...options];
    for (let index = 0; index < opts.length; index++) {
      const o = opts[index];
      if (o.value === selectedValue) {
        opts[index].selected = true;
      } else {
        opts[index].selected = false;
      }
    }
    setOptions(opts);
  }, []);

  const onSelectOption = (value) => {
    if (props.onSelect) {
      props.onSelect(value);
    }
    let opts = [...options];
    for (let index = 0; index < opts.length; index++) {
      const o = opts[index];
      if (o._id === value._id) {
        opts[index].selected = true;
      } else {
        opts[index].selected = false;
      }
    }
    setOptions(opts);
  };

  return (
    <View style={{height: 40, justifyContent: 'center', alignItems: 'center'}}>
      <ScrollView
        style={{
          backgroundColor: 'transparent',
          flex: 1,
        }}
        horizontal>
        {options.map((o) => (
          <OptionSelect key={o._id} option={o} onSelect={onSelectOption} />
        ))}
      </ScrollView>
    </View>
  );
};
export default BarSelect;
