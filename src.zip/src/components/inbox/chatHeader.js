import React, {Component} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import InfoWhiteSVG from '../../icons/infoWhiteSVG';
import {GRAY_COLOR} from '../../themes/colors';
const ChatHeader = (props) => {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={() => (props.onPress ? props.onPress() : false)}
      style={{
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingLeft: 10,
        paddingRight: 10,
      }}>
      <Image
        style={{
          width: 40,
          height: 40,
          borderRadius: 50,
          backgroundColor: GRAY_COLOR,
        }}
      />
      <View
        style={{
          alignItems: 'center',
          paddingRight: 20,
          paddingLeft: 20,
          justifyContent: 'center',
        }}>
        <Text style={{color: 'white'}}>{props.title}</Text>
      </View>
      <View style={{width: 25, height: 25}}>
        <InfoWhiteSVG style={{marginTop: 3}} />
      </View>
    </TouchableOpacity>
  );
};
export default ChatHeader;
