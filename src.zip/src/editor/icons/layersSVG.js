import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const LayerSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="29.5" height="34" viewBox="0 0 29.5 34">
  <path id="Icon_material-content-copy" data-name="Icon material-content-copy" d="M24,1.5H6a3.009,3.009,0,0,0-3,3v21H6V4.5H24Zm4.5,6H12a3.009,3.009,0,0,0-3,3v21a3.009,3.009,0,0,0,3,3H28.5a3.009,3.009,0,0,0,3-3v-21A3.009,3.009,0,0,0,28.5,7.5Zm0,24H12v-21H28.5Z" transform="translate(-2.5 -1)" fill="#f0f0f0" stroke="#f0f0f0" stroke-width="1"/>
</svg>
`}
    />
  );
};
export default LayerSVG;
