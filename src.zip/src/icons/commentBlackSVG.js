import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const CommentBlackSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="28" height="14" viewBox="0 0 28 14">
  <defs>
    <clipPath id="clip-path">
      <rect width="18" height="4" fill="none"/>
    </clipPath>
  </defs>
  <g id="Group_625" data-name="Group 625" transform="translate(-239 -11)">
    <rect fill="#111111" id="Rectangle_626" data-name="Rectangle 626" width="28" height="14" rx="7" transform="translate(239 11)"/>
    <g id="Repeat_Grid_4" data-name="Repeat Grid 4" transform="translate(244 16)" clip-path="url(#clip-path)">
      <g transform="translate(-245 -16)">
        <circle id="Ellipse_80" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)" fill="#fff"/>
      </g>
      <g transform="translate(-238 -16)">
        <circle id="Ellipse_80-2" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)" fill="#fff"/>
      </g>
      <g transform="translate(-231 -16)">
        <circle id="Ellipse_80-3" data-name="Ellipse 80" cx="2" cy="2" r="2" transform="translate(245 16)" fill="#fff"/>
      </g>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default CommentBlackSVG;
