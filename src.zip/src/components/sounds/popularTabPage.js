import React, {Component} from 'react';
import {StyleSheet, View, FlatList, Dimensions, ScrollView} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import SoundItemComponent from './soundItem';
import SoundTextComponent from './soundText';
import SoundsGroupItems from './soundsGroupItems';
import ViewPager from '@react-native-community/viewpager';

const screenHeight = Math.round(Dimensions.get('window').height);

class PopularTabPage extends Component {
  state = {
    sounds: [
      {id: 1, songName: 'Song Name', songDescription: 'Description'},
      {id: 2, songName: 'Song Name', songDescription: 'Description'},
      {id: 3, songName: 'Song Name', songDescription: 'Description'},
      {id: 4, songName: 'Song Name', songDescription: 'Description'},
    ],
    trending: [
      {id: 1, songName: 'Song Name', songDescription: 'Description'},
      {id: 2, songName: 'Song Name', songDescription: 'Description'},
      {id: 3, songName: 'Song Name', songDescription: 'Description'},
      {id: 4, songName: 'Song Name', songDescription: 'Description'},
    ],
  };
  render() {
    return (
      <View style={styles.container}>
        <ScrollView>
          <SoundTextComponent text={'Sounds'} />
          <ViewPager
            orientation="horizontal"
            style={{height: 280}}
            initialPage={0}>
            <SoundsGroupItems key="0" />
            <SoundsGroupItems key="1" />
            <SoundsGroupItems key="3" />
            <SoundsGroupItems key="4" />
          </ViewPager>

          <View style={{height: screenHeight / 2}}>
            <SoundTextComponent text={'Trending'} />
            <ViewPager
              orientation="horizontal"
              style={{height: 280}}
              initialPage={0}>
              <SoundsGroupItems key="0" />
              <SoundsGroupItems key="1" />
              <SoundsGroupItems key="3" />
              <SoundsGroupItems key="4" />
            </ViewPager>
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default PopularTabPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: SECONDRY_BLACK,
  },
});
