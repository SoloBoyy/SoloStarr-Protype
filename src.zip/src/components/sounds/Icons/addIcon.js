import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const AddSvg = props => {
  const size = props.size ? props.size : 18;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="20.25" height="20.25" viewBox="0 0 20.25 20.25">
      <path id="Icon_ionic-ios-add" data-name="Icon ionic-ios-add" d="M27.954,17.829h-7.6v-7.6a1.261,1.261,0,0,0-2.521,0v7.6h-7.6a1.261,1.261,0,0,0,0,2.521h7.6v7.6a1.261,1.261,0,1,0,2.521,0v-7.6h7.6a1.261,1.261,0,1,0,0-2.521Z" transform="translate(-8.965 -8.965)" fill="#fff"/>
    </svg>   
`}
    />
  );
};
export default AddSvg;
