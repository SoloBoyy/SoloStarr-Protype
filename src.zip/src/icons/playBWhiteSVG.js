import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const PlayBWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="30" viewBox="0 0 24 30">
  <path id="Icon_feather-play" data-name="Icon feather-play" d="M7.5,4.5,28.5,18,7.5,31.5Z" transform="translate(-6 -3)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
</svg>
`}
    />
  );
};
export default PlayBWhiteSVG;
