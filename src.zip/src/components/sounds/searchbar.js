import React, {Component} from 'react';
import {StyleSheet, View, TextInput, Image} from 'react-native';
import {DARK_GRAY, WHITE_COLOR} from '../../themes/colors';
import SearchIcon from './Icons/searchIcon';
class SearchBarComponent extends Component {
  render() {
    return (
      <View
        style={[
          styles.viewStyle,
          {
            height: 40,
            width: this.props.width ? this.props.width : '100%',
          },
        ]}>
        <View style={[styles.flexStyle, {alignItems: 'center'}]}>
          <SearchIcon />
        </View>
        <View style={[styles.flexStyle, {flex: 4}]}>
          <TextInput
            placeholder={'Search'}
            placeholderTextColor={WHITE_COLOR}
            style={styles.textInputStyle}
          />
        </View>
      </View>
    );
  }
}

export default SearchBarComponent;

const styles = StyleSheet.create({
  viewStyle: {
    alignSelf: 'center',
    flexDirection: 'row',
    backgroundColor: DARK_GRAY,
    borderRadius: 5,
  },
  textInputStyle: {
    height: 45,
    width: '100%',
    color: WHITE_COLOR,
  },

  flexStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
});
