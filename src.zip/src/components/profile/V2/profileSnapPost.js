import React, {useRef, useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import CommentWhiteSVG from '../../../icons/commentWhiteSVG';
import PauseWhiteSVG from '../../../icons/pauseWhiteSVG';
import HeartBWhiteSVG from '../../../icons/heartBWhiteSVG';
import PlayBWhiteSVG from '../../../icons/playBWhiteSVG';
import ShareWhiteSVG from '../../../icons/shareWhiteSVG';
import {navigate} from '../../../navigator';
import MyTextIconButtonProfile from './myTextIconButtonProfile';
import Video from 'react-native-video';
import {WHITE_COLOR} from '../../../themes/colors';
import LikedRedSVG from '../../../icons/likedRedSVG';
const ProfileSnapPost = (props) => {
  const cmpRef = useRef();
  const [isPaused, setIsPaused] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isMute, setIsMute] = useState(true);
  const index = props.index !== undefined ? props.index : 0;
  let isColTwo = index % 2 === 1;

  return (
    <TouchableOpacity
      activeOpacity={1}
      onLongPress={() => {
        // console.log('Measuring...');
        // cmpRef.current.measure((x, y, width, height, pageX, pageY) => {
        //   console.log(
        //     `\n>X: ${x}, Y: ${y} \n>WIDTH: ${width}, HEIGHT: ${height} \n>PAGE-X: ${pageX}, PAGE-Y: ${pageY}`,
        //   );
        // props.onHover({top: pageY, left: pageX, value: props.value});
        // });
      }}
      ref={cmpRef}
      style={{
        width: '50%',
        transform: [{translateY: isColTwo ? 25 : -10}],
        height: props.height ? props.height : 290,
      }}>
      <TouchableOpacity
        onPress={() => navigate('BoostCoinPermissionScreen')}
        style={{
          position: 'absolute',
          zIndex: 999,
          backgroundColor: 'white',
          width: 25,
          height: 25,
          borderRadius: 50,
          alignSelf: 'flex-end',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Text style={{fontSize: 25, marginTop: -3}}>+</Text>
      </TouchableOpacity>
      <View style={{flex: 1, width: '85%', alignSelf: 'center'}}>
        <Video
          muted={isMute}
          onReadyForDisplay={() => {
            if (props.item.isLoaded === false) {
              setTimeout(() => setIsPaused(true), 50);
              props.onLoad(props.index);
            }
          }}
          resizeMode="cover"
          source={props.item.imageSource}
          paused={isPaused}
          style={{
            flex: 1,
            width: '100%',
            borderRadius: 30,
            backgroundColor: 'gray',
          }}
        />
        {/* <Image
          source={props.item.imageSource}
          style={{
            flex: 1,
            width: '100%',
            borderRadius: 30,
            backgroundColor: 'white',
          }}
        /> */}
        <View
          style={{
            height: 60,
            marginRight: 1,
            flexDirection: 'row',
            justifyContent: 'space-evenly',
            alignItems: 'flex-start',
            paddingTop: 3,
            zIndex: 999,
          }}>
          <MyTextIconButtonProfile
            onPress={() => setIsLiked(!isLiked)}
            title="Liked">
            {isLiked ? <LikedRedSVG /> : <HeartBWhiteSVG />}
          </MyTextIconButtonProfile>
          <MyTextIconButtonProfile
            onPress={() => {
              setIsPaused(!isPaused);
              setIsMute(false);
            }}
            title={!isPaused ? 'Pause' : 'Play'}>
            {!isPaused ? <PauseWhiteSVG size={16} /> : <PlayBWhiteSVG />}
          </MyTextIconButtonProfile>
          <MyTextIconButtonProfile title="Comment">
            <CommentWhiteSVG />
          </MyTextIconButtonProfile>
          <MyTextIconButtonProfile title="Share">
            <ShareWhiteSVG />
          </MyTextIconButtonProfile>
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default ProfileSnapPost;
