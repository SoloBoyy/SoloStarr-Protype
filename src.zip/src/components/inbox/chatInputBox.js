import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import {GRAY_COLOR, WHITE_COLOR} from '../../themes/colors';
import GallaryWhiteSVG from '../../icons/gallaryWhiteSVG';
import FeatherSendWhiteSVG from '../../icons/featherSendWhiteSVG';
import CameraBlackSVG from '../../icons/cameraBlackSVG';
import UploadBlackSVG from '../../icons/uploadBlackSVG';
import OverlayModal from './overlayModal';
import CircleButton from './circleButton';
import MyInboxController from '../../controllers/inboxController';
const ChatInputBox = (props) => {
  const textInputRef = useRef();
  const [controlsVisible, setControlsVisible] = useState(false);
  const [value, setValue] = useState('');
  const [sendingMode, setSendingMode] = useState(false);
  const msgValue = props.value ? props.value : false;

  useEffect(() => {
    if (props.value) {
      if (props.value === '') {
        setSendingMode(false);
      } else {
        setSendingMode(true);
      }
    } else {
      if (value === '') {
        setSendingMode(false);
      } else {
        setSendingMode(true);
      }
    }
  }, [props.value, value]);
  return (
    <View
      style={{
        width: '100%',
        height: 50,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <View
        style={{
          flex: 1,
          height: 35,
          backgroundColor: 'black',
          flexDirection: 'row',
          alignItems: 'center',
          borderRadius: 50,
          paddingLeft: 15,
          paddingRight: 5,
          ...props.style,
        }}>
        <TextInput
          ref={textInputRef}
          placeholderTextColor={'gray'}
          placeholder="Type here..."
          value={msgValue ? msgValue : value}
          onChangeText={(text) =>
            props.onChangeText ? props.onChangeText(text) : setValue(text)
          }
          onFocus={() =>
            props.onChangeMode ? props.onChangeMode(true) : false
          }
          style={{flex: 1, color: 'white', marginBottom: -3}}
        />
        <TouchableOpacity
          onPress={() => {
            if (!sendingMode) {
              textInputRef.current.blur();
              setControlsVisible(true);
            } else {
              if (props.onSubmit) {
                props.onSubmit();
              }
            }
          }}
          activeOpacity={1}
          style={{
            width: 60,
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          {!sendingMode ? <GallaryWhiteSVG /> : <FeatherSendWhiteSVG />}
        </TouchableOpacity>
      </View>
      <OverlayModal
        setVisible={(value) => setControlsVisible(value)}
        {...{visible: controlsVisible}}>
        <View
          style={{
            width: 40,
            position: 'absolute',
            bottom: 5,
            right: 10,
          }}>
          <CircleButton
            size={30}
            Icon={(props) => <CameraBlackSVG size={18} />}
          />
          <CircleButton
            size={30}
            Icon={(props) => <UploadBlackSVG size={15} />}
          />
          <TouchableOpacity
            onPress={() => setControlsVisible(false)}
            style={{width: 100, height: 40}}></TouchableOpacity>
        </View>
      </OverlayModal>
    </View>
  );
};
export default ChatInputBox;
