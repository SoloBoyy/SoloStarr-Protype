import {
  COMMENT_SET_VISIBLE,
  COMMENT_TOGGLE_LIKE,
  PUSH_NEW_COMMENT,
  SET_FORYOU_LAYOUT_KEY_VALUE,
  STORY_TOGGLE_LIKE,
  SET_PROFILE_KEY_VALUE_FORYOU,
} from '../../controllers/types';
import {produce} from 'immer';

const state = {
  stories: [
    {
      _id: 0,
      title: 'abc0',
      source: {
        uri:
          'https://tiktokvideos-niofox.s3.amazonaws.com/WhatsApp+Video+2020-11-11+at+10.15.51+AM+(1).mp4',
      },
      bgColor: '#CE4760',
      liked: false,
      commentsVisible: false,
      comments: [],
    },
    {
      _id: 1,
      title: 'abc1',
      bgColor: '#283F3B',
      source: {
        uri:
          'https://tiktokvideos-niofox.s3.amazonaws.com/WhatsApp+Video+2020-11-11+at+10.15.51+AM+(2).mp4',
      },
      liked: false,
      commentsVisible: false,
      comments: [],
    },
    {
      _id: 2,
      title: 'abc2',
      bgColor: '#2374AB',
      source: {
        uri:
          'https://tiktokvideos-niofox.s3.amazonaws.com/WhatsApp+Video+2020-11-11+at+10.15.51+AM+(3).mp4',
      },
      liked: false,
      commentsVisible: false,
      comments: [],
    },

    {
      _id: 3,
      title: 'abc3',
      bgColor: '#CD8987',
      source: {
        uri:
          'https://tiktokvideos-niofox.s3.amazonaws.com/WhatsApp+Video+2020-11-11+at+10.15.51+AM+(4).mp4',
      },
      liked: false,
      commentsVisible: false,
      comments: [],
    },
    {
      _id: 4,
      title: 'abc4',
      bgColor: '#CD8987',
      source: {
        uri:
          'https://tiktokvideos-niofox.s3.amazonaws.com/WhatsApp+Video+2020-11-11+at+10.15.51+AM+(5).mp4',
      },
      liked: false,
      commentsVisible: false,
      comments: [],
    },
  ],
  layout: {
    VIEW_AD_ENABLED: true,
    SHARE_ENABLED: false,
    COMMENTS_VISIBLE: false,
    FOR_YOU_VIDEO_PLAYABLE: true,
    profileImage: {
      scale: 1,
      transform: [{translateX: 0}, {translateY: 0}],
    },
  },
};

const ForYouReducer = (mState = {...state}, action) => {
  switch (action.type) {
    case SET_FORYOU_LAYOUT_KEY_VALUE:
      // console.log('Calling layout key value : for you');
      return produce(mState, (draftState) => {
        if (action.payload.force) {
          draftState.layout[action.payload.key] = action.payload.value;
        } else {
          draftState.layout[action.payload.key] = !draftState.layout[
            action.payload.key
          ];
        }
      });

    case SET_PROFILE_KEY_VALUE_FORYOU:
      console.log('Calling layout>Profile key value : for you');
      return produce(mState, (draftState) => {
        draftState.layout.profileImage[action.payload.key] =
          action.payload.value;
      });
    case PUSH_NEW_COMMENT:
      return produce(mState, (draftState) => {
        let {storyId, comment} = action.payload;
        console.log('TEST 01, Push Comment');
        console.log(`StoryId:${storyId} \nComment `);
        console.log(comment);
        /// find story index
        let storyIndex = draftState.stories.findIndex((s) => s._id === storyId);
        if (storyIndex >= 0) {
          /// found, then pushing comment
          console.log(`Story Found`);
          draftState.stories[storyIndex].comments.push(comment);
        } else {
          console.log(`Story Id:${storyId}  Not found`);
        }
      });

    case COMMENT_TOGGLE_LIKE:
      return produce(mState, (draftState) => {
        let {storyId, commentId, likedValue} = action.payload;
        /// finding story index
        let storyIndex = draftState.stories.findIndex((s) => s._id === storyId);
        if (storyIndex >= 0) {
          /// story found n
          /// finding comment in that story
          let commentIndex = draftState.stories[storyIndex].comments.findIndex(
            (c) => c._id === commentId,
          );
          if (commentIndex >= 0) {
            /// found and update
            draftState.stories[storyIndex].comments[
              commentIndex
            ].liked = likedValue;
          } else {
            console.log(
              `Story Id:${storyId}, CommentId: ${commentId}  Not found`,
            );
          }
        } else {
          console.log(`Story Id:${storyId}  Not found`);
        }
      });

    case STORY_TOGGLE_LIKE:
      return produce(mState, (draftState) => {
        let {storyId, likedValue} = action.payload;
        /// finding story index
        let storyIndex = draftState.stories.findIndex((s) => s._id === storyId);
        if (storyIndex >= 0) {
          /// story found n
          /// finding comment in that story
          draftState.stories[storyIndex].liked = likedValue;
        } else {
          console.log(`Story Id:${storyId}  Not found`);
        }
      });

    case COMMENT_SET_VISIBLE:
      return produce(mState, (draftState) => {
        let {storyId, value} = action.payload;
        /// finding story index
        let storyIndex = draftState.stories.findIndex((s) => s._id === storyId);
        if (storyIndex >= 0) {
          /// story found n
          /// finding comment in that story
          draftState.stories[storyIndex].commentsVisible = value;
        } else {
          console.log(`Story Id:${storyId}  Not found`);
        }
      });
    default:
      return {...mState};
  }
};
export default ForYouReducer;
