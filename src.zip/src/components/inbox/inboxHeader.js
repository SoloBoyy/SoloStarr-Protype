import React, {Component} from 'react';
import {View, Text} from 'react-native';
import {useSelector} from 'react-redux';
import CommentBlackSVG from '../../icons/commentBlackSVG';
import LikedBlackSVG from '../../icons/likedBlackSVG';
import PersonBlackSVG from '../../icons/personBlackSVG';
import MensionBlackSVG from '../../icons/mensionBlackSVG';
import {COMMENTED, MENSIONED, LIKED, FOLLOWED} from './activityTypeItem';
import InboxTabButton from './inboxTabButton';
import MyActivityController from '../../controllers/activityController';

const GetIcon = (type) => {
  switch (type) {
    case COMMENTED:
      return <CommentBlackSVG />;
    case LIKED:
      return <LikedBlackSVG />;
    case FOLLOWED:
      return <PersonBlackSVG />;
    case MENSIONED:
      return <MensionBlackSVG />;
    default:
      return undefined;
  }
};

const InboxHeader = (props) => {
  const typeFilter = useSelector((state) => state.ActivityReducer.typeFilter);
  return (
    <View style={{flex: 1, flexDirection: 'row'}}>
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <InboxTabButton
          {...{
            title: 'Messages',
            selected: props.selectedTab === 'messages',
            onPress: () => {
              if (props.onSelectTab) {
                props.onSelectTab('messages');
                MyActivityController.setFilter('');
              }
            },
          }}
        />
      </View>
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <InboxTabButton
          {...{
            Icon: () => GetIcon(typeFilter),
            iconVisible: typeFilter !== '',
            title: 'Activity',
            dropdown: props.selectedTab === 'activity',
            selected: props.selectedTab === 'activity',
            onPress: () => {
              if (props.onSelectTab) {
                props.onSelectTab('activity');
                MyActivityController.setFilter('');
              }
            },
          }}
        />
      </View>
    </View>
  );
};
export default InboxHeader;
