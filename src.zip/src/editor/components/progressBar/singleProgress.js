import React, {Component} from 'react';
import {View, StyleSheet} from 'react-native';
class SingleProgress extends Component {
  render() {
    const {props} = this;
    const peak = props.peak !== undefined ? props.peak : 100;
    const seek = props.seek !== undefined ? props.seek : 30;
    const percentage = `${Math.round((seek / peak) * 100)}%`;
    const clipsCount = props.clipsCount ? props.clipsCount : 0;
    const isFirst = clipsCount === 0 ? true : false;
    return (
      <View
        key={'SP0'}
        style={[
          Styles.container,
          {
            borderTopLeftRadius: isFirst ? 20 : 0,
            borderBottomLeftRadius: isFirst ? 20 : 0,
          },
        ]}>
        <View
          key={'SP0-0'}
          style={[
            Styles.progressStyle,
            {
              borderTopRightRadius: 20,
              borderBottomRightRadius: 20,
              borderTopLeftRadius: isFirst ? 20 : 0,
              borderBottomLeftRadius: isFirst ? 20 : 0,
              width: percentage,
            },
          ]}
        />
      </View>
    );
  }
}
export default SingleProgress;

const Styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 10,
    backgroundColor: 'gray',
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    zIndex: 99,
  },
  progressStyle: {
    backgroundColor: '#DD2E2E',
    height: '100%',
    zIndex: -99,
  },
});
