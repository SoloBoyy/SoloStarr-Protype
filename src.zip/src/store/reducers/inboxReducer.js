import produce from 'immer';
import MyInboxController from '../../controllers/inboxController';
import {PUSH_NEW_MESSAGE} from '../../controllers/types';

const state = {
  chat: [
    MyInboxController.getDummy('Mark Zuckerberg'),
    MyInboxController.getDummy('Steve Jobs'),
    MyInboxController.getDummy('Elon Musk'),
    MyInboxController.getDummy('Jeff Bezos'),
    MyInboxController.getDummy('Bill Gates'),
    MyInboxController.getDummy('Henry Ford'),
  ],
};

const InboxReducer = (mState = {...state}, action) => {
  switch (action.type) {
    case PUSH_NEW_MESSAGE:
      return produce(mState, (draftState) => {
        let chatId = action.payload.chatId;
        let message = action.payload.message;
        let chatIndex = draftState.chat.findIndex((c) => c._id === chatId);
        if (chatIndex >= 0) {
          draftState.chat[chatIndex].messages.push(message);
          draftState.chat[chatIndex].desc = `${
            message.text
          } ${new Date().toLocaleDateString()}`;
        }
      });
    default:
      return {...mState};
  }
};
export default InboxReducer;
