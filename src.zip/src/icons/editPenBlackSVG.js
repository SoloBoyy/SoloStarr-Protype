import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const EditPenBlackSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="32.743" height="32.743" viewBox="0 0 32.743 32.743">
  <path id="Icon_feather-edit-2" data-name="Icon feather-edit-2" d="M25.5,4.5a4.243,4.243,0,0,1,6,6L11.25,30.75,3,33l2.25-8.25Z" transform="translate(-1.5 -1.757)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="3"/>
</svg>
`}
    />
  );
};
export default EditPenBlackSVG;
