import React, {Component} from 'react';
import {
  View,
  StatusBar,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Text,
} from 'react-native';
import ControlsOverlay from './components/controlsOverlay';
import MyLayoutManager from './Controllers/layoutManager';
import EditorControlsOvarlay from './components/editorControlsOverlay';
import {connect} from 'react-redux';
import VideoMakingScreen from './screens/videoMakingScreen';
import VideoEditingScreen from './screens/videoEditingScreen';
import TimerSelect from './components/quickControls/timerSelect';
import MyProcessingLoader from './components/myProcessingLoader';
import {SECONDRY_BLACK} from '../themes/colors';
import AlertBox from './components/quickControls/alertBox';
import MyAlertBoxController from './Controllers/myAlertBoxController';
const MyScreens = (props) => {
  if (props.mode === MyLayoutManager.VIDEO_MAKING_MODE) {
    return <VideoMakingScreen key={0} />;
  } else {
    return <VideoEditingScreen key={1} />;
  }
};

class TKTEditor extends Component {
  componentDidMount() {
    MyLayoutManager.initialize();
  }
  render() {
    // console.log(`MODE: ${this.props.mode}`);
    return (
      <View style={Styles.container}>
        {/* <StatusBar hidden /> */}
        {/* <MyScreens mode={this.props.mode} /> */}

        <Modal
          key={2}
          animationType="fade"
          transparent={true}
          visible={this.props.bottomOptionMenuEnable}
          onRequestClose={() => {
            MyLayoutManager.setBottomOptionMenuMode(false);
          }}>
          <View
            style={{
              flex: 1,
              padding: 0,
              backgroundColor: 'rgba(1,1,1, 0.7)',
            }}>
            <TouchableOpacity
              onPress={() => MyLayoutManager.setBottomOptionMenuMode(false)}
              activeOpacity={0}
              style={{
                flex: 1,
                backgroundColor: 'transparent',
              }}></TouchableOpacity>
            <TimerSelect />
          </View>
        </Modal>
        <Modal
          key={4}
          animationType="slide"
          transparent={true}
          visible={this.props.loader.visible}
          onRequestClose={() => {
            MyLayoutManager.setBottomOptionMenuMode(false);
          }}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <MyProcessingLoader
              visible={true}
              message={this.props.loader.message}
            />
          </View>
        </Modal>
        <Modal
          key={5}
          animationType="fade"
          transparent={true}
          visible={this.props.alerBoxVisible}
          onRequestClose={() => {
            // MyLayoutManager.setBottomOptionMenuMode(false);
            MyAlertBoxController.onAlertResult('');
          }}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: 'rgba(1,1,1, 0.7)',
              // backgroundColor: 'black',
            }}>
            <AlertBox />
          </View>
        </Modal>
      </View>
    );
  }
}

const mapStateToProps = (state) => ({
  mode: state.EditorReducer.mode,
  bottomOptionMenuEnable: state.EditorReducer.bottomOptionMenuEnable,
  loader: state.EditorReducer.loader,
  alerBoxVisible: state.EditorReducer.alerBoxVisible,
});
export default connect(mapStateToProps, null)(TKTEditor);

const Styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    backgroundColor: '#111111',
  },
});
