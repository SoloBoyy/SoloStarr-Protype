import React, {useState, useRef} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import ChevronDownBlackSVG from '../../icons/chevronDownBlackSVG';
import OverlayModal from './overlayModal';
import CircleButton from './circleButton';
import LikedBlackSVG from '../../icons/likedBlackSVG';
import CommentBlackSVG from '../../icons/commentBlackSVG';
import MensionBlackSVG from '../../icons/mensionBlackSVG';
import PersonBlackSVG from '../../icons/personBlackSVG';
import MyActivityController from '../../controllers/activityController';
import {COMMENTED, FOLLOWED, LIKED, MENSIONED} from './activityTypeItem';
import Popover, {PopoverPlacement} from 'react-native-popover-view';

const InboxTabButton = ({
  title,
  selected,
  width,
  onPress,
  onLongPress,
  Icon,
  dropdown,
  iconVisible,
}) => {
  const isSelected = selected;
  const [controlsVisible, setControlsVisible] = useState(false);
  const btnRef = useRef();
  if (dropdown) {
    return (
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <TouchableOpacity
          onPress={onPress ? onPress : () => false}
          onLongPress={onLongPress ? onLongPress : () => false}
          style={{
            paddingLeft: 10,
            paddingRight: 10,
            height: 25,

            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 50,
            backgroundColor: isSelected ? WHITE_COLOR : SECONDRY_BLACK,
          }}>
          {iconVisible === true ? (
            Icon()
          ) : (
            <Text
              style={{
                color: isSelected ? SECONDRY_BLACK : WHITE_COLOR,
                fontWeight: 'bold',
              }}>
              {title}
            </Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          ref={btnRef}
          onPress={() => setControlsVisible(true)}
          style={{
            width: 20,
            height: 20,
            marginLeft: 5,
            borderRadius: 50,
            backgroundColor: 'white',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <ChevronDownBlackSVG size={12} />
        </TouchableOpacity>
        {/* <OverlayModal
          setVisible={(value) => setControlsVisible(value)}
          {...{visible: controlsVisible}}> */}
        <Popover
          backgroundStyle={{backgroundColor: 'transparent'}}
          popoverStyle={{
            height: 150,
            width: 35,
            backgroundColor: 'transparent',
          }}
          placement={PopoverPlacement.BOTTOM}
          from={btnRef}
          key={25}
          isVisible={controlsVisible}
          onRequestClose={() => {
            setControlsVisible(false);
          }}>
          <View style={{}}>
            {/* <TouchableOpacity
              onPress={() => setControlsVisible(false)}
              style={{width: 100, height: 40}}></TouchableOpacity> */}
            <CircleButton
              onPress={() => {
                MyActivityController.setFilter(LIKED);
                setControlsVisible(false);
              }}
              size={30}
              Icon={() => <LikedBlackSVG size={18} />}
            />
            <CircleButton
              onPress={() => {
                MyActivityController.setFilter(COMMENTED);
                setControlsVisible(false);
              }}
              size={30}
              Icon={() => <CommentBlackSVG size={15} />}
            />
            <CircleButton
              onPress={() => {
                MyActivityController.setFilter(MENSIONED);
                setControlsVisible(false);
              }}
              size={30}
              Icon={() => <MensionBlackSVG size={15} />}
            />
            <CircleButton
              onPress={() => {
                MyActivityController.setFilter(FOLLOWED);
                setControlsVisible(false);
              }}
              size={30}
              Icon={() => <PersonBlackSVG size={15} />}
            />
          </View>
        </Popover>
        {/* </OverlayModal> */}
      </View>
    );
  } else {
    return (
      <TouchableOpacity
        onPress={onPress ? onPress : () => false}
        onLongPress={onLongPress ? onLongPress : () => false}
        style={{
          paddingLeft: 10,
          paddingRight: 10,
          height: 25,
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: 50,
          backgroundColor: isSelected ? WHITE_COLOR : SECONDRY_BLACK,
        }}>
        {iconVisible ? (
          Icon()
        ) : (
          <Text
            style={{
              color: isSelected ? SECONDRY_BLACK : WHITE_COLOR,
              fontWeight: 'bold',
            }}>
            {title}
          </Text>
        )}
      </TouchableOpacity>
    );
  }
};
export default InboxTabButton;
