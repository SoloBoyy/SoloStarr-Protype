import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  Animated,
  Modal,
  Image,
  ImageBackground,
  Alert,
} from 'react-native';
import {DARK_GRAY, LIGHT_GRAY} from '../../../themes/colors';
import {PanGestureHandler, State} from 'react-native-gesture-handler';
import MyLayoutManager from '../../Controllers/layoutManager';
import MyAlertBoxController from '../../Controllers/myAlertBoxController';
import MyRecordingController from '../../Controllers/recordingConroller';
import MyEditingController from '../../Controllers/editingController';

export const CLIP_SELECTED_SIZE = {width: 200, height: 120};
export const CLIP_NORMAL_SIZE = {width: 50, height: 70};
export const CLIP_TRANSITOR_SIZE = {width: 15};

const SingleClip = ({
  clip,
  index,
  timelineSize,
  onPress,
  onDragging,
  containerHeight,
}) => {
  const selected = clip.selected ? true : false;
  const size = selected ? CLIP_SELECTED_SIZE : CLIP_NORMAL_SIZE;
  const isLastIndex = index === timelineSize - 1;
  const {width, height} = Dimensions.get('window');
  /// Draging Animation Hooks and Variables
  const [dragging, setDragging] = useState(false);
  const [trashable, setTrashable] = useState(false);
  const _translateX = new Animated.Value(0);
  const _translateY = new Animated.Value(0);

  const _lastOffset = {x: 0, y: 0};
  const _lastAbsolutePosition = {x: 0, y: 0};
  const TRASH_POINT_Y = height - (containerHeight + 80);
  const TRASH_POINT_X = 20;
  let INITIAL_DELTA = 40;
  let X = 0;
  let Y = 0;
  let DIFF = 0;

  useEffect(() => {
    console.log('Getting for Clip');
    MyEditingController.extractPreviewforClip(clip);
  }, []);

  const _onGestureEvent = Animated.event(
    [
      {
        nativeEvent: {
          absoluteX: _translateX,
          absoluteY: _translateY,
        },
      },
    ],
    {useNativeDriver: true},
  );

  _translateX.addListener(({value}) => {
    X = value;
  });
  _translateY.addListener(({value}) => {
    Y = value;
    DIFF = X - TRASH_POINT_X - (Y - TRASH_POINT_Y);
    // DIFF < 40
    //   ? trashable !== true
    //     ? false
    //     : false
    //   : trashable !== false
    //   ? setTrashable(false)
    //   : false;
    // console.log(DIFF);
    // if (DIFF < 100) {
    //   setTrashable(true);
    // } else {
    //   setTrashable(false);
    // }

    // console.log(`DIFFERANCE: ${DIFF}`);
  });

  // useState(() => {
  //   DIFF < 40
  //     ? setTrashable(true)
  //     : trashable !== false
  //     ? setTrashable(false)
  //     : false;
  // }, [DIFF]);

  let TRASH_DIFF = Animated.subtract(
    Animated.subtract(_translateX, TRASH_POINT_X),
    Animated.subtract(_translateY, TRASH_POINT_Y),
  );

  let scale = TRASH_DIFF.interpolate({
    inputRange: [0, 0, 1, INITIAL_DELTA],
    outputRange: [0.3, 0.4, 0.5, 0.6],
  });

  const _onHandlerStateChange = (event) => {
    console.log('GESTURE STATE');
    if (event.nativeEvent.oldState === State.ACTIVE) {
      _lastAbsolutePosition.x = event.nativeEvent.absoluteX;
      _lastAbsolutePosition.y = event.nativeEvent.absoluteY;
      _lastOffset.x += event.nativeEvent.translationX;
      _lastOffset.y += event.nativeEvent.translationY;
      _translateX.setOffset(_lastOffset.x);
      _translateX.setValue(0);
      _translateY.setOffset(_lastOffset.y);
      _translateY.setValue(0);
    }
    let ne = event.nativeEvent;
    switch (event.nativeEvent.state) {
      case State.ACTIVE:
        INITIAL_DELTA = Math.abs(
          ne.absoluteX - TRASH_POINT_X - (ne.absoluteY - TRASH_POINT_Y),
        );
        setDragging(true);
        onDragging(true);

        break;
      case State.BEGAN:
        break;
      case State.CANCELLED:
        setDragging(false);
        onDragging(false);
        break;
      case State.END:
        console.log(_lastAbsolutePosition);
        console.log(`TX: ${TRASH_POINT_X}, TY: ${TRASH_POINT_Y}`);
        let mDiff = Math.abs(
          _lastAbsolutePosition.x -
            TRASH_POINT_X -
            (_lastAbsolutePosition.y - 100 - TRASH_POINT_Y),
        );
        console.log(`DIFFEANCE=: ${mDiff}`);
        setDragging(false);
        onDragging(false);
        if (mDiff < 100) {
          MyAlertBoxController.show(
            MyAlertBoxController.ACTIONS_NO_DISCARD,
            'Clip will be discarded permanently',
            (result) => {
              if (result === MyAlertBoxController.RESULTS.DISCARD) {
                MyRecordingController.removeRecordedClipById(clip._id);
              }
            },
          );
        }
        break;
    }
  };

  return (
    <>
      <Animated.View
        style={{
          flexDirection: 'row',
          alignSelf: 'center',
        }}>
        <ImageBackground
          source={clip.info.thumbnail}
          imageStyle={{borderRadius: 8}}
          style={{
            ...size,
            backgroundColor: LIGHT_GRAY,
            borderRadius: 8,
          }}>
          <PanGestureHandler
            onHandlerStateChange={_onHandlerStateChange}
            onGestureEvent={_onGestureEvent}>
            <Animated.View
              style={{
                height: 25,
                backgroundColor: 'transparent',
                borderTopRightRadius: 8,
                borderTopLeftRadius: 8,
              }}
            />
          </PanGestureHandler>
          <TouchableOpacity
            onPress={onPress ? () => onPress(clip) : () => false}
            style={{flex: 1}}>
            {/* <Image
              style={{backgroundColor: 'black', width: '100%', height: '100%'}}
              resizeMode="cover"
              source={{uri: `data:image/jpeg;base64,${clip.info.thumbnail}`}}
            /> */}
          </TouchableOpacity>
        </ImageBackground>
        {!isLastIndex ? (
          <View
            style={{
              width: CLIP_TRANSITOR_SIZE.width,
              backgroundColor: 'transparent',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: 8,
                height: 8,
                backgroundColor: LIGHT_GRAY,
                borderRadius: 50,
              }}
            />
          </View>
        ) : (
          false
        )}
      </Animated.View>
      <Modal visible={dragging} transparent={true}>
        <>
          <Animated.View
            style={[
              {
                ...size,
                borderRadius: 8,
                backgroundColor: 'transparent',

                justifyContent: 'center',
                alignItems: 'center',
              },
              {
                transform: [
                  {translateY: Animated.add(_translateY, -100)},
                  {translateX: Animated.add(_translateX, -50)},
                  {scale},
                ],
              },
            ]}>
            <ImageBackground
              style={{width: '100%', height: '100%'}}
              imageStyle={{borderRadius: 8}}
              resizeMode="cover"
              source={clip.info.thumbnail}>
              {/* <Text style={{color: 'white'}}>Test</Text> */}
            </ImageBackground>
          </Animated.View>
          <View
            style={{
              position: 'absolute',
              left: TRASH_POINT_X,
              top: TRASH_POINT_Y,
              width: 40,
              height: 40,
              backgroundColor: 'transparent',
            }}>
            {/* <Text style={{color: 'white'}}>drip box</Text> */}
          </View>
        </>
      </Modal>
    </>
  );
};
export default SingleClip;
