import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const PersonWhiteSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      style={{...props.style}}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
  <path id="Icon_material-person" data-name="Icon material-person" d="M13,13A3.5,3.5,0,1,0,9.5,9.5,3.5,3.5,0,0,0,13,13Zm0,1.75c-2.336,0-7,1.172-7,3.5V20H20V18.25C20,15.922,15.336,14.75,13,14.75Z" transform="translate(-6 -6)" fill="#fff"/>
</svg>
`}
    />
  );
};
export default PersonWhiteSVG;
