import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {SECONDRY_BLACK, WHITE_COLOR} from '../../themes/colors';
import ActionsOverlay from './actionsOverlay';
import DescTags from './descTags';
import HitBox, {SIZE} from './hitBox';

export const BOTTOM_MARGIN = 30;
const ForYouOverlay = (props) => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: SECONDRY_BLACK,
        ...StyleSheet.absoluteFillObject,
      }}>
      <ActionsOverlay
        style={{position: 'absolute', bottom: BOTTOM_MARGIN, right: 0}}
      />
      <DescTags
        style={{position: 'absolute', bottom: BOTTOM_MARGIN + SIZE + 10}}
      />
      {/* <HitBox
        style={{
          position: 'absolute',
          bottom: BOTTOM_MARGIN,
          alignSelf: 'center',
        }}
      /> */}
    </View>
  );
};
export default ForYouOverlay;
