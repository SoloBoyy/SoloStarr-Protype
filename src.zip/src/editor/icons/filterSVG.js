import React, {Component} from 'react';
import {SvgXml} from 'react-native-svg';

const FilterSVG = (props) => {
  const size = props.size ? props.size : 20;
  return (
    <SvgXml
      width={size}
      height={size}
      xml={`<svg xmlns="http://www.w3.org/2000/svg" width="85.566" height="54.5" viewBox="0 0 85.566 54.5">
  <g id="Group_5" data-name="Group 5" transform="translate(-346.434 -34.5)">
    <g id="Group_4" data-name="Group 4" transform="translate(347.702 36)">
      <path id="Path_11" data-name="Path 11" d="M318.7,102.83,344.621,80,361.4,96.937" transform="translate(-318.702 -67.546)" fill="none" stroke="#f0f0f0" stroke-width="3"/>
      <path id="Path_12" data-name="Path 12" d="M359,106.681,384.687,88l8.334,9.246" transform="translate(-328.411 -69.319)" fill="none" stroke="#f0f0f0" stroke-width="3"/>
      <circle id="Ellipse_3" data-name="Ellipse 3" cx="2.724" cy="2.724" r="2.724" transform="translate(53.552 9.341)" fill="#f0f0f0"/>
      <g id="Group_2" data-name="Group 2" transform="translate(46.935 28.8)">
        <rect id="Rectangle_4" data-name="Rectangle 4" width="37" height="4" rx="2" transform="translate(0.363 1.2)" fill="#f0f0f0"/>
        <circle id="Ellipse_4" data-name="Ellipse 4" cx="3.5" cy="3.5" r="3.5" transform="translate(24.363 0.2)" fill="#fff"/>
      </g>
      <path id="Path_14" data-name="Path 14" d="M393.947,168.908,393.838,144H320v49.817h42.811" transform="translate(-319.768 -144)" fill="none" stroke="#f0f0f0" stroke-linecap="round" stroke-width="3"/>
      <g id="Group_1" data-name="Group 1" transform="translate(46.935 37.363)">
        <rect id="Rectangle_5" data-name="Rectangle 5" width="37" height="4" rx="2" transform="translate(0.363 1.637)" fill="#f0f0f0"/>
        <circle id="Ellipse_5" data-name="Ellipse 5" cx="3.5" cy="3.5" r="3.5" transform="translate(5.363 -0.363)" fill="#fff"/>
      </g>
      <g id="Group_3" data-name="Group 3" transform="translate(46.935 45.925)">
        <rect id="Rectangle_5-2" data-name="Rectangle 5" width="37" height="4" rx="2" transform="translate(0.363 1.075)" fill="#f0f0f0"/>
        <circle id="Ellipse_5-2" data-name="Ellipse 5" cx="3.5" cy="3.5" r="3.5" transform="translate(24.363 0.075)" fill="#fff"/>
      </g>
    </g>
  </g>
</svg>
`}
    />
  );
};
export default FilterSVG;
