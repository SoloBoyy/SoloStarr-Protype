import React, {Component} from 'react';

import {
  View,
  Text,
  ImageBackground,
  Image,
  Animated,
  PanResponder,
  StatusBar,
} from 'react-native';
// import Animated from 'react-native-reanimated';
import {
  PinchGestureHandler,
  PanGestureHandler,
  State,
} from 'react-native-gesture-handler';
import {Svg, Defs, Rect, Mask, Circle} from 'react-native-svg';
const AnimatedCircle = Animated.createAnimatedComponent(Circle);
class ImageCropScreen extends Component {
  constructor() {
    super();
    this.state = {};
    this.baseScale = new Animated.Value(1);
    this.pinchScale = new Animated.Value(1);
    this.mRef = null;
    this.selectCircleRef = null;
    this.lastScale = 1;
    this._translateX = new Animated.Value(0);
    this._translateY = new Animated.Value(0);
    this._translateX.setOffset(200);
    this._translateY.setOffset(150);
    this._absoluteX = new Animated.Value(0);
    this._absoluteY = new Animated.Value(0);
    this._lastOffset = {x: 200, y: 150};
    this.scale = Animated.multiply(this.baseScale, this.pinchScale);

    // this._translateX.addListener;
    // this.scale.addListener(({value}) => {
    //   console.log(value);
    //   this.selectCircleRef.setNativeProps({r: (value * 100).toString()});
    // });
    this.onGestureEvent = Animated.event(
      [{nativeEvent: {scale: this.pinchScale}}],
      {useNativeDriver: true},
    );
    this.onChangeGestureState = ({nativeEvent}) => {
      if (nativeEvent.oldState === State.ACTIVE) {
        this.lastScale *= nativeEvent.scale;
        this.baseScale.setValue(this.lastScale);
        this.pinchScale.setValue(1);
      }
    };

    this.onPanGestureEvent = Animated.event(
      [
        {
          nativeEvent: {
            translationX: this._translateX,
            translationY: this._translateY,
            x: this._absoluteX,
            y: this._absoluteY,
          },
        },
      ],
      {useNativeDriver: true},
    );
    this._onPanHandlerStateChange = (event) => {
      if (event.nativeEvent.oldState === State.ACTIVE) {
        this._lastOffset.x += event.nativeEvent.translationX;
        this._lastOffset.y += event.nativeEvent.translationY;
        this._translateX.setOffset(this._lastOffset.x);
        this._translateX.setValue(0);
        this._translateY.setOffset(this._lastOffset.y);
        this._translateY.setValue(0);

        // this.mRef.measure((x, y, width, height, pageX, pageY) => {
        //   console.log(
        //     `x:${pageX} y:${pageY} StatusBarHeigh:${StatusBar.currentHeight}`,
        //   );
        // });
      }
    };
  }

  render() {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ImageBackground
          style={{width: '100%', height: '100%'}}
          source={require('../assets/SAMPLE01.jpg')}>
          <PanGestureHandler
            onGestureEvent={this.onPanGestureEvent}
            onHandlerStateChange={this._onPanHandlerStateChange}
            maxPointers={1}
            minPointers={1}>
            <Animated.View
              ref={(e) => (this.mRef = e)}
              style={{
                width: '100%',
                height: '100%',
                borderRadius: 100,
                backgroundColor: 'transparent',
              }}>
              <PinchGestureHandler
                onGestureEvent={this.onGestureEvent}
                onHandlerStateChange={this.onChangeGestureState}>
                <Animated.View
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 100,
                    backgroundColor: 'transparent',
                  }}>
                  <Svg height="100%" width="100%">
                    <Defs>
                      <Mask id="mask" x="0" y="0" height="100%" width="100%">
                        <Rect height="100%" width="100%" fill="#fff" />
                        {/* <Animated.View
                          style={{
                            backgroundColor: 'rgba(0,0,0,0.3)',
                            width: 100,
                            height: 100,
                            transform: [{scale: this.scale}],
                          }}> */}
                        <AnimatedCircle
                          ref={(e) => (this.selectCircleRef = e)}
                          fill="#000000"
                          r="100"
                          cx={this._translateX}
                          cy={this._translateY}
                        />
                        {/* </Animated.View> */}
                      </Mask>
                    </Defs>
                    <Rect
                      height="100%"
                      width="100%"
                      fill="rgba(0, 0, 0, 0.5)"
                      mask="url(#mask)"
                      fill-opacity="0"
                    />
                  </Svg>
                </Animated.View>
              </PinchGestureHandler>
            </Animated.View>
          </PanGestureHandler>
        </ImageBackground>
      </View>
    );
  }
}

export default ImageCropScreen;

//  <PinchGestureHandler
//    onGestureEvent={this.onGestureEvent}
//    onHandlerStateChange={this.onChangeGestureState}>
//    <Animated.Image
//      style={{
//        width: '100%',
//        height: '100%',
//        backgroundColor: 'black',
//        transform: [{scale: this.scale}, {translateX: 0}],
//      }}
//      source={require('../assets/SAMPLE01.jpg')}
//    />
//  </PinchGestureHandler>;
