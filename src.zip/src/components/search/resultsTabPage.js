import React, {useState, useEffect} from 'react';
import {View, Text, FlatList} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import UserInfoItem from './userInfoItem';

const ResultsTabPage = (props) => {
  const [resultItems, setResultItems] = useState([{_id: 1}, {_id: 2}]);

  useEffect(() => {
    let items = [];
    for (let index = 0; index < 10; index++) {
      items.push({_id: index});
    }
    setResultItems(items);
  }, []);
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: SECONDRY_BLACK,
      }}>
      <View style={{width: '80%', alignSelf: 'center'}}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={resultItems}
          renderItem={({item, index}) => <UserInfoItem />}
          keyExtractor={(item) =>
            `${item._id}${Math.round(Math.random() * 10000)}`
          }
        />
      </View>
    </View>
  );
};
export default ResultsTabPage;
