import React, {Component} from 'react';
import {StyleSheet, View, FlatList} from 'react-native';
import {SECONDRY_BLACK} from '../../themes/colors';
import SoundItemComponent from './soundItem';

class SearchTabPage extends Component {
  state = {
    sounds: [
      {id: 1, songName: 'Song Name', songDescription: 'Description'},
      {id: 2, songName: 'Song Name', songDescription: 'Description'},
      {id: 3, songName: 'Song Name', songDescription: 'Description'},
      {id: 4, songName: 'Song Name', songDescription: 'Description'},
    ],
  };
  render() {
    return (
      <View style={styles.container}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={this.state.sounds}
          renderItem={({item}) => (
            <SoundItemComponent
              songName={item.songName}
              songDescription={item.songDescription}
            />
          )}
          keyExtractor={(item) => item.id}
        />
      </View>
    );
  }
}

export default SearchTabPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: SECONDRY_BLACK,
  },
});
