import React, {Component} from 'react';
import {View, Text, StatusBar} from 'react-native';
import UserChatHeaderContainer from '../components/inbox/userChatHeaderContainer';
import UserChatHeader from '../components/inbox/userChatHeader';
import {SECONDRY_BLACK} from '../themes/colors';
import ChatInputBox from '../components/inbox/chatInputBox';
import {navigate} from '../navigator';
class UserMessageScreen extends Component {
  state = {
    messageText: '',
  };
  render() {
    return (
      <View style={{flex: 1, backgroundColor: 'black'}}>
        <StatusBar backgroundColor={SECONDRY_BLACK} />
        <UserChatHeaderContainer
          navigation={this.props.navigation}
          onPressRight={() => navigate('BoostCoinBuyScreen')}>
          <UserChatHeader />
        </UserChatHeaderContainer>
        <View style={{height: 10}} />
        <View
          style={{
            backgroundColor: SECONDRY_BLACK,
            borderRadius: 10,
            width: '90%',
            alignSelf: 'center',
            padding: 10,
          }}>
          <Text style={{color: 'white'}}>
            Starrs allow your messages to stand out in a creators inbox
          </Text>
          <View style={{height: 10}} />
          <Text style={{color: 'white'}}>3 Starrs Available</Text>
        </View>
        <View style={{flex: 1}} />
        <ChatInputBox
          value={this.state.messageText}
          onSubmit={() => {
            this.setState({messageText: ''});
          }}
          onChangeText={(text) => this.setState({messageText: text})}
        />
      </View>
    );
  }
}

export default UserMessageScreen;
